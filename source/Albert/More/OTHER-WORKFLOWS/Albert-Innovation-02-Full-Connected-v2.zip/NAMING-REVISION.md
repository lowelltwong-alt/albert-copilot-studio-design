# Presentation revision

Recipient titles normalized. Prior archive SHA-256: `90fb41bee39b0546200b4d3ec3f677a1fee485df76fc3a6006a9e3c30188c9d2`. Historical validation reports describe the original revision; they are not fresh tenant or performance results. Manifest payload fingerprints reflect this naming copy. Source and license notices remain applicable.
