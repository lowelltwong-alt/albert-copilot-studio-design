# Presentation revision

Recipient titles normalized. Prior archive SHA-256: `edab008c642e020057e55d0b5d58d3f0209d86c31a37b447dc87f40fc8b1d803`. Historical validation reports describe the original revision; they are not fresh tenant or performance results. Manifest payload fingerprints reflect this naming copy. Source and license notices remain applicable.
