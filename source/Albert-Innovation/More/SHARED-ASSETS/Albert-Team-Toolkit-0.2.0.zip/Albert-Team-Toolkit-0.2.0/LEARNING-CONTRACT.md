# Portable learning contract

`learning.py` evaluates one operator-supplied JSON bundle through this bounded
sequence:

```text
event -> fixed claim -> validation refs -> regression refs -> lesson candidate
      -> separate operator adoption decision
```

It is a pure standard-library evaluator. It has no DAD import, persistence,
network access, command execution, prompt editing, registry edit, or automatic
promotion. Its JSON output is an ordered diagnostic result; it does not state
that a repair was actually performed or that people are independent.

## Input shape

The top-level object must contain exactly these fields:

```text
schema_version: "innovation.learning-input.v1"
bundle_id: lowercase operator identifier
classification: "public_metadata"
event, fix, lesson_candidate, adoption_decision
```

All IDs are canonical and deterministic. `learning.py` recomputes them from
the record's stable identity fields and rejects a mismatch:

| Record | Identity fields |
| --- | --- |
| event | source ID, event type, observed artifact revision, error fingerprint |
| fix | canonical event ID, decision, fixed artifact revision, fix summary |
| lesson | canonical event/fix IDs, fixed artifact revision, lesson summary |
| adoption | canonical candidate ID, decision, declared scope |

An artifact revision is exactly `sha256:` followed by 64 lowercase hex digits.
Every validation and regression reference is an object with exactly
`ref_id`, `artifact_revision`, and `status`. It must have `status: "passed"`
and bind to `fix.artifact_revision`. This is a claim about supplied evidence;
the evaluator does not run the referenced check.

The event must be public metadata. Text is bounded and rejects secret-like,
private-path, and hidden-reasoning-like markers. This is a
conservative local screen, not a proof that a record has no sensitive data.

## Transitions and holds

- A fixed claim needs an explicit `decision: "fixed"`, both validation and
  regression references, and a checker identity distinct from the fix author.
  Different strings do **not** prove two independent people or reviewers.
- A candidate links to the fixed revision and must state where it applies,
  where it does not, and its misuse risk.
- A non-empty `prior_candidate_ids` array produces
  `needs_duplicate_review`; it never becomes adoption-eligible automatically.
- `pending` produces `candidate_record_valid_review_pending`. This validates
  only supplied record shape and references; holdout evidence, prompt-level
  regression, rollback/expiry policy, and adopter authenticity remain
  unverified. `adopt` records only an operator-supplied human approver ID and produces
  `adoption_recorded_not_applied`. It does not alter this toolkit.
- Invalid, incomplete, stale, unsafe, self-checked, or false fixed claims are
  `rejected`.

Use it directly:

```powershell
python -B learning.py validate examples/learning-complete.json
python -B learning.py demo examples/learning-complete.json
python -B -m unittest -v test_learning.py
```

`validate` and `demo` are intentionally equivalent local diagnostics. They read
the named file and emit one JSON object to stdout. A rejected document exits 1;
no file is written. `examples/learning-complete.json` is a synthetic positive
case. `examples/learning-rejected-unsafe.json` demonstrates rejection without
containing a real credential or private case data.

## Donor notice and adaptation boundary

This is a narrow adaptation of constraints inspected in the private
Digital-Assett-Directory donor; it does not copy its registry, lake records,
raw data, outboxes, source policies, or runtime. The owner explicitly
authorized this scoped, owner-controlled team handoff in this session. The
donor nevertheless declares that no general public reuse licence is granted in
`LICENSE_DECISION_REQUIRED.md`; do not represent this as a public donor licence
or distribute it outside the authorized owner-controlled scope without a human
provenance and licensing decision.

Evidence inspected on 2026-09-08:

| Donor surface | SHA-256 | Constraint adapted |
| --- | --- | --- |
| `schemas/exception-event.schema.json` | `38141347EE1EFFB7F06B5A1049E21B2122CAE598BB71DA1D976ED43043644294` | stable event metadata, bounded fields, privacy screening |
| `schemas/exception-fix-outcome.schema.json` | `B72CA4BC8622B863874A917EFCC840E7E170EB377ACA4C51346E8C37578A94F9` | fixed claims need validation and regression references |
| `src/digital_asset_directory/exceptions_lake.py` | `53E4E6DD8F68232766B1A03D373DE56E6F18BDCD43B5344DFED47F1C719E9376` | `stable_exception_event_id`, `stable_exception_fix_id`, `screen_exception_record`, `build_exception_fix_outcome`, `hard_issue_lookup`, `_is_validated_fixed_outcome` |
| `src/digital_asset_directory/priority_content_lessons.py` | `426AA6AB457CD1AD10F48C0F58AAE23CC3B140F39492DE1B0D0FD1F0EBC90602` | generated-only promotion candidate and separate human registry gate |

This evaluator intentionally strengthens two donor-trace gaps: it binds every
verification reference to the exact fixed revision and rejects author/checker
identity equality. It does not claim the donor already implements either
enhancement. It also deliberately omits DAD's private source policy, collection,
quarantine, registry, storage, and MCP host configuration.
