"""Read-only local tests for the isolated Team Toolkit runtime.

No temporary directory is created. Baseline tests use the final catalog copied
into this bundle; malformed catalog cases are in-memory mocks.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import socket
import sys
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
CATALOG_PATH = HERE / "catalog.json"
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from dad_provider import LocalDADStdioProvider, NullDADProvider
from toolkit import (
    MAX_RELATED_PER_ASSET,
    RELATED_THRESHOLD,
    Catalog,
    CatalogError,
    _dad_graph_tokens,
    _graph_asset_tokens,
    _idf_weighted_cosine,
    _idf_weights,
    dispatch,
)


def _catalog_or_skip(case: unittest.TestCase) -> Catalog:
    if not CATALOG_PATH.is_file():
        case.skipTest("bundle catalog.json has not been generated")
    return Catalog.load(CATALOG_PATH)


def _synthetic_asset(asset_id: str) -> dict:
    return {
        "id": asset_id, "title": "MCP guidance", "type": "guide", "path": "toolkit.py",
        "description": "Generic guide", "use_when": "Review adapter", "avoid_when": "Case evidence",
        "tags": ["mcp"], "capabilities": ["fit"], "needs": ["integration"], "outcomes": ["review"],
        "version": "1.0.0", "classification": "portable_core", "review_status": "candidate",
        "sensitivity": "public_metadata", "sha256": "0" * 64, "provenance": ["in-memory-test"],
    }


class OfflineRuntimeTests(unittest.TestCase):
    def test_catalog_search_content_neighbors_and_candidate_graph(self) -> None:
        catalog = _catalog_or_skip(self)
        asset = catalog.assets[0]
        self.assertTrue(catalog.validate()["valid"])
        results = catalog.search(asset["id"])["results"]
        self.assertTrue(results)
        self.assertEqual(catalog.content(asset["id"])["sha256"], asset["sha256"])
        self.assertEqual(catalog.neighbors(asset["id"])["asset_id"], asset["id"])
        graph = catalog.graph()
        self.assertIn("candidate_edges", graph)
        self.assertNotIn('"score"', json.dumps(graph))
        self.assertLess(len(graph["candidate_edges"]), len(catalog.assets) * (len(catalog.assets) - 1) // 2)
        degree = {asset["id"]: 0 for asset in catalog.assets}
        for edge in graph["candidate_edges"]:
            self.assertTrue(edge["evidence"].startswith("normalized IDF shared terms: "))
            degree[edge["source"]] += 1
            degree[edge["target"]] += 1
        self.assertTrue(all(value <= MAX_RELATED_PER_ASSET for value in degree.values()))
        reordered = Catalog(catalog.root, catalog.release, tuple(reversed(catalog.assets)), catalog.edges)
        self.assertEqual(graph["candidate_edges"], reordered.graph()["candidate_edges"])

    def test_graph_uses_normalized_idf_cosine_for_related_not_unrelated_cards(self) -> None:
        close_left = _dad_graph_tokens("MCP Streamable HTTP adapter validates protocol schema")
        close_right = _dad_graph_tokens("MCP protocol schema validation for Streamable HTTP adapter")
        unrelated = _dad_graph_tokens("gardening compost irrigation and landscape flowers")
        weights = _idf_weights((close_left, close_right, unrelated))
        self.assertGreaterEqual(_idf_weighted_cosine(close_left, close_right, weights), RELATED_THRESHOLD)
        self.assertEqual(_idf_weighted_cosine(close_left, unrelated, weights), 0.0)

    def test_graph_ignores_identifiers_and_generic_avoidance_boilerplate(self) -> None:
        left = {
            "id": "left-id", "type": "guide", "use_when": "shared boilerplate", "avoid_when": "shared boilerplate",
            "title": "Protocol adapter", "description": "Schema negotiation", "tags": ["mcp"],
            "capabilities": ["transport"], "needs": ["client"], "outcomes": ["interoperability"],
        }
        right = {
            "id": "right-id", "type": "guide", "use_when": "shared boilerplate", "avoid_when": "shared boilerplate",
            "title": "Garden compost", "description": "Soil nutrients", "tags": ["horticulture"],
            "capabilities": ["mulching"], "needs": ["rainwater"], "outcomes": ["flowers"],
        }
        self.assertNotIn("shared", _graph_asset_tokens(left) | _graph_asset_tokens(right))
        self.assertEqual(_graph_asset_tokens(left) & _graph_asset_tokens(right), set())

    def test_invalid_catalog_rejects_duplicate_ids_paths_and_stale_hashes(self) -> None:
        duplicate = {"schema": "albert.assets.v1", "release": "test-1", "assets": [_synthetic_asset("asset.one"), _synthetic_asset("asset.one")], "edges": []}
        with patch("toolkit._read_json", return_value=duplicate):
            with self.assertRaisesRegex(CatalogError, "duplicate asset id"):
                Catalog.load(HERE / "toolkit.py")
        direct = Catalog(root=HERE, release="test", assets=(), edges=())
        with self.assertRaisesRegex(CatalogError, "escapes package"):
            direct._verified_path({"path": "../escape.md", "sha256": "0" * 64})
        with self.assertRaisesRegex(CatalogError, "digest is stale"):
            direct._verified_path({"path": "toolkit.py", "sha256": "0" * 64})
        expected = b"first-read-only"
        with patch("pathlib.Path.read_bytes", side_effect=[expected, b"changed-after-verification"]) as reads:
            _path, content = direct._verified_bytes({"path": "toolkit.py", "sha256": hashlib.sha256(expected).hexdigest()})
        self.assertEqual(content, expected)
        self.assertEqual(reads.call_count, 1, "returned bytes must be the bytes that were hashed")
        too_long = {"schema": "albert.assets.v1", "release": "test-1", "assets": [_synthetic_asset("a" * 121)], "edges": []}
        with patch("toolkit._read_json", return_value=too_long):
            with self.assertRaisesRegex(CatalogError, "metadata-id"):
                Catalog.load(HERE / "toolkit.py")

    def test_dispatch_rejects_case_like_discovery_input_and_defaults_to_null_dad(self) -> None:
        _catalog_or_skip(self)
        self.assertEqual(dispatch("DADStatus", {}, catalog_path=CATALOG_PATH, dad_provider=NullDADProvider())["state"], "unavailable")
        self.assertEqual(dispatch("SearchDiscoveryPatterns", {"topic": "mcp"}, catalog_path=CATALOG_PATH, dad_provider=NullDADProvider())["diagnostic_code"], "dad_discovery_disabled")
        with self.assertRaisesRegex(CatalogError, "approved generic"):
            dispatch("SearchDiscoveryPatterns", {"topic": "case plaintiff statement"}, catalog_path=CATALOG_PATH, dad_provider=NullDADProvider())
        with self.assertRaisesRegex(CatalogError, "unknown read-only"):
            dispatch("SaveCandidate", {}, catalog_path=CATALOG_PATH, dad_provider=NullDADProvider())

    def test_discovery_dispatch_issues_one_provider_call_per_request(self) -> None:
        _catalog_or_skip(self)
        class CountingProvider:
            calls = 0
            def status(self): return {"state": "available"}
            def search(self, topic):
                self.calls += 1
                return {"state": "available", "topic": topic, "records": []}
        provider = CountingProvider()
        result = dispatch("SearchDiscoveryPatterns", {"topic": "mcp"}, catalog_path=CATALOG_PATH, dad_provider=provider)
        self.assertEqual(result["topic"], "mcp")
        self.assertEqual(provider.calls, 1)

    def test_dad_malformed_type_returns_unavailable(self) -> None:
        self.assertEqual(LocalDADStdioProvider._handshake([], {}), "dad_malformed_response")
        self.assertEqual(LocalDADStdioProvider._handshake({"protocolVersion": "2025-06-18", "serverInfo": {}}, {"tools": []}), "dad_capability_drift")

    def test_dad_search_refuses_stale_and_projects_fresh_typed_metadata(self) -> None:
        provider = LocalDADStdioProvider(HERE / "toolkit.py", HERE, timeout_seconds=1)
        fresh = {
            "schema_version": "dad.mcp.graph_search_nodes.v1", "review_status": "candidate", "surface_id": "lesson-graph",
            "result_count": 1, "results": [{"node_id": "lesson:one", "node_type": "lesson", "label": "MCP review"}],
            "surface_freshness": {"state": "fresh", "body_exists": True, "manifest_exists": True, "body_hash": "sha256:" + "a" * 64, "manifest_hash": "sha256:" + "b" * 64},
        }
        with patch.object(provider, "_exchange", return_value=(fresh, None)):
            result = provider.search("mcp")
        self.assertEqual(result["state"], "available")
        self.assertEqual(result["records"][0]["node_type"], "lesson")
        self.assertEqual(result["provenance"]["body_hash"], "sha256:" + "a" * 64)
        fresh["surface_freshness"]["state"] = "stale"
        with patch.object(provider, "_exchange", return_value=(fresh, None)):
            self.assertEqual(provider.search("mcp")["diagnostic_code"], "dad_surface_stale")


try:
    import httpx
    import uvicorn
    from mcp.client.session import ClientSession
    from mcp.client.streamable_http import streamable_http_client
    from server import create_app
    HAS_SERVICE = True
except ImportError:
    HAS_SERVICE = False


@unittest.skipUnless(HAS_SERVICE, "optional MCP SDK and Starlette are not installed")
class ServiceRuntimeTests(unittest.IsolatedAsyncioTestCase):
    async def test_api_and_mcp_use_same_dispatcher(self) -> None:
        catalog = _catalog_or_skip(self)
        asset = catalog.assets[0]
        app = create_app(catalog_path=CATALOG_PATH, provider=NullDADProvider())
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            api = await client.post("/api/tools/SearchAssets", json={"query": asset["id"], "limit": 3})
            api_bad_bool = await client.post("/api/tools/SearchAssets", json={"query": asset["id"], "limit": True})
            api_bad_string = await client.post("/api/tools/SearchAssets", json={"query": asset["id"], "limit": "3"})
        self.assertEqual(api.status_code, 200)
        self.assertEqual(api_bad_bool.status_code, 400)
        self.assertEqual(api_bad_string.status_code, 400)
        self.assertTrue(api.json()["ok"])
        self.assertEqual(api.json()["result"], dispatch("SearchAssets", {"query": asset["id"], "limit": 3}, catalog_path=CATALOG_PATH, dad_provider=NullDADProvider()))

        sock = socket.socket()
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        sock.close()
        server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="critical"))
        thread = threading.Thread(target=server.run, daemon=True)
        thread.start()
        try:
            for _ in range(50):
                if server.started:
                    break
                await asyncio.sleep(0.05)
            self.assertTrue(server.started, "local Streamable HTTP server did not start")
            async with streamable_http_client(f"http://127.0.0.1:{port}/mcp") as (read, write, _):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    tools = await session.list_tools()
                    self.assertEqual({tool.name for tool in tools.tools}, {"SearchAssets", "GetAsset", "GetNeighbors", "GetAssetContent", "SearchDiscoveryPatterns", "DADStatus"})
                    result = await session.call_tool("SearchAssets", {"query": asset["id"], "limit": 3})
                    self.assertFalse(result.isError)
                    for malformed in (True, "3"):
                        rejected = await session.call_tool("SearchAssets", {"query": asset["id"], "limit": malformed})
                        self.assertTrue(rejected.isError)
        finally:
            server.should_exit = True
            thread.join(timeout=5)

    async def test_network_gate_denies_and_authorizes_api_and_mcp_consistently(self) -> None:
        _catalog_or_skip(self)
        from unittest.mock import patch as env_patch
        environment = {
            "ALBERT_NETWORK_ENABLED": "true",
            "ALBERT_NETWORK_KEY": "test-key",
            "ALBERT_ALLOWED_HOSTS": "toolkit.example,toolkit.example:*",
            "ALBERT_ALLOWED_ORIGINS": "https://toolkit.example",
        }
        with env_patch.dict("os.environ", environment, clear=False):
            app = create_app(catalog_path=CATALOG_PATH, provider=NullDADProvider(), host="toolkit.example")
            transport = httpx.ASGITransport(app=app)
            async with httpx.AsyncClient(transport=transport, base_url="http://toolkit.example") as client:
                api_denied = await client.post("/api/tools/DADStatus", headers={"host": "toolkit.example"}, json={})
                mcp_denied = await client.post("/mcp", headers={"host": "toolkit.example", "content-type": "application/json"}, json={"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
                allowed_headers = {"host": "toolkit.example", "origin": "https://toolkit.example", "x-albert-key": "test-key", "content-type": "application/json", "accept": "application/json, text/event-stream"}
                api_allowed = await client.post("/api/tools/DADStatus", headers=allowed_headers, json={})
        sock = socket.socket()
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        sock.close()
        server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="critical"))
        thread = threading.Thread(target=server.run, daemon=True)
        thread.start()
        try:
            for _ in range(50):
                if server.started:
                    break
                await asyncio.sleep(0.05)
            async with httpx.AsyncClient(base_url=f"http://127.0.0.1:{port}") as client:
                mcp_allowed = await client.post("/mcp", headers=allowed_headers, json={"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "test", "version": "1"}}})
        finally:
            server.should_exit = True
            thread.join(timeout=5)
        self.assertEqual(api_denied.status_code, 403)
        self.assertEqual(mcp_denied.status_code, 403)
        self.assertEqual(api_allowed.status_code, 200)
        self.assertNotEqual(mcp_allowed.status_code, 403)


if __name__ == "__main__":
    unittest.main(verbosity=2)
