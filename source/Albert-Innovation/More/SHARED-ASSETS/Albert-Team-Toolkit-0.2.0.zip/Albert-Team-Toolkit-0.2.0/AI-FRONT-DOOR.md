# Team asset entrypoint

Start [README](README.md), then [ASSET-INDEX](ASSET-INDEX.md). Search metadata before creating another asset. Existing DAD donor snapshots are reference material; the adapted skill/role files are the runnable prompts. Treat catalog graph links as discovery, not execution permission.

For subagent instruction/output review: [WF04](flows/WF04-subagent-improvement.md), [A01](agents/A01-subagent-improver.md), [T04](templates/T04-subagent-review.md). For rich podcast writing/reference comparison: [WF05](flows/WF05-conversational-podcast.md), [P06](prompts/P06-conversational-podcast-writer.md), [A02](agents/A02-podcast-conversation-reviewer.md), [T05](templates/T05-podcast-review.md). Model bindings and storage/setup: [REVIEWER-ADAPTERS](REVIEWER-ADAPTERS.md).

Keep each case's source, permissions and witness boundaries authoritative. Generic reusable lessons must be deidentified. Use P01 for source evidence, P03 for independent verification, P05 for causal diagnosis, and WF02 for candidate learning records. Do not auto-adopt or let a style grade override factual failure. This release is a local candidate; see QA before use.
