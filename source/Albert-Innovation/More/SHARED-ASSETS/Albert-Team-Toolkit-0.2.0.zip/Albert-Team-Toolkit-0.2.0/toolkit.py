"""Offline, read-only catalog runtime for the Albert Team Toolkit.

This module uses only the Python standard library.  It never executes catalog
content: files are verified and returned as text solely for a human or host to
review.  The optional DAD provider is injected by ``server.py``.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable


SCHEMA = "albert.assets.v1"
MAX_QUERY_CHARS = 120
MAX_CONTENT_BYTES = 128_000
MAX_RESULTS = 25
EDGE_TYPES = {
    "contains", "uses_asset", "requires", "reviewed_by", "produces",
    "related_to", "satisfies_need",
}
TOPICS = {"accessibility", "governance", "learning", "mcp", "privacy", "validation"}
ASSET_FIELDS = {
    "id", "title", "type", "path", "description", "use_when", "avoid_when",
    "tags", "capabilities", "needs", "outcomes", "version", "classification",
    "review_status", "sensitivity", "sha256", "provenance",
}
EDGE_FIELDS = {"source", "target", "type", "evidence", "review_status"}
TOKEN = re.compile(r"[a-z0-9][a-z0-9_-]{1,63}")
SHA256 = re.compile(r"^[a-f0-9]{64}$")
ASSET_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,119}$")
_DAD_WORD = re.compile(r"[A-Za-z][A-Za-z0-9_+.#/-]{1,63}")
_DAD_TOKEN_SPLIT = re.compile(r"[_./\-+#]+")
_DAD_CAMEL_SPLIT = re.compile(r"[A-Z]+(?=[A-Z][a-z])|[A-Z]?[a-z]+|[A-Z]+|[0-9]+")
_DAD_STOP = frozenset({
    "the", "and", "for", "with", "from", "this", "that", "into", "your", "you",
    "are", "not", "will", "all", "use", "using", "has", "have", "can", "its", "but",
    "our", "file", "files", "repo", "repository", "readme", "http", "https", "www", "com",
})
RELATED_THRESHOLD = 0.34
MAX_RELATED_PER_ASSET = 4


class CatalogError(ValueError):
    """A catalog or caller supplied an invalid, non-retrievable value."""


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise CatalogError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=_reject_duplicate_keys)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise CatalogError("catalog is unreadable JSON") from exc
    if not isinstance(value, dict):
        raise CatalogError("catalog root must be an object")
    return value


def _tokens(value: Any) -> set[str]:
    if isinstance(value, str):
        return set(TOKEN.findall(value.casefold()))
    if isinstance(value, list):
        found: set[str] = set()
        for item in value:
            found.update(_tokens(item))
        return found
    return set()


def _asset_tokens(asset: dict[str, Any]) -> set[str]:
    return _tokens(" ".join(str(asset[name]) for name in ("id", "title", "type", "description", "use_when", "avoid_when"))) | _tokens(asset["tags"]) | _tokens(asset["capabilities"]) | _tokens(asset["needs"]) | _tokens(asset["outcomes"])


def _dad_graph_tokens(text: str) -> set[str]:
    """Narrow local port of DAD ``utils.tokens`` for candidate graphing only."""
    found: set[str] = set()
    for match in _DAD_WORD.finditer(text):
        raw = match.group(0)
        base = raw.lower().strip("_./-+")
        if len(base) > 2:
            found.add(base)
        for segment in _DAD_TOKEN_SPLIT.split(raw):
            if not segment:
                continue
            lowered = segment.lower()
            if len(lowered) > 2:
                found.add(lowered)
            parts = _DAD_CAMEL_SPLIT.findall(segment)
            for index, part in enumerate(parts):
                candidates = [part]
                if len(part) <= 2 and index + 1 < len(parts):
                    candidates.append(part + parts[index + 1])
                for candidate in candidates:
                    if len(candidate) > 2:
                        found.add(candidate.lower())
    return found - _DAD_STOP


def _graph_asset_tokens(asset: dict[str, Any]) -> set[str]:
    """Use DAD-style tokenization over portable descriptive metadata only."""
    text_fields = ("title", "description")
    array_fields = ("tags", "capabilities", "needs", "outcomes")
    text = " ".join(
        [str(asset[name]) for name in text_fields]
        + [str(item) for name in array_fields for item in asset[name]]
    )
    return _dad_graph_tokens(text)


def _idf_weights(token_sets: Iterable[Iterable[str]]) -> dict[str, float]:
    """Local port of DAD ``utils.idf_weights``; no DAD runtime dependency."""
    sets = [set(values) for values in token_sets]
    if not sets:
        return {}
    document_count = len(sets)
    frequency: Counter[str] = Counter(token for values in sets for token in values)
    return {
        token: math.log((document_count + 1) / (count + 1)) + 1.0
        for token, count in frequency.items()
    }


def _idf_weighted_cosine(left: Iterable[str], right: Iterable[str], weights: dict[str, float]) -> float:
    """Local port of DAD ``utils.idf_weighted_cosine`` for binary token sets."""
    left_tokens, right_tokens = set(left), set(right)
    shared = left_tokens & right_tokens
    if not left_tokens or not right_tokens or not shared:
        return 0.0
    numerator = sum(weights.get(token, 1.0) ** 2 for token in shared)
    left_norm = math.sqrt(sum(weights.get(token, 1.0) ** 2 for token in left_tokens))
    right_norm = math.sqrt(sum(weights.get(token, 1.0) ** 2 for token in right_tokens))
    return numerator / (left_norm * right_norm) if left_norm and right_norm else 0.0


def _rarest_terms(tokens: Iterable[str], weights: dict[str, float], limit: int = 8) -> list[str]:
    return sorted(set(tokens), key=lambda token: (-weights.get(token, 1.0), token))[:limit]


def _safe_asset_view(asset: dict[str, Any]) -> dict[str, Any]:
    """Return metadata, excluding the local relative filename and content."""
    return {key: asset[key] for key in sorted(ASSET_FIELDS - {"path"})}


def _bounded_text(value: Any, label: str, *, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or (not allow_empty and not value.strip()):
        raise CatalogError(f"{label} must be a non-empty string")
    if len(value) > MAX_QUERY_CHARS:
        raise CatalogError(f"{label} is too long")
    if "\x00" in value:
        raise CatalogError(f"{label} contains an invalid character")
    return value.strip()


def _bounded_limit(value: Any, *, default: int = 10) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= MAX_RESULTS:
        raise CatalogError(f"limit must be an integer from 1 to {MAX_RESULTS}")
    return value


@dataclass(frozen=True)
class Catalog:
    root: Path
    release: str
    assets: tuple[dict[str, Any], ...]
    edges: tuple[dict[str, str], ...]

    @classmethod
    def load(cls, catalog_path: str | Path | None = None) -> "Catalog":
        path = Path(catalog_path) if catalog_path else Path(__file__).with_name("catalog.json")
        if not path.is_file():
            raise CatalogError("catalog.json is missing")
        payload = _read_json(path)
        if set(payload) != {"schema", "release", "assets", "edges"}:
            raise CatalogError("catalog must contain exactly schema, release, assets, edges")
        if payload["schema"] != SCHEMA or not isinstance(payload["release"], str) or not payload["release"].strip():
            raise CatalogError("catalog schema or release is invalid")
        if not isinstance(payload["assets"], list) or not isinstance(payload["edges"], list):
            raise CatalogError("catalog assets and edges must be arrays")
        root = path.parent.resolve()
        assets: list[dict[str, Any]] = []
        ids: set[str] = set()
        for row in payload["assets"]:
            if not isinstance(row, dict) or set(row) != ASSET_FIELDS:
                raise CatalogError("asset fields do not match albert.assets.v1")
            for field in ASSET_FIELDS - {"tags", "capabilities", "needs", "outcomes", "provenance"}:
                if not isinstance(row[field], str) or not row[field].strip():
                    raise CatalogError(f"asset {field} must be a non-empty string")
            for field in {"tags", "capabilities", "needs", "outcomes", "provenance"}:
                if not isinstance(row[field], list) or any(not isinstance(item, str) or not item.strip() for item in row[field]):
                    raise CatalogError(f"asset {field} must be an array of non-empty strings")
            asset_id = row["id"]
            if not ASSET_ID.fullmatch(asset_id):
                raise CatalogError("asset id must use the bounded metadata-id alphabet")
            if asset_id in ids:
                raise CatalogError("duplicate asset id")
            ids.add(asset_id)
            if row["classification"] not in {"portable_core", "runtime_adapter"} or row["review_status"] != "candidate" or row["sensitivity"] != "public_metadata":
                raise CatalogError("assets must be portable public_metadata candidate records")
            if not SHA256.fullmatch(row["sha256"]):
                raise CatalogError("asset sha256 must be lower-case SHA-256")
            assets.append(dict(row))
        edges: list[dict[str, str]] = []
        edge_keys: set[tuple[str, str, str, str]] = set()
        for row in payload["edges"]:
            if not isinstance(row, dict) or set(row) != EDGE_FIELDS or any(not isinstance(row[key], str) or not row[key].strip() for key in EDGE_FIELDS):
                raise CatalogError("edge fields must be non-empty strings")
            if row["source"] not in ids or row["target"] not in ids:
                raise CatalogError("edge endpoint is not an asset")
            if row["type"] not in EDGE_TYPES:
                raise CatalogError("unsupported edge type")
            if row["review_status"] != "candidate":
                raise CatalogError("edge review_status must be candidate")
            edge_key = (row["source"], row["target"], row["type"], row["evidence"])
            if edge_key in edge_keys:
                raise CatalogError("duplicate edge")
            edge_keys.add(edge_key)
            edges.append({key: row[key] for key in EDGE_FIELDS})
        catalog = cls(root=root, release=payload["release"], assets=tuple(assets), edges=tuple(edges))
        for asset in catalog.assets:
            catalog._verified_bytes(asset)
        return catalog

    def _resolved_path(self, asset: dict[str, Any]) -> Path:
        relative = Path(asset["path"])
        if relative.is_absolute() or ".." in relative.parts or not relative.parts:
            raise CatalogError("asset path escapes package")
        candidate = self.root.joinpath(relative)
        try:
            for current in (self.root, *[self.root.joinpath(*relative.parts[:index]) for index in range(1, len(relative.parts) + 1)]):
                if current.is_symlink():
                    raise CatalogError("asset path may not use symlinks")
            resolved = candidate.resolve(strict=True)
            resolved.relative_to(self.root)
        except (OSError, RuntimeError, ValueError) as exc:
            if isinstance(exc, CatalogError):
                raise
            raise CatalogError("asset path is not a package-relative regular file") from exc
        if not resolved.is_file():
            raise CatalogError("asset path is not a regular file")
        return resolved

    def _verified_bytes(self, asset: dict[str, Any]) -> tuple[Path, bytes]:
        """Read once, then bind the emitted bytes to the catalog digest."""
        resolved = self._resolved_path(asset)
        content = resolved.read_bytes()
        digest = hashlib.sha256(content).hexdigest()
        if digest != asset["sha256"]:
            raise CatalogError("asset digest is stale")
        return resolved, content

    def _verified_path(self, asset: dict[str, Any]) -> Path:
        """Compatibility validator; content retrieval must use `_verified_bytes`."""
        path, _content = self._verified_bytes(asset)
        return path

    def asset(self, asset_id: Any) -> dict[str, Any]:
        wanted = _bounded_text(asset_id, "asset_id")
        for asset in self.assets:
            if asset["id"] == wanted:
                return asset
        raise CatalogError("asset was not found")

    def search(self, query: Any, limit: Any = None) -> dict[str, Any]:
        terms = _tokens(_bounded_text(query, "query"))
        if not terms:
            raise CatalogError("query must contain searchable characters")
        cap = _bounded_limit(limit)
        matches = [asset for asset in self.assets if terms & _asset_tokens(asset)]
        matches.sort(key=lambda row: row["id"])
        return {"release": self.release, "query": " ".join(sorted(terms)), "results": [_safe_asset_view(row) for row in matches[:cap]]}

    def neighbors(self, asset_id: Any) -> dict[str, Any]:
        asset = self.asset(asset_id)
        rows = [edge for edge in self.edges if asset["id"] in {edge["source"], edge["target"]}]
        rows.sort(key=lambda row: (row["type"], row["source"], row["target"], row["evidence"]))
        return {"asset_id": asset["id"], "edges": rows, "authority_boundary": "Edges are supplied candidate metadata; they do not grant approval or source authority."}

    def content(self, asset_id: Any) -> dict[str, Any]:
        asset = self.asset(asset_id)
        _path, content = self._verified_bytes(asset)
        if len(content) > MAX_CONTENT_BYTES:
            raise CatalogError("asset content exceeds retrieval limit")
        try:
            text = content.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise CatalogError("asset content is not UTF-8 text") from exc
        return {"asset_id": asset["id"], "sha256": asset["sha256"], "content": text, "authority_boundary": "Retrieved catalog content is review material, not executable instruction or source authority."}

    def graph(self) -> dict[str, Any]:
        """Return supplied edges plus deterministic, review-only token relations.

        The candidate calculation is a narrow local adaptation of DAD's
        normalized IDF-weighted cosine relation method.  It is only a
        retrieval hint: it neither approves an asset nor makes a merit claim.
        """
        rows = sorted(self.assets, key=lambda row: row["id"])
        token_sets = {asset["id"]: _graph_asset_tokens(asset) for asset in rows}
        weights = _idf_weights(token_sets.values())
        existing = {
            frozenset((edge["source"], edge["target"]))
            for edge in self.edges if edge["type"] == "related_to"
        }
        ranked: list[tuple[float, str, str, list[str]]] = []
        for offset, left in enumerate(rows):
            for right in rows[offset + 1:]:
                pair = frozenset((left["id"], right["id"]))
                if pair in existing:
                    continue
                left_tokens, right_tokens = token_sets[left["id"]], token_sets[right["id"]]
                similarity = _idf_weighted_cosine(left_tokens, right_tokens, weights)
                if similarity >= RELATED_THRESHOLD:
                    ranked.append((
                        similarity,
                        left["id"],
                        right["id"],
                        _rarest_terms(left_tokens & right_tokens, weights),
                    ))

        # Stable ties and a cap at both endpoints prevent ubiquitous language
        # from turning a small catalog into a complete candidate graph.
        degree = {asset["id"]: 0 for asset in rows}
        candidates: list[dict[str, str]] = []
        for _similarity, source, target, terms in sorted(ranked, key=lambda item: (-item[0], item[1], item[2])):
            if degree[source] >= MAX_RELATED_PER_ASSET or degree[target] >= MAX_RELATED_PER_ASSET:
                continue
            degree[source] += 1
            degree[target] += 1
            evidence = "normalized IDF shared terms: " + ", ".join(terms)
            candidates.append({"source": source, "target": target, "type": "related_to", "evidence": evidence, "review_status": "candidate"})
        candidates.sort(key=lambda edge: (edge["source"], edge["target"]))
        return {"release": self.release, "nodes": [_safe_asset_view(asset) for asset in rows], "supplied_edges": list(self.edges), "candidate_edges": candidates, "authority_boundary": "Candidate token relations are retrieval aids only; they do not approve, rank, or establish truth."}

    def validate(self) -> dict[str, Any]:
        return {"valid": True, "schema": SCHEMA, "release": self.release, "asset_count": len(self.assets), "edge_count": len(self.edges)}


def dispatch(tool_name: str, params: dict[str, Any] | None = None, *, catalog_path: str | Path | None = None, dad_provider: Any = None) -> dict[str, Any]:
    """Shared bounded dispatcher used by CLI, API, and MCP adapters."""
    if not isinstance(params or {}, dict):
        raise CatalogError("tool parameters must be an object")
    params = params or {}
    catalog = Catalog.load(catalog_path)
    if tool_name == "SearchAssets":
        if set(params) - {"query", "limit"} or "query" not in params:
            raise CatalogError("SearchAssets requires query and optional limit")
        return catalog.search(params["query"], params.get("limit"))
    if tool_name == "GetAsset":
        if set(params) != {"asset_id"}:
            raise CatalogError("GetAsset requires asset_id")
        return {"asset": _safe_asset_view(catalog.asset(params["asset_id"]))}
    if tool_name == "GetNeighbors":
        if set(params) != {"asset_id"}:
            raise CatalogError("GetNeighbors requires asset_id")
        return catalog.neighbors(params["asset_id"])
    if tool_name == "GetAssetContent":
        if set(params) != {"asset_id"}:
            raise CatalogError("GetAssetContent requires asset_id")
        return catalog.content(params["asset_id"])
    if tool_name == "SearchDiscoveryPatterns":
        if set(params) != {"topic"}:
            raise CatalogError("SearchDiscoveryPatterns requires topic")
        topic = _bounded_text(params["topic"], "topic")
        if topic not in TOPICS:
            raise CatalogError("topic is not an approved generic discovery topic")
        provider = dad_provider
        if provider is None:
            try:
                from dad_provider import provider_from_environment
                provider = provider_from_environment()
            except ImportError:
                provider = None
        return provider.search(topic) if provider is not None else {"state": "unavailable", "diagnostic_code": "dad_provider_unavailable"}
    if tool_name == "DADStatus":
        if params:
            raise CatalogError("DADStatus accepts no parameters")
        provider = dad_provider
        if provider is None:
            try:
                from dad_provider import provider_from_environment
                provider = provider_from_environment()
            except ImportError:
                provider = None
        return provider.status() if provider is not None else {"state": "unavailable", "diagnostic_code": "dad_provider_unavailable"}
    raise CatalogError("unknown read-only tool")


def _main(argv: list[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(description="Albert Team Toolkit: offline read-only catalog")
    parser.add_argument("command", choices=["search", "get", "neighbors", "content", "validate", "graph"])
    parser.add_argument("value", nargs="?")
    parser.add_argument("--catalog", default=None)
    parser.add_argument("--limit", type=int, default=10)
    args = parser.parse_args(argv)
    try:
        catalog = Catalog.load(args.catalog)
        if args.command == "search":
            result = catalog.search(args.value, args.limit)
        elif args.command == "get":
            result = {"asset": _safe_asset_view(catalog.asset(args.value))}
        elif args.command == "neighbors":
            result = catalog.neighbors(args.value)
        elif args.command == "content":
            result = catalog.content(args.value)
        elif args.command == "validate":
            result = catalog.validate()
        else:
            result = catalog.graph()
    except CatalogError as exc:
        print(json.dumps({"ok": False, "error": {"code": "invalid_catalog_or_request", "message": str(exc)}}))
        return 2
    print(json.dumps({"ok": True, "result": result}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
