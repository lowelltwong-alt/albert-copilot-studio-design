"""Opt-in, read-only broker for DAD's local stdio MCP server.

No Albert case parameters are accepted here.  The only query input is the
closed generic topic enum owned by ``toolkit.py``.
"""

from __future__ import annotations

import json
import os
import queue
import re
import subprocess
import threading
from pathlib import Path
from typing import Any


REQUIRED_DAD_TOOLS = frozenset({
    "dad_graph_surface_status", "dad_graph_get_node", "dad_graph_neighbors", "dad_graph_search_nodes",
})
TOPIC_TERMS = {"accessibility": "accessibility", "governance": "governance", "learning": "learning", "mcp": "mcp", "privacy": "privacy", "validation": "validation"}
PRIVATE_TEXT = re.compile(r"(?:[A-Za-z]:[\\/]|\\\\|file://|authorization|api[_-]?key|password|secret|private[_ -]?(?:source|data|payload)|token\s*[:=])", re.IGNORECASE)
MCP_PROTOCOL_VERSION = "2025-06-18"
SHA256_REF = re.compile(r"^sha256:[a-f0-9]{64}$")
ALBERT_BOUNDARY = "Optional DAD discovery is candidate-only metadata and never Albert case evidence or authority."


def _unavailable(code: str) -> dict[str, Any]:
    return {"state": "unavailable", "diagnostic_code": code, "authority_boundary": ALBERT_BOUNDARY}


class NullDADProvider:
    def status(self) -> dict[str, Any]:
        return _unavailable("dad_discovery_disabled")

    def search(self, topic: str) -> dict[str, Any]:
        return _unavailable("dad_discovery_disabled")


class LocalDADStdioProvider:
    """One-request stdio session with fixed executable and DAD root.

    The process is launched without a shell.  Each call sends initialize,
    tools/list, then a single permitted tool request and closes stdin.
    """

    def __init__(self, executable: str | Path, hub_root: str | Path, *, timeout_seconds: float = 3.0) -> None:
        self.executable = Path(executable)
        self.hub_root = Path(hub_root)
        self.timeout_seconds = timeout_seconds

    def _configuration_error(self) -> str | None:
        if not self.executable.is_absolute() or not self.executable.is_file():
            return "dad_executable_not_pinned"
        if not self.hub_root.is_absolute() or not self.hub_root.is_dir() or not (self.hub_root / "AGENTS.md").is_file():
            return "dad_root_not_initialized"
        if not isinstance(self.timeout_seconds, (float, int)) or not 0.1 <= self.timeout_seconds <= 10:
            return "dad_timeout_invalid"
        return None

    def _read_line(self, process: subprocess.Popen[str]) -> str | None:
        """Bound one response wait without exposing stderr or leaving a server alive."""
        result: queue.Queue[str] = queue.Queue(maxsize=1)
        thread = threading.Thread(target=lambda: result.put(process.stdout.readline()), daemon=True)
        thread.start()
        try:
            line = result.get(timeout=float(self.timeout_seconds))
        except queue.Empty:
            return None
        return line.strip() or None

    @staticmethod
    def _response(line: str | None, expected_id: int) -> tuple[dict[str, Any] | None, str | None]:
        if line is None:
            return None, "dad_transport_unavailable"
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            return None, "dad_malformed_response"
        if not isinstance(row, dict) or row.get("jsonrpc") != "2.0" or row.get("id") != expected_id:
            return None, "dad_malformed_response"
        if "error" in row:
            return None, "dad_request_rejected"
        result = row.get("result")
        if not isinstance(result, dict):
            return None, "dad_malformed_response"
        return result, None

    @staticmethod
    def _handshake(init: dict[str, Any], tool_result: dict[str, Any]) -> str | None:
        if not isinstance(init, dict) or not isinstance(tool_result, dict):
            return "dad_malformed_response"
        server_info = init.get("serverInfo")
        tools = tool_result.get("tools")
        if not isinstance(server_info, dict) or not isinstance(tools, list):
            return "dad_malformed_response"
        if init.get("protocolVersion") != MCP_PROTOCOL_VERSION or server_info.get("name") != "dad-local-graph-surfaces":
            return "dad_capability_drift"
        names = {row.get("name") for row in tools if isinstance(row, dict)}
        return None if REQUIRED_DAD_TOOLS.issubset(names) else "dad_capability_drift"

    def _exchange(self, method: str, params: dict[str, Any]) -> tuple[dict[str, Any] | None, str | None]:
        error = self._configuration_error()
        if error:
            return None, error
        command = [str(self.executable), "-B", "-m", "digital_asset_directory.cli", "mcp", "graph-stdio", "--hub", str(self.hub_root)]
        try:
            process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, shell=False)
        except OSError:
            return None, "dad_transport_unavailable"
        try:
            assert process.stdin is not None
            for request, request_id in (({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": MCP_PROTOCOL_VERSION, "capabilities": {}, "clientInfo": {"name": "albert-team-toolkit", "version": "0.1.0"}}}, 1),):
                process.stdin.write(json.dumps(request, separators=(",", ":")) + "\n")
                process.stdin.flush()
                init, issue = self._response(self._read_line(process), request_id)
                if issue:
                    return None, issue
            process.stdin.write(json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}}, separators=(",", ":")) + "\n")
            process.stdin.write(json.dumps({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}, separators=(",", ":")) + "\n")
            process.stdin.flush()
            tool_result, issue = self._response(self._read_line(process), 2)
            if issue:
                return None, issue
            issue = self._handshake(init, tool_result)
            if issue:
                return None, issue
            process.stdin.write(json.dumps({"jsonrpc": "2.0", "id": 3, "method": method, "params": params}, separators=(",", ":")) + "\n")
            process.stdin.flush()
            call_result, issue = self._response(self._read_line(process), 3)
            if issue:
                return None, issue
            payload = call_result.get("structuredContent")
        except (OSError, ValueError):
            return None, "dad_transport_unavailable"
        finally:
            if process.stdin is not None:
                try:
                    process.stdin.close()
                except OSError:
                    pass
            try:
                process.terminate()
            except OSError:
                pass
            try:
                process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                process.kill()
        # Never forward this response.  Search() projects a tiny field allowlist
        # below, so a harmless DAD explanatory string cannot make the transport
        # unusable while path/credential-like projected fields still fail closed.
        if not isinstance(payload, dict):
            return None, "dad_response_rejected"
        return payload, None

    def status(self) -> dict[str, Any]:
        payload, error = self._exchange("tools/call", {"name": "dad_graph_surface_status", "arguments": {}})
        if error:
            return _unavailable(error)
        return {"state": "available", "source": "dad-local-graph-surfaces", "authority_boundary": ALBERT_BOUNDARY, "diagnostic_code": "dad_read_only"}

    def search(self, topic: str) -> dict[str, Any]:
        term = TOPIC_TERMS.get(topic)
        if term is None:
            return _unavailable("dad_topic_rejected")
        payload, error = self._exchange("tools/call", {"name": "dad_graph_search_nodes", "arguments": {"surface_id": "lesson-graph", "query": term, "limit": 10}})
        if error:
            return _unavailable(error)
        freshness = payload.get("surface_freshness")
        if (payload.get("schema_version") != "dad.mcp.graph_search_nodes.v1" or payload.get("review_status") != "candidate" or payload.get("surface_id") != "lesson-graph" or not isinstance(freshness, dict)):
            return _unavailable("dad_response_rejected")
        if freshness.get("state") != "fresh" or freshness.get("body_exists") is not True or freshness.get("manifest_exists") is not True or not isinstance(freshness.get("body_hash"), str) or not isinstance(freshness.get("manifest_hash"), str) or not SHA256_REF.fullmatch(freshness["body_hash"]) or not SHA256_REF.fullmatch(freshness["manifest_hash"]):
            return _unavailable("dad_surface_stale")
        raw = payload.get("results")
        if not isinstance(raw, list) or payload.get("result_count") != len(raw):
            return _unavailable("dad_response_rejected")
        records: list[dict[str, Any]] = []
        for item in raw[:10]:
            if not isinstance(item, dict):
                return _unavailable("dad_response_rejected")
            record: dict[str, Any] = {}
            for source, target in (("node_id", "id"), ("id", "id"), ("label", "label"), ("node_type", "node_type"), ("type", "node_type"), ("kind", "node_type")):
                value = item.get(source)
                if isinstance(value, str) and value and len(value) <= 200 and not PRIVATE_TEXT.search(value):
                    record.setdefault(target, value)
            if "id" in record:
                records.append(record)
        return {"state": "available", "topic": topic, "records": records, "provenance": {"source": "dad-local-graph-surfaces", "schema_version": payload["schema_version"], "surface_id": payload["surface_id"], "review_status": payload["review_status"], "body_hash": freshness["body_hash"], "manifest_hash": freshness["manifest_hash"]}, "authority_boundary": ALBERT_BOUNDARY, "diagnostic_code": "dad_read_only"}


def provider_from_environment() -> NullDADProvider | LocalDADStdioProvider:
    if os.environ.get("ALBERT_DAD_DISCOVERY", "disabled").casefold() != "enabled":
        return NullDADProvider()
    executable = os.environ.get("ALBERT_DAD_PYTHON")
    root = os.environ.get("ALBERT_DAD_ROOT")
    if not executable or not root:
        return NullDADProvider()
    try:
        # DAD's first local Python startup can take several seconds; ten seconds
        # remains bounded and avoids declaring a healthy cold start unavailable.
        timeout = float(os.environ.get("ALBERT_DAD_TIMEOUT_SECONDS", "10"))
    except ValueError:
        timeout = -1
    return LocalDADStdioProvider(executable, root, timeout_seconds=timeout)
