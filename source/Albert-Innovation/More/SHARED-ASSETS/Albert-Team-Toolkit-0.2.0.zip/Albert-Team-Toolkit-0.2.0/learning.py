"""Portable, metadata-only error-to-learning evaluator.

Adapted constraints (not code) from Digital-Assett-Directory's exception and
learning workflow.  See LEARNING-CONTRACT.md for provenance, limitations, and
the separate licensing decision required before distribution.

This module never persists records, runs commands from records, edits prompts,
imports DAD, accesses a network, or promotes a lesson.  It only evaluates one
operator-supplied JSON document and returns deterministic JSON data.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


SCHEMA_VERSION = "innovation.learning-input.v1"
MAX_SUMMARY = 600
MAX_TEXT = 240
MAX_LIST = 12
MAX_INPUT_BYTES = 65_536
ID_RE = re.compile(r"^[a-z][a-z0-9._-]{2,79}$")
REVISION_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
FORBIDDEN_TEXT = re.compile(
    r"(?i)(api[_-]?key|password|secret|token\s*[=:]|private[_ -]?key|"
    r"bearer\s+|-----begin|<think>|chain[ -]?of[ -]?thought|[a-z]:\\users\\)"
)


@dataclass(frozen=True)
class Finding:
    code: str
    path: str
    message: str
    severity: str = "error"

    def as_dict(self) -> dict[str, str]:
        return {
            "code": self.code,
            "path": self.path,
            "message": self.message,
            "severity": self.severity,
        }


def canonical_digest(value: Any) -> str:
    """Return a stable digest for JSON-compatible metadata."""
    canonical = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def stable_id(kind: str, fields: dict[str, Any]) -> str:
    """Return the canonical, scope-bound identity for a lifecycle record."""
    return f"innovation:{kind}:{canonical_digest(fields)[7:31]}"


def _expected_ids(event: dict[str, Any], fix: dict[str, Any], lesson: dict[str, Any], adoption: dict[str, Any]) -> dict[str, str]:
    event_id = stable_id(
        "event",
        {
            "source_id": event.get("source_id"),
            "event_type": event.get("event_type"),
            "artifact_revision": event.get("artifact_revision"),
            "error_fingerprint": event.get("error_fingerprint"),
        },
    )
    fix_id = stable_id(
        "fix",
        {
            "event_id": event_id,
            "decision": fix.get("decision"),
            "artifact_revision": fix.get("artifact_revision"),
            "fix_summary": fix.get("fix_summary"),
        },
    )
    candidate_id = stable_id(
        "lesson",
        {
            "event_id": event_id,
            "fix_id": fix_id,
            "artifact_revision": fix.get("artifact_revision"),
            "lesson_summary": lesson.get("lesson_summary"),
        },
    )
    adoption_id = stable_id(
        "adoption",
        {"candidate_id": candidate_id, "decision": adoption.get("decision"), "scope": adoption.get("scope")},
    )
    return {"event_id": event_id, "fix_id": fix_id, "candidate_id": candidate_id, "adoption_id": adoption_id}


def _add(findings: list[Finding], code: str, path: str, message: str, severity: str = "error") -> None:
    findings.append(Finding(code, path, message, severity))


def _is_object(value: Any) -> bool:
    return isinstance(value, dict)


def _check_text(findings: list[Finding], path: str, value: Any, *, required: bool = True, limit: int = MAX_TEXT) -> None:
    if not isinstance(value, str):
        if required:
            _add(findings, "field_type", path, "must be a string")
        return
    if required and not value.strip():
        _add(findings, "field_required", path, "must be nonblank")
    if len(value) > limit:
        _add(findings, "field_too_long", path, f"exceeds {limit} characters")
    if FORBIDDEN_TEXT.search(value):
        _add(findings, "unsafe_metadata", path, "contains secret-like, private-path, or hidden-reasoning-like text")


def _check_id(findings: list[Finding], path: str, value: Any) -> None:
    _check_text(findings, path, value, limit=80)
    if isinstance(value, str) and value and not ID_RE.fullmatch(value):
        _add(findings, "invalid_identity", path, "must be a lowercase operator identity, not a display name")


def _check_revision(findings: list[Finding], path: str, value: Any) -> None:
    _check_text(findings, path, value, limit=71)
    if isinstance(value, str) and value and not REVISION_RE.fullmatch(value):
        _add(findings, "invalid_revision", path, "must be sha256:<64 lowercase hex characters>")


def _check_string_list(findings: list[Finding], path: str, value: Any, *, minimum: int = 0) -> None:
    if not isinstance(value, list):
        _add(findings, "field_type", path, "must be an array")
        return
    if len(value) < minimum:
        _add(findings, "field_required", path, f"requires at least {minimum} item(s)")
    if len(value) > MAX_LIST:
        _add(findings, "list_too_long", path, f"allows at most {MAX_LIST} items")
    for index, item in enumerate(value):
        _check_text(findings, f"{path}[{index}]", item)


def _check_refs(findings: list[Finding], path: str, refs: Any, revision: Any) -> None:
    if not isinstance(refs, list):
        _add(findings, "field_type", path, "must be an array of metadata references")
        return
    if not refs:
        _add(findings, "field_required", path, "requires at least one exact-revision reference")
    if len(refs) > MAX_LIST:
        _add(findings, "list_too_long", path, f"allows at most {MAX_LIST} items")
    for index, ref in enumerate(refs):
        item_path = f"{path}[{index}]"
        if not _is_object(ref):
            _add(findings, "field_type", item_path, "must be an object")
            continue
        if set(ref) != {"ref_id", "artifact_revision", "status"}:
            _add(findings, "unknown_or_missing_ref_field", item_path, "requires exactly ref_id, artifact_revision, status")
        _check_text(findings, f"{item_path}.ref_id", ref.get("ref_id"))
        _check_revision(findings, f"{item_path}.artifact_revision", ref.get("artifact_revision"))
        if ref.get("artifact_revision") != revision:
            _add(findings, "stale_evidence_revision", f"{item_path}.artifact_revision", "must equal fix.artifact_revision")
        if ref.get("status") != "passed":
            _add(findings, "evidence_not_passed", f"{item_path}.status", "must be 'passed'")


def _check_exact_keys(findings: list[Finding], path: str, value: Any, required: set[str]) -> bool:
    if not _is_object(value):
        _add(findings, "field_type", path, "must be an object")
        return False
    actual = set(value)
    if actual != required:
        missing = sorted(required - actual)
        extra = sorted(actual - required)
        _add(findings, "unknown_or_missing_field", path, f"missing={missing}; extra={extra}")
    return True


def evaluate(document: Any) -> dict[str, Any]:
    """Evaluate one supplied record bundle and return ordered findings and state."""
    findings: list[Finding] = []
    expected_top = {"schema_version", "bundle_id", "classification", "event", "fix", "lesson_candidate", "adoption_decision"}
    if not _check_exact_keys(findings, "$", document, expected_top):
        return _result(findings, "rejected", {}, {})
    assert isinstance(document, dict)
    if document.get("schema_version") != SCHEMA_VERSION:
        _add(findings, "schema_version", "$.schema_version", f"must equal {SCHEMA_VERSION}")
    _check_id(findings, "$.bundle_id", document.get("bundle_id"))
    if document.get("classification") != "public_metadata":
        _add(findings, "unsafe_classification", "$.classification", "only public_metadata is accepted")

    event = document.get("event")
    fix = document.get("fix")
    lesson = document.get("lesson_candidate")
    adoption = document.get("adoption_decision")
    event_keys = {"event_id", "source_id", "event_type", "artifact_revision", "error_fingerprint", "safe_summary", "author_id", "classification"}
    fix_keys = {"fix_id", "event_id", "decision", "artifact_revision", "author_id", "checker_id", "fix_summary", "validation_refs", "regression_refs", "remaining_risks"}
    lesson_keys = {"candidate_id", "event_id", "fix_id", "artifact_revision", "author_id", "lesson_summary", "applies_when", "does_not_apply_when", "danger_if_misapplied", "prior_candidate_ids"}
    adoption_keys = {"adoption_id", "candidate_id", "decision", "human_approver_id", "scope", "decision_summary"}
    objects = (("$.event", event, event_keys), ("$.fix", fix, fix_keys), ("$.lesson_candidate", lesson, lesson_keys), ("$.adoption_decision", adoption, adoption_keys))
    if not all(_check_exact_keys(findings, path, value, keys) for path, value, keys in objects):
        return _result(findings, "rejected", {}, {})
    assert isinstance(event, dict) and isinstance(fix, dict) and isinstance(lesson, dict) and isinstance(adoption, dict)

    for prefix, record, identifiers, texts in (
        ("$.event", event, ("source_id", "author_id"), ("event_type", "error_fingerprint", "safe_summary")),
        ("$.fix", fix, ("author_id", "checker_id"), ("decision", "fix_summary")),
        ("$.lesson_candidate", lesson, ("author_id",), ("lesson_summary", "danger_if_misapplied")),
        ("$.adoption_decision", adoption, (), ("decision", "scope", "decision_summary")),
    ):
        for key in identifiers:
            _check_id(findings, f"{prefix}.{key}", record.get(key))
        for key in texts:
            _check_text(findings, f"{prefix}.{key}", record.get(key), limit=MAX_SUMMARY if key.endswith("summary") else MAX_TEXT)
    human_approver_id = adoption.get("human_approver_id")
    if not isinstance(human_approver_id, str):
        _add(findings, "field_type", "$.adoption_decision.human_approver_id", "must be a string; empty is allowed only before adoption")
    elif human_approver_id:
        _check_id(findings, "$.adoption_decision.human_approver_id", human_approver_id)
    for prefix, record in (("$.event", event), ("$.fix", fix), ("$.lesson_candidate", lesson)):
        _check_revision(findings, f"{prefix}.artifact_revision", record.get("artifact_revision"))

    if event.get("classification") != "public_metadata":
        _add(findings, "unsafe_classification", "$.event.classification", "only public_metadata is accepted")
    if fix.get("event_id") != event.get("event_id"):
        _add(findings, "broken_fix_event_link", "$.fix.event_id", "must reference event.event_id")
    if fix.get("decision") != "fixed":
        _add(findings, "false_fixed_claim", "$.fix.decision", "portable learning accepts only an explicit fixed decision")
    if fix.get("author_id") == fix.get("checker_id") and fix.get("author_id"):
        _add(findings, "author_checker_not_distinct", "$.fix.checker_id", "checker_id must differ from author_id; this does not prove human independence")
    _check_refs(findings, "$.fix.validation_refs", fix.get("validation_refs"), fix.get("artifact_revision"))
    _check_refs(findings, "$.fix.regression_refs", fix.get("regression_refs"), fix.get("artifact_revision"))
    _check_string_list(findings, "$.fix.remaining_risks", fix.get("remaining_risks"))
    _check_string_list(findings, "$.lesson_candidate.applies_when", lesson.get("applies_when"), minimum=1)
    _check_string_list(findings, "$.lesson_candidate.does_not_apply_when", lesson.get("does_not_apply_when"), minimum=1)
    _check_string_list(findings, "$.lesson_candidate.prior_candidate_ids", lesson.get("prior_candidate_ids"))
    if lesson.get("event_id") != event.get("event_id"):
        _add(findings, "broken_event_link", "$.lesson_candidate.event_id", "must reference event.event_id")
    if lesson.get("fix_id") != fix.get("fix_id"):
        _add(findings, "broken_fix_link", "$.lesson_candidate.fix_id", "must reference fix.fix_id")
    if lesson.get("artifact_revision") != fix.get("artifact_revision"):
        _add(findings, "stale_lesson_revision", "$.lesson_candidate.artifact_revision", "must equal fixed artifact revision")
    if adoption.get("candidate_id") != lesson.get("candidate_id"):
        _add(findings, "broken_candidate_link", "$.adoption_decision.candidate_id", "must reference lesson_candidate.candidate_id")
    adoption_decision = adoption.get("decision")
    if not isinstance(adoption_decision, str) or adoption_decision not in {"pending", "adopt", "reject"}:
        _add(findings, "invalid_adoption_decision", "$.adoption_decision.decision", "must be pending, adopt, or reject")
    if adoption_decision == "adopt" and (not isinstance(human_approver_id, str) or not human_approver_id.strip()):
        _add(findings, "adoption_requires_operator", "$.adoption_decision.human_approver_id", "adopt requires an operator-supplied human approver identity")

    expected = _expected_ids(event, fix, lesson, adoption)
    for key, path in (("event_id", "$.event.event_id"), ("fix_id", "$.fix.fix_id"), ("candidate_id", "$.lesson_candidate.candidate_id"), ("adoption_id", "$.adoption_decision.adoption_id")):
        supplied = {"event_id": event, "fix_id": fix, "candidate_id": lesson, "adoption_id": adoption}[key].get(key)
        if supplied != expected[key]:
            _add(findings, "unstable_identity", path, f"must equal canonical {expected[key]}")

    has_duplicates = bool(lesson.get("prior_candidate_ids"))
    valid = not any(item.severity == "error" for item in findings)
    if not valid:
        status = "rejected"
    elif has_duplicates:
        status = "needs_duplicate_review"
        _add(findings, "duplicate_learning_conservative_hold", "$.lesson_candidate.prior_candidate_ids", "prior candidates require a separate comparison; no adoption is eligible", "warning")
    elif adoption_decision == "adopt":
        status = "adoption_recorded_not_applied"
    elif adoption_decision == "reject":
        status = "candidate_rejected_by_operator"
    else:
        status = "candidate_record_valid_review_pending"
    return _result(findings, status, expected, {"adoption_eligibility": "unverified"})


def _result(findings: Iterable[Finding], status: str, identities: dict[str, str], controls: dict[str, Any]) -> dict[str, Any]:
    ordered = list(findings)
    return {
        "schema_version": "innovation.learning-evaluation.v1",
        "status": status,
        "valid": status not in {"rejected"},
        "findings": [item.as_dict() for item in ordered],
        "canonical_identities": identities,
        "controls": {"automatic_promotion": False, "persistence_performed": False, "execution_performed": False, "adoption_eligibility": "unverified", **controls},
        "authority_boundary": "Operator-supplied metadata is evaluated only. A distinct checker identity is required but does not prove independent human review. Adoption is not applied to prompts, registries, or any external system.",
    }


def load_json_strict(path: Path) -> Any:
    def reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON key: {key}")
            result[key] = value
        return result
    if path.stat().st_size > MAX_INPUT_BYTES:
        raise ValueError("input exceeds byte limit")

    def reject_nonfinite(_: str) -> None:
        raise ValueError("non-finite JSON values are not allowed")

    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle, object_pairs_hook=reject_duplicate_keys, parse_constant=reject_nonfinite)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Evaluate one portable Innovation learning bundle.")
    parser.add_argument("command", choices=("validate", "demo"))
    parser.add_argument("file", type=Path)
    args = parser.parse_args(argv)
    try:
        result = evaluate(load_json_strict(args.file))
    except (OSError, ValueError, json.JSONDecodeError):
        result = _result([Finding("input_error", "$", "input unavailable or invalid")], "rejected", {}, {})
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0 if result["status"] != "rejected" else 1


if __name__ == "__main__":
    raise SystemExit(main())
