# Prompt-only MVP candidate integration

This is an explicit W08 candidate replacement for the earlier short-drill generation choice. It does not change the full manual or connected profiles.

| Existing MVP responsibility | Candidate behavior / exact file |
|---|---|
| W00 intake / case identity / save checkpoint | Keep existing intake and source custody; add selected witness, audience, intended duration and permitted disclosure in the episode brief |
| W01–W04 sources, chunks/graph, conflicts, witness scope | Keep existing stages; original Markdown outranks derived graph. Store a separate author-context ledger and learner-permitted projection |
| W05 witness preparation | Apply P06 planning sections; save research, permitted claims, eight-chapter episode plan and ten-anchor card |
| W06 plan check | Apply P01 to actual sources, with a named test/delivery boundary |
| W08 script generation | Use [P06](prompts/P06-conversational-podcast-writer.md) instead of the old short-only MVP generation paragraph or COACH/EXAMINER-only format. Other source, truthfulness and storage safeguards remain. HOST_A/HOST_B are conversational hosts, not invented witness testimony |
| W06 script review | Add [A02](agents/A02-podcast-conversation-reviewer.md) / T05 reference comparison, retaining independent evidence/examination and existing quality criteria |
| W07 repair | One editor resolves verified findings, updates every dependent artifact and requests one full recheck |
| W09 export | Save speaker-labeled dialogue, measured timing/pauses, permitted source map and KC10 card; do not read source IDs or production directions aloud |
| Reusable improvement | A01 / WF04 audits instructions versus output and the graders; proposal only, with explicit adoption evidence |

Full [WF05](flows/WF05-conversational-podcast.md) lists exact CASE-Wxx filenames and inputs/outputs. This table is the operator binding, not an imported Copilot solution. In one-chat setups run stages sequentially and save/reopen each file; separate fresh reviewer conversations are preferred when available. No custom API, MCP, graph database or automatic subagent capability is required.

**Diagnostic mode used in the Msimoto test:** the user authorized internal testing of existing extracted text despite imperfect OCR. All outputs are diagnostic, knowledge boundaries provisional from the selected witness's own source. No human approval of evidence or actual witness delivery is inferred. Missing facts stop the affected claim, not all useful internal drafting. Production mode still requires the team's actual source/disclosure review.

The observed test runs P06 with saved Markdown and host subagents. It does not establish that every prior W-stage prompt or a Copilot tenant ran end-to-end. No-change full-profile snapshots remain the rollback until PROMOTION-GATE is satisfied.
