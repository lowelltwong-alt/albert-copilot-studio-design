# Choose the setup that fits

| Mode | Minimum setup | What runs | Persistent state |
|---|---|---|---|
| Manual prompts | Extract package; a model conversation | Open a skill or prompt, supply inputs, save output yourself | Operator-saved files in the authorized workspace |
| Local asset library | Python 3.11+ | Standard-library catalog search, graph, verified file retrieval and learning-record checks | Shipped immutable catalog; supplied learning records remain local |
| MCP + API companion | Python plus `requirements.txt` | Same asset dispatcher through Streamable HTTP and JSON API | Read-only asset library; no case-job database |
| Optional DAD discovery | Existing initialized DAD and configured local executable/root | Bounded generic metadata reads through a stdio broker | No case content or learning writes sent to DAD |

Role identities are stable; model IDs are runtime choices. For basic extraction choose an available economy model; for source-rich drafting/checking choose a capable balanced model; for an unresolved difficult review choose a stronger specialist. Bind the exact names actually available in the team's picker and record them with each attempt. User-reported GPT/Claude names have not been independently verified in the tenant. The current local experiment is not proof of cross-provider equivalence.

Copilot Studio manual execution does not install these files as persistent storage merely because they are pasted into chat. Save each checkpoint and artifact explicitly in an approved folder/SharePoint library when used. MCP reads the generic toolkit; it does not supply case persistence. The full connected Albert workflow still requires its separately specified backend.
