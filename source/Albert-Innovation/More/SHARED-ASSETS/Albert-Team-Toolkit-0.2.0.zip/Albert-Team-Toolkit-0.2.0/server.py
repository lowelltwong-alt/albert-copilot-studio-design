"""FastMCP and HTTP adapters for the same Albert Team Toolkit read dispatcher.

The app is loopback-only by default.  It contains no OAuth implementation and
does not claim tenant deployment readiness.
"""

from __future__ import annotations

import json
import os
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Annotated, Any

from pydantic import Field, StrictInt

from toolkit import CatalogError, dispatch


TOOL_NAMES = ("SearchAssets", "GetAsset", "GetNeighbors", "GetAssetContent", "SearchDiscoveryPatterns", "DADStatus")
LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}
StrictLimit = Annotated[StrictInt, Field(ge=1, le=25)]


def _network_settings(host: str) -> tuple[bool, str | None, set[str], set[str]]:
    network = host not in LOOPBACK_HOSTS
    if not network:
        return False, None, set(), set()
    if os.environ.get("ALBERT_NETWORK_ENABLED") != "true":
        raise RuntimeError("network deployment requires ALBERT_NETWORK_ENABLED=true")
    key = os.environ.get("ALBERT_NETWORK_KEY")
    hosts = {item.strip().casefold() for item in os.environ.get("ALBERT_ALLOWED_HOSTS", "").split(",") if item.strip()}
    origins = {item.strip() for item in os.environ.get("ALBERT_ALLOWED_ORIGINS", "").split(",") if item.strip()}
    if not key or not hosts or not origins:
        raise RuntimeError("network deployment requires key, allowed hosts, and allowed origins")
    return True, key, hosts, origins


def _host_is_allowed(host: str, allowed: set[str]) -> bool:
    normalized = host.casefold()
    return normalized in allowed or f"{normalized}:*" in allowed


def _run(tool_name: str, params: dict[str, Any], catalog_path: str | Path | None, provider: Any) -> dict[str, Any]:
    try:
        return {"ok": True, "tool": tool_name, "result": dispatch(tool_name, params, catalog_path=catalog_path, dad_provider=provider)}
    except CatalogError as exc:
        return {"ok": False, "tool": tool_name, "error": {"code": "invalid_request", "message": str(exc)}}


def create_mcp_server(*, catalog_path: str | Path | None = None, provider: Any = None, host: str = "127.0.0.1"):
    """Create an official Python MCP SDK FastMCP server with six bounded reads."""
    try:
        from mcp.server.fastmcp import FastMCP
        from mcp.server.transport_security import TransportSecuritySettings
        from starlette.requests import Request
        from starlette.responses import JSONResponse
    except ImportError as exc:  # Toolkit CLI remains usable without optional service dependencies.
        raise RuntimeError("MCP SDK and Starlette are required for server.py; set PYTHONPATH to the installed work directory") from exc

    network, _key, hosts, origins = _network_settings(host)
    transport_security = None
    if network:
        # Keep the SDK's own streamable-HTTP Host/Origin policy aligned with the
        # outer key gate; otherwise API and MCP could accept different callers.
        transport_security = TransportSecuritySettings(
            enable_dns_rebinding_protection=True,
            allowed_hosts=sorted(hosts),
            allowed_origins=sorted(origins),
        )
    mcp = FastMCP(
        "albert-team-toolkit",
        instructions="Read-only generic digital-asset companion. It never accepts case content or performs writes.",
        host=host,
        streamable_http_path="/mcp",
        stateless_http=True,
        json_response=True,
        transport_security=transport_security,
    )

    @mcp.tool(name="SearchAssets", description="Search local public-metadata catalog assets using a bounded generic query.")
    def search_assets(query: str, limit: StrictLimit = 10) -> dict[str, Any]:
        return _run("SearchAssets", {"query": query, "limit": limit}, catalog_path, provider)

    @mcp.tool(name="GetAsset", description="Read one local catalog asset's metadata.")
    def get_asset(asset_id: str) -> dict[str, Any]:
        return _run("GetAsset", {"asset_id": asset_id}, catalog_path, provider)

    @mcp.tool(name="GetNeighbors", description="Read supplied candidate metadata edges incident to an asset.")
    def get_neighbors(asset_id: str) -> dict[str, Any]:
        return _run("GetNeighbors", {"asset_id": asset_id}, catalog_path, provider)

    @mcp.tool(name="GetAssetContent", description="Read verified UTF-8 content of a package-relative catalog asset.")
    def get_asset_content(asset_id: str) -> dict[str, Any]:
        return _run("GetAssetContent", {"asset_id": asset_id}, catalog_path, provider)

    @mcp.tool(name="SearchDiscoveryPatterns", description="Search optional DAD discovery using an approved generic topic only.")
    def search_discovery_patterns(topic: str) -> dict[str, Any]:
        return _run("SearchDiscoveryPatterns", {"topic": topic}, catalog_path, provider)

    @mcp.tool(name="DADStatus", description="Read availability of the optional local DAD discovery provider.")
    def dad_status() -> dict[str, Any]:
        return _run("DADStatus", {}, catalog_path, provider)

    @mcp.custom_route("/api/tools/{name}", methods=["POST"])
    async def api_tools(request: Request) -> JSONResponse:
        name = request.path_params["name"]
        if name not in TOOL_NAMES:
            return JSONResponse({"ok": False, "error": {"code": "unknown_tool", "message": "unknown read-only tool"}}, status_code=404)
        try:
            body = await request.json()
        except json.JSONDecodeError:
            return JSONResponse({"ok": False, "tool": name, "error": {"code": "invalid_request", "message": "request body must be JSON"}}, status_code=400)
        if not isinstance(body, dict):
            return JSONResponse({"ok": False, "tool": name, "error": {"code": "invalid_request", "message": "request body must be an object"}}, status_code=400)
        response = _run(name, body, catalog_path, provider)
        return JSONResponse(response, status_code=200 if response["ok"] else 400)

    return mcp


class _NetworkGate:
    """ASGI wrapper used only for explicitly enabled non-loopback deployment."""

    def __init__(self, app: Callable[..., Awaitable[Any]], *, enabled: bool, key: str | None, hosts: set[str], origins: set[str]) -> None:
        self.app, self.enabled, self.key, self.hosts, self.origins = app, enabled, key, hosts, origins

    async def __call__(self, scope: dict[str, Any], receive: Callable[..., Awaitable[Any]], send: Callable[..., Awaitable[Any]]) -> None:
        if not self.enabled or scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        headers = {name.decode("latin-1").casefold(): value.decode("latin-1") for name, value in scope.get("headers", [])}
        host = headers.get("host", "").split(":", 1)[0].casefold()
        origin = headers.get("origin")
        permitted = headers.get("x-albert-key") == self.key and _host_is_allowed(host, self.hosts) and (origin is None or origin in self.origins)
        if permitted:
            await self.app(scope, receive, send)
            return
        payload = json.dumps({"ok": False, "error": {"code": "network_access_denied", "message": "network request is not allowed"}}).encode("utf-8")
        await send({"type": "http.response.start", "status": 403, "headers": [(b"content-type", b"application/json"), (b"content-length", str(len(payload)).encode("ascii"))]})
        await send({"type": "http.response.body", "body": payload})


def create_app(*, catalog_path: str | Path | None = None, provider: Any = None, host: str = "127.0.0.1"):
    """Return the SDK's Streamable HTTP app; `/mcp` and `/api/tools/{name}` share `_run`."""
    network, key, hosts, origins = _network_settings(host)
    mcp = create_mcp_server(catalog_path=catalog_path, provider=provider, host=host)
    return _NetworkGate(mcp.streamable_http_app(), enabled=network, key=key, hosts=hosts, origins=origins)


def main() -> None:
    """Start only when an operator explicitly invokes this module."""
    try:
        import uvicorn
    except ImportError as exc:
        raise SystemExit("uvicorn is required to run the optional HTTP service") from exc
    host = os.environ.get("ALBERT_BIND_HOST", "127.0.0.1")
    port = int(os.environ.get("ALBERT_BIND_PORT", "8765"))
    uvicorn.run(create_app(host=host), host=host, port=port, log_level="warning")


if __name__ == "__main__":
    main()
