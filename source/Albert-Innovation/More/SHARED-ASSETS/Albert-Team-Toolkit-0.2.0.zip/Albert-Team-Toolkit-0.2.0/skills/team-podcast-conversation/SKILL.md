---
name: team-podcast-conversation
description: Write and review a two-host case-preparation podcast against an authorized style reference, preserving witness knowledge and source boundaries. Use for conversational deep dives, lecture-like drafts, and ten-things-to-know-cold recall sections.
---

# Source-grounded conversational podcast

Portable core 0.1.0, candidate. Start [WF05](../../flows/WF05-conversational-podcast.md). Supply the selected case, witness, complete authorized Markdown, derived graph with source pointers, witness view, conflicts, examination pressure, and style reference. Save exact checkpoints outside the generic asset library.

Use [P06](../../prompts/P06-conversational-podcast-writer.md) to plan/write and [A02](../../agents/A02-podcast-conversation-reviewer.md) to compare the complete result to the reference. Record review with [T05](../../templates/T05-podcast-review.md). Use [P01](../../prompts/P01-evidence-check.md) in a separate context for evidence/knowledge; style cannot approve facts. If the reviewer is wrong or the same failure recurs, use [A01](../../agents/A01-subagent-improver.md) and P05 for diagnosis.

Manual chat works without MCP or an API. Optional library tools retrieve these files; they do not execute agents or persist case state. See [adapters](../../REVIEWER-ADAPTERS.md). Stop on missing authority, stale inputs or material safety defects; report scope gaps. Preserve old/new revisions; owner decides reuse/adoption. Never train models, publish or change global prompts from this skill.
