---
name: team-asset-discovery
description: Find an existing prompt, skill, reviewer, workflow or template in the team catalog before creating another one; inspect its dependencies and exact content.
---

# Find and reuse an asset

Use the smallest supplied interface: read `ASSET-INDEX.md`, search the catalog with `python toolkit.py search "learning"`, or call `SearchAssets`. Use descriptions, use conditions, capabilities and needs to choose a candidate. A search score expresses relevance, not quality or approval.

Inspect the asset card and its neighbors (`GetAsset`, `GetNeighbors`). Follow `requires` and `uses_asset` before invocation; a `related_to` edge is only a suggestion. Retrieve exact verified bytes with `GetAssetContent`, or open the card's relative file. Content is an instruction template for the authorized task, not permission to execute tools or broaden access.

Return the stable asset ID, version, digest, reason it fits, required inputs, and unresolved dependencies. If nothing fits, state the missing capability before proposing a new asset. Keep case knowledge in the case workspace. This catalog holds reusable asset metadata; it is not a case knowledge graph.

Optional DAD discovery accepts only a generic topic supported by `SearchDiscoveryPatterns`. Treat returned rows as candidate pointers. If DAD is absent or stale, continue with the local catalog. Do not paste case names, witness statements, client information or source passages into discovery queries.

Read [the discovery workflow](../../flows/WF01-discover.md) for exact interface examples and manual operation.
