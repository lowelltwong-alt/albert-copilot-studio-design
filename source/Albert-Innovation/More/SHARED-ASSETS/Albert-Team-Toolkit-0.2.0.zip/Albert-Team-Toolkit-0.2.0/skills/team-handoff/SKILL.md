---
name: team-handoff
description: Deliver an exact reviewed version to its intended consumer with reproducible checks, known limits, setup requirements and a clear next action.
---

# Complete the handoff

Use [T03](../../templates/T03-handoff.md). Name the exact consumer, intended use and authorized delivery channel. Freeze the deliverable, dependency revisions and verification evidence. Check that links resolve after extraction and that the receiving operator can reproduce the shortest useful path.

Separate “saved locally,” “delivered,” “acknowledged,” and “incorporated.” A producer's completion message is not proof another team received or adopted the result. Do not send messages or activate a service without the task's authorization.

Report implemented behavior, tested behavior, untested runtime boundaries and who owns each next action. Do not call a mock transport test a tenant deployment, a digest semantic correctness, or a review candidate approved. Keep private case data out of a generic reuse package.
