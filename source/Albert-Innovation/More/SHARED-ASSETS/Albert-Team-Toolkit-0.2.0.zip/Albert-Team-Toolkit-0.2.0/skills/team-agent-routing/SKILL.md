---
name: team-agent-routing
description: Decompose a substantial task into bounded author and checker roles, choosing model capability and effort proportionally and recording actual independence.
---

# Bounded delegation

Use [T02](../../templates/T02-assignment.md). Delegate only work that can run independently alongside useful lead work. Keep exact transformations local and deterministic. Use an economical read-only scout for bounded retrieval; a balanced worker for synthesis or implementation; a stronger specialist only for a named unresolved difficult question. Resolve actual available models in the runtime adapter; never make a provider model name the permanent role identity.

Give each worker inputs, one deliverable, allowed tools and effects, write ownership, acceptance evidence and a stopping condition. Keep overlapping files under one controller. An author may propose its own checks; another reviewer inspects the actual result before decisive acceptance.

Four review prompts run in one conversation are four lenses, not four independent reviewers. Record shared context, author exposure, model family, source visibility and whether scores were visible. Compare disagreements using source evidence, including the possibility that the evaluator is wrong. Escalate only the unresolved issue and stop after the agreed budget.

Use [P05](../../prompts/P05-prompt-diagnosis.md) for a recurring, verified failure. A score alone does not establish which layer needs a change. Preserve a working simple role when the fix belongs in a tool, input contract or downstream specialist.
