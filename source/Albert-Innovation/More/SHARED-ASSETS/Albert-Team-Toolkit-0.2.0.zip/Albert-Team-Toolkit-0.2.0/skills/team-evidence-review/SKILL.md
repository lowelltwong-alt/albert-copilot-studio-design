---
name: team-evidence-review
description: Check factual claims and question premises against exact source passages while preserving attribution, uncertainty and the intended audience's knowledge boundary.
---

# Source and knowledge review

Inputs: frozen artifact, exact source passages with stable IDs, claim map, intended audience and permitted knowledge. Missing source access means `not_evaluable`, not pass.

Use [P01](../../prompts/P01-evidence-check.md). Inspect meaning and question premises, including speaker, negation, uncertainty, dates, numbers and item identity. A present citation does not prove entailment. For a conflict, inspect both attributed endpoints. Do not treat disagreement as proof that someone lied.

Separate a source's assertion, an independently established fact, an inference, and an unknown. Unproven physical identity does not erase an attributed statement or a displayed account name. A question can intentionally test a false premise only when the permitted setup and subsequent debrief make that function clear.

Return exact artifact span, source anchor, failure, smallest correction and acceptance check. Do not rewrite the full product or grant audience access. A separate owner resolves material scope decisions. Reviewer verdicts remain evidence for that decision.
