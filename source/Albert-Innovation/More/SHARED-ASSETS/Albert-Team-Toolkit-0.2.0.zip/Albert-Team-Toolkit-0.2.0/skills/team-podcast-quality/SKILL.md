---
name: team-podcast-quality
description: Review a source-grounded training podcast transcript for useful factual teaching, truthful practice, delayed retrieval and spoken clarity; no audio generation.
---

# Training script quality

Inputs: source-bound approved scope, learner role, reviewed knowledge sheet, exact source map, complete script and audience. If witness preparation is involved, preserve the distinction between learning record facts and supplying desired testimony.

Use [WF03](../../flows/WF03-podcast-quality.md). Make a short plan of important factual distinctions and practice opportunities from the sources. Start with an actual learner question, leave a response pause, then teach the permitted fact or qualification. Useful feedback may restate source facts; it may not invent a learner answer, excuse, motive, memory or successful response.

Use evidence, examination, learning and spoken editorial lenses on the same frozen version. One editor adjudicates conflicting findings. Recheck affected source claims and the complete assembled transcript; a patch check alone does not establish whole-product quality.

A sparse case can produce a short episode. Do not manufacture conflict, drama or repetition to reach a reference duration. Give production notes separate from speech: speakers, spoken words, proposed silence and a words-per-minute range. These are estimates until recorded. Never claim tested human recall or audio listening from page review.

For Albert's exact W00–W10 prompts, source snapshots, timed scripts and unchanged production rubric, use the separately delivered `Albert-MVP-Quality-Loop` package. This generic skill does not override its gates or merge a case graph into the asset graph.
