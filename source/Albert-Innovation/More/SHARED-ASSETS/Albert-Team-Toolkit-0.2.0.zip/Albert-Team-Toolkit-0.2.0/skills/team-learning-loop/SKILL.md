---
name: team-learning-loop
description: Turn a verified error or repeated review failure into a bounded repair and a reusable candidate lesson, with regression evidence and a separate adoption decision.
---

# Learn from a verified result

Adapted from DAD's learning loop. Search prior lessons and assets first. Record whether a prior lesson applied, failed, or was unavailable; a duplicate observation is not another independent success.

Follow [WF02](../../flows/WF02-repair-learn.md). Keep the actual evidence and fixed artifact in their authorized workspace. Put only short categorical descriptions, opaque local references and hashes in learning records. Do not turn private facts, transcripts or secrets into reusable lessons.

Distinguish a mistaken answer from a mistaken instruction. The input, tool, context, workflow, handoff or evaluator may be responsible. Preserve counterevidence and use `no_change` or `collect_more_evidence` when the cause is uncertain. A model explaining its own failure is a hypothesis.

After the narrow repair, have another reviewer check the exact revised bytes and rerun the affected regression. A “fixed” claim without revision-bound validation and regression evidence remains blocked. Use `learning.py` and [LEARNING-CONTRACT](../../LEARNING-CONTRACT.md) to check the record; the validator does not run repairs or establish that the referenced evidence is true.

A lesson is a candidate until an authorized owner reviews its scope, other-case evidence, untouched holdout, costs, limitations and rollback. This skill never edits instructions automatically. Keep old prompt revisions available and mark their replacement explicitly. Prompt-only use works with operator-saved Markdown; Python and DAD are optional.
