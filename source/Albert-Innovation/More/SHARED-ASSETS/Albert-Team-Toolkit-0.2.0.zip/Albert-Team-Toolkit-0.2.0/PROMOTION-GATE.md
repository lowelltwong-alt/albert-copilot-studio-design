# MVP first; conditional reuse in the two full profiles

User instruction: start with the prompt-only MVP, test it, and carry improvements to the full workflow without services and the full workflow with MCP/API only if good. No automatic profile promotion occurred in this release.

1. Freeze the MVP prompt/adapter/source/knowledge-view revisions. Test an entire substantial Msimoto episode, not a sample.
2. Independent source review must find no unresolved material fabricated/unsupported testimony, knowledge leaks, changed qualifiers or exhibit confusion. Candidate OCR/testing is not human source approval.
3. Independent A02 review must score all five dimensions at least 3/4 with evidence, meaningful two-host interaction, ten supported distinct anchors, truthful examination handling and measured timing. Original broad Albert quality gates remain in force; this additional craft gate does not weaken them.
4. Use a materially different case for transfer and a truly unseen source/attempt for qualification evidence. Prior Kemper/Evans/Rivera/Chen cases are regressions, not untouched holdouts. A single Msimoto pass cannot establish all-case durability.
5. Review regressions for sparse evidence, conflicting accounts, expert versus fact witnesses, civil/criminal posture, and different exhibit forms. Do not invent specialized rules; obtain the supplied case-specific rules or mark limits.
6. Only after satisfying the applicable checks, port the same stable prompt/role IDs into each full profile's orchestration and storage adapter, then rerun affected retrieval, persistence, permission and full-assembly tests. No rewriting from scratch is necessary, but adapter equivalence must be observed.
7. Owner reviews exact versions, limitations and rollback. The two full profiles stay on their prior prompts while a gate is unmet. Reporting an incomplete gate is an allowed outcome, not a reason to lower the standard.

The generic toolkit may carry these candidate assets now for review without activating them in the other profiles. Case test outputs remain separate from this reusable package.
