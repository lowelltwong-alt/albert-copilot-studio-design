# WF02 · Error → repair → verified lesson

| Step | File / callable asset | Result and next step |
|---|---|---|
| 1 · Observe | `skills/team-learning-loop/SKILL.md` | Freeze actual failure and scope; search prior lessons. |
| 2 · Diagnose | `prompts/P02-repair-plan.md` | Verified cause or bounded uncertainty; one proposed repair. |
| 3 · Repair | Authorized operator or scoped worker | New artifact revision; preserved preimage. |
| 4 · Verify | `prompts/P03-independent-verification.md` | Distinct checker, exact revision, source check and regression evidence. Failed check returns to diagnosis within budget. |
| 5 · Curate | `prompts/P04-lesson-curation.md` | Deduplicated, deidentified candidate lesson or no change. |
| 6 · Validate record | `learning.py`; `LEARNING-CONTRACT.md` | Structural evidence checks. This does not execute the referenced test or prove reviewer identity. |
| 7 · Test transfer | `prompts/P05-prompt-diagnosis.md` | Relevant other-case regression and untouched holdout; no threshold changes. |
| 8 · Decide | Actual authorized owner | Adopt exact revision, reject or defer; record review date and rollback. |

Without Python, keep the same fields in operator-saved Markdown and manually inspect every gate. No transcript memory or chat context is treated as durable storage. DAD is optional discovery only; these local records are not sent to its learning store.

The toolkit closes the procedural gap by making the local handoffs explicit. It does not import DAD's collector, central lake, automatic capture, rule registry or private corpus.
