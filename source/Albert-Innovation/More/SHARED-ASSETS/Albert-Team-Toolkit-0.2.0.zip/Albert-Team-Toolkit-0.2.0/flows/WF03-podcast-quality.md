# WF03 · Plan → teach → test → improve

1. Lock source revisions, intended witness/learner scope, reviewed knowledge sheet and quality rubric.
2. Plan source-derived teaching units: important fact, qualification, actual question, feedback and later retrieval where useful.
3. Check planned premises and audience scope with P01 before drafting.
4. Draft the complete script and paragraph-to-source map. Put citations and timing outside speech.
5. Run four scoped lenses: evidence, examination realism, learning/retrieval and spoken clarity. Record which contexts are actually independent.
6. One editor verifies findings and makes the smallest material repairs. Preserve facts and adverse admissions; avoid repeated procedural narration.
7. Recheck changed evidence and the whole assembly. A separate final reviewer grades the frozen complete product. Stop at the agreed budget or when sources cannot support improvement.
8. Save speech-only export, speaker export, timing instructions, source map, review and unresolved findings. A human decides actual use.
9. Feed only verified generalizable failures into WF02. The next case uses the prior prompt until its replacement has passed separate adoption checks.

Use Albert's separate Quality Loop package for executable run cards, W-stage prompt placement, all eight dimensions, source snapshots and measured word/pause exports. Its production threshold is unchanged. This portable workflow alone does not qualify a podcast or establish learning outcomes.
