# WF01 · Discover → inspect → use

1. Start with the task's generic capability: evidence checking, learning, delegation, podcast quality or handoff.
2. Find matching descriptions in `ASSET-INDEX.md` or the local search CLI.
3. Inspect the stable asset card, use/non-use conditions and dependencies.
4. Follow its graph neighbors. `uses_asset` describes composition; `related_to` describes candidate similarity. Neither is approval.
5. Retrieve the verified content and supply its declared inputs in an authorized model conversation. Save the output with the asset version and input revisions.
6. Run the named acceptance check and hand the result to its consumer.

Manual mode needs only these Markdown files. Python indexes the same catalog. MCP and API retrieve the same files; they do not run the prompts or save case state.

The complete asset graph belongs to this package. A case graph, chunks, conflicts and witness scope belong in the case's own saved workspace. Keep those two graphs separate.
