# Albert Team Toolkit

**0.2.0 · local review candidate.** A separate gift for the team: searchable reusable prompts, skills, subagent roles, workflows and source-linked learning methods adapted from DAD.

Start with [the asset index](ASSET-INDEX.md), or open one of the two new workflows:

- [Review and improve a subagent](flows/WF04-subagent-improvement.md): trace instructions to actual output, check the grader, diagnose the responsible layer, test a minimal change and retain owner-controlled adoption.
- [Make a rich conversational podcast](flows/WF05-conversational-podcast.md): use the case Markdown and knowledge boundaries to plan and write a two-host deep dive, teach likely examination pressure truthfully, include ten things to know cold, and compare the complete transcript with the original style reference.

![Podcast composition and review](D05-PODCAST-CONVERSATION.png)

The new [instruction-and-output reviewer A01](agents/A01-subagent-improver.md) can inspect writers **and reviewers**. The [podcast reviewer A02](agents/A02-podcast-conversation-reviewer.md) checks whether host exchanges build understanding, rather than alternating lecture paragraphs. [P06](prompts/P06-conversational-podcast-writer.md) supplies the substantial conversation-writing brief. [Reference notes](PODCAST-REFERENCE-NOTES.md) explain what was learned from the user's original NotebookLM episodes and Meta's public NotebookLlama pipeline.

## Minimal setup

Open the workflow and linked exact prompt files, supply authorized inputs in your chosen model conversation, then save/reopen the outputs. No custom API, MCP, DAD installation or Python is needed for this manual mode. Saved files—not chat context—hold the case state.

For searchable local retrieval, use Python 3.11+:

```powershell
python -B toolkit.py validate
python -B toolkit.py search podcast --limit 5
python -B toolkit.py neighbors albert:workflow:conversational-podcast
python -B toolkit.py content albert:agent:podcast-conversation-reviewer
```

The optional existing MCP/API companion returns these same verified instruction files. It does not run agents, call models or store cases. [Reviewer adapters](REVIEWER-ADAPTERS.md) map manual, host-agent, MCP/API and later audio use; [RUNTIME](RUNTIME.md) and [COPILOT-SETUP](COPILOT-SETUP.md) describe the service. Copilot Studio/Teams tenant import remains untested.

## Composition, evidence and limits

[catalog.json](catalog.json) owns asset identities, descriptions, digests and typed relationships. [GRAPH.json](GRAPH.json) and the [index](ASSET-INDEX.md) derive from it. Candidate similarity links help discovery; they do not grade instructions or establish source truth. Case graphs/chunks/conflicts stay in their own authorized workspace. The generic toolkit never receives private case rows through its search interface.

![Bounded review of agents and reviewers](D04-SUBAGENT-IMPROVEMENT.png)

[QA](QA-REPORT.md) gives exact testing and remaining gaps. [Provenance](PROVENANCE.md) preserves donor fingerprints and owner-authorized team reuse; public licensing remains unresolved. The old 0.1.0 release is retained for rollback. No global prompts were installed, no audio produced, and no Innovation message or public Git publication was sent.

The user requested **MVP-first** testing. These podcast prompts are candidate improvements for that test; the full manual and MCP/API Albert profiles are unchanged until the quality and transfer gates in [PROMOTION-GATE](PROMOTION-GATE.md) are satisfied. A promising episode is not proof of universal case coverage or gold-standard audio.
