"""Focused local diagnostics for the portable learning evaluator.

These are ordinary unit/smoke checks, not DAD harness certification.
"""

from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

import learning


ROOT = Path(__file__).parent
COMPLETE = ROOT / "examples" / "learning-complete.json"
UNSAFE = ROOT / "examples" / "learning-rejected-unsafe.json"
NONFINITE = ROOT / "examples" / "learning-rejected-nonfinite.json"


def complete() -> dict:
    return json.loads(COMPLETE.read_text(encoding="utf-8"))


def codes(result: dict) -> set[str]:
    return {finding["code"] for finding in result["findings"]}


class LearningEvaluatorTests(unittest.TestCase):
    def test_complete_synthetic_bundle_is_candidate_only(self) -> None:
        result = learning.evaluate(complete())
        self.assertTrue(result["valid"])
        self.assertEqual("candidate_record_valid_review_pending", result["status"])
        self.assertFalse(result["controls"]["automatic_promotion"])
        self.assertFalse(result["controls"]["persistence_performed"])
        self.assertFalse(result["controls"]["execution_performed"])
        self.assertEqual("unverified", result["controls"]["adoption_eligibility"])

    def test_fix_event_link_mismatch_has_one_new_finding_over_valid_baseline(self) -> None:
        baseline = learning.evaluate(complete())
        record = complete()
        record["fix"]["event_id"] = "innovation:event:000000000000000000000000"
        result = learning.evaluate(record)
        baseline_codes = [finding["code"] for finding in baseline["findings"]]
        candidate_codes = [finding["code"] for finding in result["findings"]]
        self.assertEqual([], baseline_codes)
        self.assertEqual(["broken_fix_event_link"], candidate_codes)

    def test_false_fixed_claim_is_rejected(self) -> None:
        record = complete()
        record["fix"]["decision"] = "accepted_risk"
        result = learning.evaluate(record)
        self.assertEqual("rejected", result["status"])
        self.assertIn("false_fixed_claim", codes(result))

    def test_missing_regression_reference_is_rejected(self) -> None:
        record = complete()
        record["fix"]["regression_refs"] = []
        result = learning.evaluate(record)
        self.assertEqual("rejected", result["status"])
        self.assertIn("field_required", codes(result))

    def test_author_cannot_be_checker(self) -> None:
        record = complete()
        record["fix"]["checker_id"] = record["fix"]["author_id"]
        result = learning.evaluate(record)
        self.assertEqual("rejected", result["status"])
        self.assertIn("author_checker_not_distinct", codes(result))

    def test_stale_validation_revision_is_rejected(self) -> None:
        record = complete()
        record["fix"]["validation_refs"][0]["artifact_revision"] = record["event"]["artifact_revision"]
        result = learning.evaluate(record)
        self.assertEqual("rejected", result["status"])
        self.assertIn("stale_evidence_revision", codes(result))

    def test_unsafe_metadata_is_rejected(self) -> None:
        result = learning.evaluate(json.loads(UNSAFE.read_text(encoding="utf-8")))
        self.assertEqual("rejected", result["status"])
        self.assertIn("unsafe_metadata", codes(result))

    def test_common_windows_user_path_is_rejected(self) -> None:
        record = complete()
        record["event"]["safe_summary"] = r"A value from C:\Users\operator\record.txt was observed."
        result = learning.evaluate(record)
        self.assertEqual("rejected", result["status"])
        self.assertIn("unsafe_metadata", codes(result))

    def test_unhashable_adoption_decision_returns_findings(self) -> None:
        record = complete()
        record["adoption_decision"]["decision"] = []
        result = learning.evaluate(record)
        self.assertEqual("rejected", result["status"])
        self.assertIn("invalid_adoption_decision", codes(result))

    def test_duplicate_learning_is_held_for_review(self) -> None:
        record = complete()
        record["lesson_candidate"]["prior_candidate_ids"] = ["innovation:lesson:000000000000000000000000"]
        result = learning.evaluate(record)
        self.assertTrue(result["valid"])
        self.assertEqual("needs_duplicate_review", result["status"])
        self.assertIn("duplicate_learning_conservative_hold", codes(result))

    def test_adoption_is_recorded_but_never_applied(self) -> None:
        record = complete()
        record["adoption_decision"].update({"decision": "adopt", "human_approver_id": "human-c", "decision_summary": "Approved for a bounded team guidance trial."})
        expected = learning.stable_id("adoption", {"candidate_id": record["lesson_candidate"]["candidate_id"], "decision": "adopt", "scope": record["adoption_decision"]["scope"]})
        record["adoption_decision"]["adoption_id"] = expected
        result = learning.evaluate(record)
        self.assertEqual("adoption_recorded_not_applied", result["status"])
        self.assertFalse(result["controls"]["automatic_promotion"])
        self.assertFalse(result["controls"]["execution_performed"])

    def test_adoption_without_operator_identity_is_rejected(self) -> None:
        record = complete()
        record["adoption_decision"]["decision"] = "adopt"
        record["adoption_decision"]["adoption_id"] = learning.stable_id(
            "adoption",
            {"candidate_id": record["lesson_candidate"]["candidate_id"], "decision": "adopt", "scope": record["adoption_decision"]["scope"]},
        )
        result = learning.evaluate(record)
        self.assertEqual("rejected", result["status"])
        self.assertIn("adoption_requires_operator", codes(result))

    def test_pending_adoption_rejects_nonstring_operator_identity(self) -> None:
        record = complete()
        record["adoption_decision"]["human_approver_id"] = []
        result = learning.evaluate(record)
        self.assertEqual("rejected", result["status"])
        self.assertIn("field_type", codes(result))

    def test_cli_smoke_emits_json_without_writing(self) -> None:
        before = {path.name for path in ROOT.iterdir()}
        run = subprocess.run(
            [sys.executable, "-B", "learning.py", "demo", str(COMPLETE)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(0, run.returncode, run.stderr)
        self.assertEqual("candidate_record_valid_review_pending", json.loads(run.stdout)["status"])
        self.assertEqual(before, {path.name for path in ROOT.iterdir()})

    def test_cli_rejects_nonfinite_json_without_echoing_input(self) -> None:
        run = subprocess.run(
            [sys.executable, "-B", "learning.py", "validate", str(NONFINITE)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=False,
        )
        payload = json.loads(run.stdout)
        self.assertEqual(1, run.returncode)
        self.assertEqual("rejected", payload["status"])
        self.assertEqual(["input_error"], [finding["code"] for finding in payload["findings"]])
        self.assertNotIn("NaN", run.stdout)
        self.assertNotIn(str(NONFINITE), run.stdout)

    def test_input_byte_limit_rejects_before_opening_file(self) -> None:
        class OversizedInput:
            def stat(self) -> SimpleNamespace:
                return SimpleNamespace(st_size=learning.MAX_INPUT_BYTES + 1)

            def open(self, *_: object, **__: object) -> object:
                raise AssertionError("oversized input must not be opened")

        with self.assertRaisesRegex(ValueError, "input exceeds byte limit"):
            learning.load_json_strict(OversizedInput())  # type: ignore[arg-type]


if __name__ == "__main__":
    unittest.main()
