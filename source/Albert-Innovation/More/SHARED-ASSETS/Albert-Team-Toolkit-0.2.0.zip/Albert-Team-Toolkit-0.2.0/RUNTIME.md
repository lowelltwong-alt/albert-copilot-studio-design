# Albert Team Toolkit runtime

This is an optional, generic digital-asset companion. It has no case corpus,
does not execute prompts, makes no model call, and does not implement Albert
case jobs, persistence, OAuth, or tenant activation. Albert's prompt-only MVP
does not require it.

## Offline CLI

The standard-library core reads only `catalog.json` beside `toolkit.py`.
Run it from this directory:

```powershell
python -B toolkit.py validate
python -B toolkit.py search mcp --limit 10
python -B toolkit.py get <asset-id>
python -B toolkit.py neighbors <asset-id>
python -B toolkit.py content <asset-id>
python -B toolkit.py graph
```

The validator rejects duplicate JSON keys and IDs, escaping/symlink paths,
stale SHA-256 digests, dangling/duplicate edges, and edge types outside the
contract vocabulary. Asset retrieval reads only verified, package-relative
regular UTF-8 files. `graph` preserves supplied typed edges and emits
deterministic candidate relations without rank or score claims. Its local,
stdlib-only relation method is adapted from DAD
`src/digital_asset_directory/graph_engine.py` (`build_edges`, threshold 0.34)
and `src/digital_asset_directory/utils.py` (`tokens`, `idf_weights`, and
`idf_weighted_cosine`): it tokenizes only title, description, tags,
capabilities, needs, and outcomes; computes normalized IDF-weighted cosine;
keeps pairs at or above 0.34; and accepts at most four candidates at each
asset with stable tie ordering. It emits bounded shared-term evidence only.
The local implementation imports no DAD code or runtime. Those relations are
retrieval candidates, not authority, approval, or merit evidence.

## Optional HTTP and MCP service

Use a normal project virtual environment with the pinned Python MCP SDK
`mcp==1.30.0`, Starlette, and Uvicorn. Do not install globally:

```powershell
py -m venv .venv
.\.venv\Scripts\python -m pip install "mcp==1.30.0" "starlette==1.6.0" "uvicorn==0.52.4" "httpx==0.28.1"
.\.venv\Scripts\python -B server.py
```

The service binds `127.0.0.1:8765` by default. It serves official FastMCP
stateless JSON Streamable HTTP at `/mcp` and the same dispatcher as
`POST /api/tools/{name}`. Both expose exactly these bounded read tools:

| Tool | Input |
| --- | --- |
| `SearchAssets` | `query`, optional `limit` (1–25) |
| `GetAsset` | `asset_id` |
| `GetNeighbors` | `asset_id` |
| `GetAssetContent` | `asset_id` |
| `SearchDiscoveryPatterns` | closed generic `topic` enum only |
| `DADStatus` | no input |

There are no write tools, generic MCP pass-through, case fields, or automatic
fallback to a write path. `/api/tools/{name}` accepts one JSON object; invalid
requests return a bounded `invalid_request` response.

To bind a non-loopback host, set all of these before starting: 
`ALBERT_NETWORK_ENABLED=true`, `ALBERT_NETWORK_KEY`,
`ALBERT_ALLOWED_HOSTS` (comma-separated), and `ALBERT_ALLOWED_ORIGINS`
(comma-separated). Every network HTTP request, including `/mcp`, must carry
`X-Albert-Key` and match the configured Host/origin. This is a small deployment
gate, not OAuth or a production security certification.

## Optional DAD discovery

DAD is disabled unless all three variables are deliberately configured:

```powershell
$env:ALBERT_DAD_DISCOVERY = "enabled"
$env:ALBERT_DAD_PYTHON = "C:\absolute\path\to\DAD-python.exe"
$env:ALBERT_DAD_ROOT = "C:\absolute\path\to\initialized-DAD-root"
```

`dad_provider.py` starts that fixed executable with `-B -m
digital_asset_directory.cli mcp graph-stdio --hub <root>` and no shell. It
performs MCP `initialize`, sends `notifications/initialized`, then calls
`tools/list` before one read call; it verifies the exact
four DAD graph-read tool names, and exposes only `dad_graph_surface_status` and
`dad_graph_search_nodes` through the two Albert discovery tools. Generic topics
are mapped internally; no case identifier, case text, user identity, token,
tenant value or source row is accepted as an input. Raw DAD responses never
leave the broker; only its bounded projection is returned. Timeout,
capability drift, malformed output, path/credential-like output, or missing
configuration returns `unavailable`; the local catalog still works.

The DAD result is explicitly candidate-only discovery metadata. It cannot
become Albert case evidence, source authority, review approval, or a job input.
No DAD preflight/workflow command, registry/settings write, host registration,
or public server is performed by this runtime.

## Tests

```powershell
.\.venv\Scripts\python -B test_runtime.py
```

The baseline covers catalog validation, content digest/path confinement, typed
edges, candidate graph output, discovery-topic denial, null DAD behavior, API
parity, and an SDK `ClientSession` Streamable HTTP initialize/list/call smoke
when optional dependencies are available. It is local implementation evidence,
not a tenant, Copilot Studio, OAuth/DLP, public-network, or full Albert backend qualification.
