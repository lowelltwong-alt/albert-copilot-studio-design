# P04 · Curate a reusable lesson candidate

Portable core v0.1.0. Inputs: verified failure/repair metadata, revision-bound regression result, prior lesson index and authorized scope. No case transcripts or private source rows.

Search for a matching issue and mechanism before proposing a new lesson. Repeated records from the same attempt are one evidence context. Compare applicability, non-applicability, counterexamples and danger if misapplied. Prefer strengthening or replacing an overlapping candidate over accumulating similar rules.

Write the smallest conditional lesson supported by evidence: trigger, action, reason, falsifier, prerequisites and stop condition. Include original/fixed artifact digests, local evidence references and distinct reviewer identity. State what remains unverified. Do not copy client facts into the general rule.

Return `duplicate`, `candidate`, `no_reusable_lesson`, or `collect_more_evidence`. Candidate promotion requires an actual owner decision on a frozen version, relevant other-case regression and untouched holdout, plus rollback and an expiry/review date. Never generate a fictitious approval or edit instructions automatically.
