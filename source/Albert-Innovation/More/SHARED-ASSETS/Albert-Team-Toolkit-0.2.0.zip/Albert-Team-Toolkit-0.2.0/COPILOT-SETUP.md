# Optional Copilot Studio connection

The target is the **standard harness**, with **Teams** as the first deployment test. Tenant details are pending. The implemented endpoint serves this generic asset companion; it is not the full Albert case workflow backend.

Microsoft currently specifies **Streamable HTTP**, with the onboarding wizard as the recommended connection route. Copilot Studio supports MCP tools/resources and requires generative orchestration. These statements were checked against Microsoft's documentation on 2026-09-08. [Connection guide](https://learn.microsoft.com/en-us/microsoft-copilot-studio/mcp-add-existing-server-to-agent), [MCP extension requirements](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agent-extend-action-mcp).

## Local engineer smoke

Create an ordinary project-local virtual environment using the team's workspace policy, install `requirements.txt`, activate it and start `python -B server.py`. The default is loopback `127.0.0.1:8765`. Use `test_runtime.py` and the commands in RUNTIME.md before hosting. `REQUIREMENTS-TESTED-WINDOWS.txt` records the exact dependency versions used in this task's Windows test environment; it is not cross-platform qualification.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -B server.py
```

No provider API key is needed to retrieve the library. A service access key is required for an explicitly enabled non-loopback deployment. Do not put it into the catalog, prompt text or source control.

## Configuration contract

| Setting | Local default / required value | Owner |
|---|---|---|
| MCP endpoint | `/mcp` on the hosted HTTPS service | Service team |
| API endpoint | `/api/tools/{name}` on the same service | Service team |
| `ALBERT_BIND_HOST` | Loopback by default; choose deployment bind explicitly | Service team |
| `ALBERT_BIND_PORT` | 8765 by default | Service team |
| `ALBERT_NETWORK_ENABLED` | Omitted locally; `true` for a non-loopback bind | Service team |
| `ALBERT_NETWORK_KEY` | Secret value supplied by hosting secret store | Service team |
| `ALBERT_ALLOWED_HOSTS` | Explicit externally served host names; no wildcard | Service team |
| `ALBERT_ALLOWED_ORIGINS` | Explicit permitted browser origins | Service team |
| Client authentication header | `X-Albert-Key` | Connector admin |
| DAD discovery | Disabled by default; see RUNTIME.md for opt-in local paths | DAD owner / service team |
| Tenant, environment, DLP policy, Teams channel | Pending tenant-specific values | Power Platform admin |

Host the service behind managed HTTPS. The code supplies an API-key gate, not an OAuth identity service. If your organization requires per-user Entra identity, add and test an appropriate identity-aware gateway/adapter before tenant use. A cloud-hosted service cannot access a laptop's local DAD by a filesystem path; deploy the optional broker only where a governed DAD runtime is available, or leave it disabled. Never expose local DAD stdio directly as a Copilot endpoint.

## Studio placement

1. In the target environment, confirm the standard harness and generative orchestration. Open the agent's **Tools → Add a tool → New tool → Model Context Protocol**.
2. Name it **Albert Team Toolkit**. Description: “Find and retrieve reusable team skills, prompts, review workflows and learning-record guidance. Generic asset discovery only; not case evidence or case storage.”
3. Enter the hosted HTTPS URL ending in `/mcp`. Choose **API key**, type **Header**, name **X-Albert-Key**. Supply the actual service access key through the connection setup.
4. Create the connection and add it to the agent. Verify the six expected tools and exact input schemas. Retrieve `albert:skill:learning-loop`; ask for a generic topic, not a client case.
5. If a custom connector is required, copy `COPILOT-MCP.swagger.json`, replace its `.invalid` host with the actual service hostname and configure the same header. For the optional API read route use `COPILOT-API.swagger.json`. These are templates; the sample host is deliberately unusable.
6. For a read fallback, call the equivalent API operation with the same arguments and principal. Neither interface writes case state or executes a prompt. Do not duplicate a model generation under the assumption that a read fallback resumes it.

## Acceptance before the team calls it deployed

| Check | Required evidence |
|---|---|
| Transport | Real Studio initialization, tools listing and successful content retrieval over HTTPS |
| Identity and policy | Approved connection, intended user access, rejected wrong/missing key, permitted Power Platform DLP grouping |
| Parity | Same asset ID/version/hash/content via MCP and API for the same principal |
| Failure | DAD unavailable leaves local asset retrieval working; unknown topic and write tool rejected |
| Teams | Publish the agent to the approved Teams channel and repeat the supported user journeys |
| Operations | Hosting owner, access-key rotation, monitoring, removal and rollback documented |

Record observed dates/results and exact package hash. Local tests cannot establish these tenant-specific results. The package therefore makes no “100% Copilot deployment” claim while tenant and hosted endpoint evidence are missing.
