# Searchable asset index — 0.2.0

Generated from catalog.json. Stable IDs map to exact instruction files; candidate review status does not grant execution or adoption authority.

| ID | Asset / exact file | When to use |
|---|---|---|
| `albert:skill:asset-discovery` | [Find reusable assets](skills/team-asset-discovery/SKILL.md) | Before creating a reusable asset or selecting a method. |
| `albert:skill:learning-loop` | [Learn from verified errors](skills/team-learning-loop/SKILL.md) | A reproducible error, recurring review failure or applicable prior lesson. |
| `albert:skill:evidence-review` | [Check sources and knowledge](skills/team-evidence-review/SKILL.md) | A source-grounded product needs factual or knowledge-boundary review. |
| `albert:skill:agent-routing` | [Assign authors and checkers](skills/team-agent-routing/SKILL.md) | Independent work can advance a substantial task in parallel. |
| `albert:skill:podcast-quality` | [Improve a training transcript](skills/team-podcast-quality/SKILL.md) | A training or witness-prep transcript is ready for planned review. |
| `albert:skill:handoff` | [Deliver an exact version](skills/team-handoff/SKILL.md) | A reviewed work product has a downstream consumer. |
| `albert:prompt:evidence-check` | [P01 · Evidence checker](prompts/P01-evidence-check.md) | Review one frozen artifact with its source map and allowed knowledge. |
| `albert:prompt:repair-plan` | [P02 · Repair planner](prompts/P02-repair-plan.md) | A verified defect needs a narrow repair. |
| `albert:prompt:independent-verification` | [P03 · Independent verifier](prompts/P03-independent-verification.md) | A separate reviewer can inspect an exact candidate repair. |
| `albert:prompt:lesson-curation` | [P04 · Lesson curator](prompts/P04-lesson-curation.md) | A verified repair may generalize. |
| `albert:prompt:prompt-diagnosis` | [P05 · Prompt diagnosis](prompts/P05-prompt-diagnosis.md) | Recurring verified failures justify a bounded comparison. |
| `albert:workflow:discovery` | [WF01 · Find and use](flows/WF01-discover.md) | Choose and invoke a supplied reusable asset. |
| `albert:workflow:repair-learning` | [WF02 · Repair and learn](flows/WF02-repair-learn.md) | A concrete error needs evidence-backed reuse. |
| `albert:workflow:podcast-quality` | [WF03 · Podcast quality](flows/WF03-podcast-quality.md) | Generate or improve a complete source-grounded training transcript. |
| `albert:template:assignment` | [T02 · Worker assignment](templates/T02-assignment.md) | Dispatch a bounded worker or checker. |
| `albert:template:handoff` | [T03 · Consumer handoff](templates/T03-handoff.md) | Prepare an exact version for a named consumer. |
| `albert:contract:learning-record` | [Learning record contract](LEARNING-CONTRACT.md) | Create a learning bundle for learning.py. |
| `albert:tool:learning-record-check` | [Learning record checker](learning.py) | Check a local operator-supplied learning record. |
| `albert:example:learning-record` | [Synthetic learning record](examples/learning-complete.json) | Learn the record shape or run the local demo. |
| `albert:agent:subagent-improver` | [A01 · Review and improve subagents](agents/A01-subagent-improver.md) | A weak output, recurring failure or disputed agent grade. |
| `albert:skill:subagent-improvement` | [Use the subagent improvement architecture](skills/team-subagent-improvement/SKILL.md) | Selecting a reusable review architecture for workers and reviewers. |
| `albert:template:subagent-review` | [T04 · Instruction-output review packet](templates/T04-subagent-review.md) | Saving a review against exact worker and grader artifacts. |
| `albert:workflow:subagent-improvement` | [WF04 · Review, challenge and improve agents](flows/WF04-subagent-improvement.md) | A reusable architecture needs an auditable improvement path. |
| `albert:agent:podcast-conversation-reviewer` | [A02 · Does this sound like a podcast?](agents/A02-podcast-conversation-reviewer.md) | A podcast draft sounds like a lecture or needs reference-based craft review. |
| `albert:skill:podcast-conversation` | [Use the rich podcast workflow](skills/team-podcast-conversation/SKILL.md) | Building substantial witness-preparation podcast scripts. |
| `albert:prompt:conversational-podcast-writer` | [P06 · Write a rich two-host podcast](prompts/P06-conversational-podcast-writer.md) | Prompt-only case preparation needs depth, host interaction and truthful cross/direct practice. |
| `albert:workflow:conversational-podcast` | [WF05 · Case knowledge to conversational podcast](flows/WF05-conversational-podcast.md) | Implementing the MVP-first conversational podcast and reviewer architecture. |
| `albert:template:podcast-review` | [T05 · Podcast reference comparison](templates/T05-podcast-review.md) | Comparing an exact complete transcript to a permitted style reference. |
| `albert:example:subagent-review-fixtures` | [Synthetic agent and grader failures](examples/subagent-review-fixtures.md) | Probing an instruction-output reviewer without private payloads. |
