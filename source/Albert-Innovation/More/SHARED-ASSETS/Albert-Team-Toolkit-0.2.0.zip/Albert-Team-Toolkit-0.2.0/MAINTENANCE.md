# Maintain one catalog and its projections

The catalog is the local metadata authority. Markdown instructions remain the asset content authority. The human index and generated graph are projections of the catalog, never independent copies to edit separately. No external DAD catalog becomes authoritative for this package.

An asset keeps its ID when its implementation or prompt revision changes. Update its version and digest; record the reason, affected consumers and evidence. Create a new ID when it is a materially different capability. Mark a replacement explicitly rather than deleting history or silently reusing an old ID for a different purpose.

For a catalog revision, select exact unique IDs, bind the whole old catalog digest and expected old field values, review a semantic diff, and reject changes to unrelated or protected rows. Apply under an exclusive lock with an atomic replacement. Validate all asset paths/digests and graph endpoints; regenerate the index and graph from that validated revision. Roll back only when the current bytes still match the failed candidate. Keep the old release archive.

This release was created under an expected-absence lock and validated before and after publication. It provides read-only runtime tools, not a general-purpose registry editor or automatic learner. The team's governed repository tools should own future mutations. A model must not silently reseal a changed prompt and keep the same review evidence.

Re-run affected tests when the catalog, prompt, model adapter, runtime, SDK, source scope or deployment boundary changes. Structural checks do not establish cross-model behavior. Human review remains required to adopt changed instructions; record comparison, scope, limitations and rollback in the new release.
