# Frozen diagram previews

These SVG/PNG previews were rendered from workflow-core revision `c86dd4d5ee578e75d01541c64770313b4af9ec6095fbb1e226ac637a37b4260a`. They are a dated review snapshot, not the live diagram source. Use the canonical core and its generated Mermaid files for future changes. RENDER-RECEIPT.json binds every source and output hash.
