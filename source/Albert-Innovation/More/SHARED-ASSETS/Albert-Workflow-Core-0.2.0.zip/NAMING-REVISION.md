# Presentation revision

Recipient titles normalized. Prior archive SHA-256: `a55ca6e8e58fa806a1ff87255f033a80aa4d17cc45c1a184b2067a9034bedc45`. Historical validation reports describe the original revision; they are not fresh tenant or performance results. Manifest payload fingerprints reflect this naming copy. Source and license notices remain applicable.
