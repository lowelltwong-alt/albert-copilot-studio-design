# Exact prompt and file handoffs

Use `CASE-WITNESS` plus immutable revision `REV`. Start with the local frozen [WF06](shared/imports/Albert-Prompt-Process-0.3.0/WF06-prompt-process.md), which contains the complete naming and input/output table. The mapping below applies to all three profiles; transport does not change knowledge permission or review requirements.

| Step | Instruction IDs | Save and reopen before next role |
|---|---|---|
| Source / W05 | P07 + P01 + P06 | Raw source index, permission view, separate author ledger, `...W05-HANDOFF-REV.md`. Declare proposition versus full-span permission explicitly. |
| Plan / W08 | P06 + T06 | `...W08-PLAN-REV.md`, planned KC10 and T06, supported duration budget. |
| Plan gate / W06 | Independent P01 + P07 | `...W06-PLAN-REV.md`; resolve material premises before drafting. |
| Draft / W08 | P06 + T06 | Full SCRIPT, CLAIMS, KC10, AUTHOR and as-built T06 for the same revision. |
| Initial review / W06 | Separate P01 and A02 + T06 | SOURCE and CRAFT reports with identical complete assembly/source/view hashes and actual required reads. |
| Join / W07 | P09 | Current AND decision; a source/method/disclosure failure vetoes a craft score. |
| One repair if justified | Exact P02 + P06 + P08 | New complete assembly and CHANGE-RECEIPT, verified actions, original preserved. |
| Final review / W06 | Independent P03 and A02 | Whole current assembly; fixed/preserved/not-fixed/not-assessed are distinct. Stop unresolved failures. |
| Export / W09 | P09/operator | SPEAKERS.txt, SPOKEN.txt, TIMING.md, permitted card/map. Keep cues and citations nonspoken. |
| Triggered learning | A01 + P05 / WF04 | Instruction-output evidence, critic validation, generic candidate with exact tests; no automatic prompt edits. |

Ordinary operation allows at most one verified repair. A separately declared development experiment may test a second only after meaningful benefit and a remaining deficit; stop at plateau, regression, veto or its cap. Preserve first-pass and repaired results separately. A longer runtime produced by pauses does not establish richer teaching. A small probe pass does not establish full-script compliance.

Save source truth, permissions, conflicted accounts and derived graph separately. The witness-facing output may use only permitted knowledge, including explicitly allowed attributed statements; a broader author research context never grants permission. At export the owner checks actual consumer, access, version and retained file identities. Chat context is not durable storage.

This package has no active live witness authority or external send capability. The user receives the local deliverable; a team handoff remains a separate authorized channel action. No source case material belongs in the generic public asset pack.
