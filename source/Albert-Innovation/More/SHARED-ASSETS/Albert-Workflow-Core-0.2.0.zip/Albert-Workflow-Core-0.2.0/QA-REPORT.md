# Core 0.2.0 integration QA

Disposition: **local package integrity and diagram generation verified**. This does not qualify the case transcripts, a Copilot tenant, a backend or a public release.

The independently reviewed create-only derivation applied 34 typed semantic changes, bound frozen Process 0.3.0, retained the old core unchanged, and verified every payload after generation and tests. All ten generator tests passed under Python optimization (`-O`), including stale-output rejection, missing/duplicate identities, invalid learning adoption, input/path/hash faults and diagram injection. The generated-output drift check passed. These are previously observed completed runs; this receipt does not invent a second full test execution.

Current integrity recheck verified every derivation payload and all four Mermaid source/PNG/SVG identities. The complete flow and three profile diagrams rendered successfully using Mermaid 11.17.2 in isolated headless Edge. Root visually inspected all four PNGs: text is legible and nodes are not clipped. They are long workflow diagrams; use the SVG for zooming. No source-case data was sent to the renderer. The first sandbox browser launch failed with EPERM; the approved retry rendered successfully.

All three profiles use the same P07 source/consumer handoff, P08 depth-preserving repair, P09 current-review join and stopping rule, T06 actual pressure/payoff review, and WF06 flow. Profile differences are runtime/storage adapters. Source review remains independent from craft review. No imported historic QA result is treated as qualification of this derivative. Existing learning-ledger entries remain candidates with no automatic adoption. Model, provider, tenant and audio behavior remain untested by these deterministic checks.

Diagrams derive from the core definition; edit the definition through the guarded mechanism, regenerate, run tests and drift checking, then render/inspect affected previews. The included CI installation instructions enable enforcement when installed. No persistent watcher or repository CI was installed in this local task.

## Exact identities

| Artifact | SHA-256 |
|---|---|
| outputs/Albert-Workflow-Core-0.2.0/core/workflow-core.json | c86dd4d5ee578e75d01541c64770313b4af9ec6095fbb1e226ac637a37b4260a |
| outputs/Albert-Workflow-Core-0.2.0/DERIVATION-RECEIPT.json | 68493e85e3e6ab625b546db08c2b62b8f0b7a828c861b725f121c15d42a8a46d |
| outputs/Albert-Workflow-Core-0.2.0/generator.py | b4bd1e7023a6eab12ffa6dddbe35374dd994ea476daf0a0c9951c1271ae1b28b |
| outputs/Albert-Workflow-Core-0.2.0/test_generator.py | f35c603f488b49296e94f58df8894339feffa7a46179f44974d0cc8d07cf7120 |
| outputs/Albert-Workflow-Core-0.2.0-Previews/RENDER-RECEIPT.json | c7755feb6136c6de586ece5da40842f9f2baa912a431a96ec9eb355e59ea2b69 |
| work/create_core02.py | c879bc68c374cdcf5c3d39013c2dfba1972d6340b630be4f937163fe8316455d |
| work/core02-dry-run.json | 68493e85e3e6ab625b546db08c2b62b8f0b7a828c861b725f121c15d42a8a46d |
| work/core02-mechanism-review.md | 3f45fdbf4096d43644c5f04c2adca4ec1792f87334edf20aa34e7aabd2bbc7c0 |
| work/render_core02.cjs | d916ef280be9c09f820cf187386c0b5f57c3a0b1a4babf0ace68428437af0671 |

Current recheck: 105 bound payloads, four Mermaid sources, eight rendered files. Prior ten-test evidence and current hash evidence are distinct. User-only local handoff; Innovation acknowledgment, public publication and tenant integration are pending separate work.
