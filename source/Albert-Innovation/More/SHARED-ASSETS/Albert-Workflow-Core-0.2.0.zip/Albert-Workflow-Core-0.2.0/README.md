# Albert Workflow Core 0.2.0

One shared definition binds the podcast and learning subsystem for three profiles. This local development package integrates frozen Prompt Process 0.3.0. It is not a qualification of the connected backend, Copilot tenant or witness-facing content. The study found useful first repairs, diminishing or negative additional returns, and continuing failures in fresh drafts; inspect the separately delivered study disposition before selecting a case export.

Start with [STAGE-RUNBOOK.md](STAGE-RUNBOOK.md). The exact generic entrypoint is [WF06](shared/imports/Albert-Prompt-Process-0.3.0/WF06-prompt-process.md). P07 makes source access and learner permission explicit, T06 checks developed pressure and retrieval in the actual script, P08 preserves depth during a verified edit, and P09 joins current reviews and stops further polishing. The underlying P06 writer, P01/P03 evidence checks and A02/A01 reviewers remain byte-identical imports.

| Profile | What changes | Durable storage |
|---|---|---|
| MVP prompt-only | Operator copies exact prompts between role chats and saves/reopens artifacts. No code, API or MCP required to run prompts. | Authorized ordinary case files; source/view/claims/conflict IDs form a small Markdown graph. |
| Full manual | Same prompts/gates plus full multi-witness case ledger and human-controlled joins. | Owner-managed files or explicitly configured SharePoint. |
| Full connected | Same prompt contracts through separately validated retrieval/persistence bindings and manual fallback. | Approved case store; tenant, authentication, retention and effect tests still required. |

The asset library MCP retrieves reusable assets. It is not by itself a case database, model runner or subagent scheduler. No API/MCP/tenant is installed by this package.

[Profile mapping](generated/profile-mapping.md) lists the exact file for each node and profile. [Diagrams](generated/diagrams.md) derive from `core/workflow-core.json`; never edit generated views by hand. [CI-INSTALL.md](CI-INSTALL.md) explains automated drift checking after installation in a repository. There is no active watcher here.

Imported Toolkit 0.2 documents retain their original revision/status and example results. They are provenance snapshots, not evidence this derivative passed. `DERIVATION-RECEIPT.json` binds this package's exact typed changes; current QA and preview receipts are supplied after validation. Old lesson ledger entries remain candidates with no automatic adoption. New process bindings are an explicitly authorized local development revision, not global/human/tenant promotion.

The public NotebookLlama tutorial supplies the source-preparation → writing → conversational-rewrite pattern. Our rewrite is optional and evidence-gated because additional passes can remove useful depth or introduce errors. We have not reproduced NotebookLM's private instructions or measured equivalence to its audio.

Maintenance requires Python only for packaging and diagrams. It is not an end-user MVP dependency. A model/provider/runtime change requires affected rechecks; no universal portability or model-availability claim is made. Preserve sealed prior packages for rollback.
