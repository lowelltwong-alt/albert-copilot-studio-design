#!/usr/bin/env python3
"""Generate and validate the Albert three-profile workflow views.

The JSON document in core/workflow-core.json is the sole editable workflow
definition.  This standard-library script is maintenance tooling: end users run
the prompt-only MVP with saved Markdown; they do not need Python, MCP, or an API.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "core" / "workflow-core.json"
GENERATED = ROOT / "generated"
IMPORT_ROOT = ROOT / "shared" / "imports"
ADOPTION_EVIDENCE_ROOT = ROOT / "shared" / "adoption-evidence"
ID_RE = re.compile(r"^[A-Z][A-Z0-9_.:-]{2,96}$")
PROFILE_IDS = ("PROFILE.MVP.PROMPT_ONLY", "PROFILE.FULL.MANUAL", "PROFILE.FULL.CONNECTED")


class ValidationError(ValueError):
    pass


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_json(value: Any) -> str:
    return json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationError(message)


def strict_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValidationError(f"duplicate JSON mapping key: {key}")
        result[key] = value
    return result


def objects(value: Any, name: str) -> list[dict[str, Any]]:
    require(isinstance(value, list), f"{name} must be a list")
    require(all(isinstance(item, dict) for item in value), f"{name} entries must be objects")
    return value


def strings(value: Any, name: str) -> list[str]:
    require(isinstance(value, list) and all(isinstance(item, str) for item in value),
            f"{name} must be a list of strings")
    require(len(value) == len(set(value)), f"{name} contains duplicate references")
    return value


def unique_ids(items: list[dict[str, Any]], kind: str) -> set[str]:
    found: set[str] = set()
    for item in items:
        item_id = item.get("id")
        require(isinstance(item_id, str) and ID_RE.fullmatch(item_id) is not None,
                f"invalid {kind} id: {item_id!r}")
        require(item_id not in found, f"duplicate {kind} id: {item_id}")
        found.add(item_id)
    return found


def safe_label(text: Any) -> str:
    """Return a Mermaid-safe label or reject a diagram-control injection."""
    require(isinstance(text, str) and text.strip(), "diagram label must be a non-empty string")
    require(not any(ch in text for ch in "\r\n[]{};`<>\"&"),
            "diagram label contains Mermaid/HTML control characters")
    return text.replace("\\", "\\\\")


def load_source() -> dict[str, Any]:
    try:
        value = json.loads(SOURCE.read_text(encoding="utf-8"), object_pairs_hook=strict_object)
    except FileNotFoundError as error:
        raise ValidationError(f"missing canonical definition: {SOURCE}") from error
    except json.JSONDecodeError as error:
        raise ValidationError(f"invalid canonical JSON: {error}") from error
    require(isinstance(value, dict), "canonical definition must be an object")
    return value


def validate(core: dict[str, Any]) -> None:
    require(type(core.get("schema_version")) is int and core.get("schema_version") == 1,
            "unsupported schema_version")
    require(core.get("workflow_id") == "ALBERT.WORKFLOW.CORE.V1", "unexpected workflow_id")
    require(core.get("future_canonical_directory") == "core/", "future canonical directory must be core/")
    for key in ("assets", "nodes", "edges", "profiles", "lessons", "evidence"):
        objects(core.get(key), key)

    assets = objects(core["assets"], "assets")
    asset_ids = unique_ids(assets, "asset")
    for asset in assets:
        path_text, expected = asset.get("path"), asset.get("sha256")
        require(isinstance(path_text, str) and path_text.startswith("shared/imports/") and
                not Path(path_text).is_absolute() and ".." not in Path(path_text).parts,
                f"asset {asset['id']} must be a portable source import")
        require(isinstance(expected, str) and re.fullmatch(r"[0-9a-f]{64}", expected) is not None,
                f"asset {asset['id']} has invalid sha256")
        path = ROOT / path_text
        require(path.is_file() and not path.is_symlink(), f"asset {asset['id']} is missing or symlinked: {path_text}")
        cursor = IMPORT_ROOT
        for part in path.relative_to(IMPORT_ROOT).parts:
            cursor /= part
            require(not cursor.is_symlink(), f"asset {asset['id']} is below a symlink: {path_text}")
        try:
            path.resolve(strict=True).relative_to(IMPORT_ROOT.resolve(strict=True))
        except ValueError as error:
            raise ValidationError(f"asset {asset['id']} escapes shared/imports: {path_text}") from error
        require(sha256(path) == expected, f"asset {asset['id']} has stale hash: {path_text}")

    nodes = objects(core["nodes"], "nodes")
    node_ids = unique_ids(nodes, "node")
    for node in nodes:
        safe_label(node.get("label"))
        require(node.get("kind") in {"work", "review", "decision", "lesson"},
                f"node {node['id']} has invalid kind")
        require(isinstance(node.get("impact"), str) and node['impact'].strip(),
                f"node {node['id']} needs a dependency impact")
        refs = strings(node.get("asset_ids"), f"node {node['id']} asset_ids")
        require(refs, f"node {node['id']} needs asset_ids")
        require(set(refs) <= asset_ids, f"node {node['id']} references a nonexistent asset")
        prompts = strings(node.get("prompt_ids"), f"node {node['id']} prompt_ids")
        require(set(prompts) <= asset_ids and all(prompt.startswith("ASSET.P") for prompt in prompts),
                f"node {node['id']} references a nonexistent or non-prompt asset")

    edges = objects(core["edges"], "edges")
    edge_ids = unique_ids(edges, "edge")
    for edge in edges:
        require(edge.get("from") in node_ids and edge.get("to") in node_ids,
                f"edge {edge['id']} references a nonexistent node")
        require(edge["from"] != edge["to"], f"edge {edge['id']} is self-referential")
        safe_label(edge.get("label"))
    require(edge_ids, "at least one edge is required")

    profiles = objects(core["profiles"], "profiles")
    profile_ids = unique_ids(profiles, "profile")
    require(tuple(item["id"] for item in profiles) == PROFILE_IDS,
            "profiles must be the ordered MVP, manual-full, connected-full set")
    for profile in profiles:
        require(set(strings(profile.get("node_ids"), f"profile {profile['id']} node_ids")) == node_ids,
                f"profile {profile['id']} must use every shared-core node")
        safe_label(profile.get("label"))
    mvp, manual, connected = profiles
    require(mvp.get("transport") == "manual_prompt_and_saved_markdown" and mvp.get("mcp_api") == "none",
            "MVP must remain prompt-only with manual saved artifacts")
    require(manual.get("transport") == "operator_managed_files_and_ledger" and manual.get("mcp_api") == "none",
            "manual full profile must have no MCP/API")
    require(connected.get("transport") == "optional_documented_bindings" and
            connected.get("mcp_api") == "untested_backend_or_tenant",
            "connected profile must remain an untested optional binding")

    evidence = objects(core["evidence"], "evidence")
    evidence_ids = unique_ids(evidence, "evidence")
    evidence_by_id = {item["id"]: item for item in evidence}
    asset_by_id = {item["id"]: item for item in assets}
    lessons = objects(core["lessons"], "lessons")
    lesson_ids = unique_ids(lessons, "lesson")
    for lesson in lessons:
        require(isinstance(lesson.get("revision_id"), str) and lesson['revision_id'].strip(),
                f"lesson {lesson['id']} needs a revision_id")
        require(isinstance(lesson.get("summary"), str) and lesson['summary'].strip(),
                f"lesson {lesson['id']} needs a summary")
        status = lesson.get("status")
        require(status in {"candidate", "adopted"}, f"lesson {lesson['id']} has invalid status")
        require(set(strings(lesson.get("affected_node_ids"), f"lesson {lesson['id']} affected_node_ids")) <= node_ids,
                f"lesson {lesson['id']} references a nonexistent node")
        require(set(strings(lesson.get("affected_asset_ids"), f"lesson {lesson['id']} affected_asset_ids")) <= asset_ids,
                f"lesson {lesson['id']} references a nonexistent asset")
        require(lesson['affected_node_ids'] and lesson['affected_asset_ids'],
                f"lesson {lesson['id']} needs affected node and asset dependencies")
        if status == "candidate":
            require(lesson.get("active_profiles") == [],
                    f"candidate lesson {lesson['id']} cannot be active")
            require(lesson.get("adoption_evidence_id") is None,
                    f"candidate lesson {lesson['id']} cannot contain adoption evidence")
        else:
            adoption = lesson.get("adoption_evidence_id")
            require(adoption in evidence_ids, f"adopted lesson {lesson['id']} lacks exact evidence")
            record = evidence_by_id[adoption]
            validate_adoption_evidence(record, lesson, asset_by_id)
            require(lesson.get("active_profiles") == list(PROFILE_IDS),
                    f"adopted lesson {lesson['id']} must explicitly apply to all profiles")
    require(lesson_ids, "at least one lesson is required")


def validate_adoption_evidence(record: dict[str, Any], lesson: dict[str, Any], asset_by_id: dict[str, dict[str, Any]]) -> None:
    """Require a local, digest-pinned decision and test receipt; it cannot authenticate a human."""
    required = ("kind", "owner", "decision", "decided_at", "lesson_id", "revision_id", "path", "sha256")
    require(all(isinstance(record.get(key), str) and record[key] for key in required),
            f"adoption evidence {record.get('id')} lacks decision metadata")
    require(record["kind"] == "human_adoption_decision" and record["decision"] == "adopt",
            f"adoption evidence {record['id']} is not an adopt decision")
    require(record["lesson_id"] == lesson["id"] and record["revision_id"] == lesson.get("revision_id"),
            f"adoption evidence {record['id']} does not bind this lesson revision")
    path_text = record["path"]
    path = ROOT / path_text
    require(path_text.startswith("shared/adoption-evidence/") and ".." not in Path(path_text).parts and
            path.is_file() and not path.is_symlink(), f"adoption evidence {record['id']} path is unsafe")
    try:
        path.resolve(strict=True).relative_to(ADOPTION_EVIDENCE_ROOT.resolve(strict=True))
    except ValueError as error:
        raise ValidationError(f"adoption evidence {record['id']} escapes its evidence root") from error
    require(re.fullmatch(r"[0-9a-f]{64}", record["sha256"]) is not None and sha256(path) == record["sha256"],
            f"adoption evidence {record['id']} has stale digest")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=strict_object)
    except json.JSONDecodeError as error:
        raise ValidationError(f"adoption evidence {record['id']} is invalid JSON") from error
    require(isinstance(payload, dict) and payload.get("lesson_id") == lesson["id"] and
            payload.get("revision_id") == lesson.get("revision_id") and payload.get("owner") == record["owner"] and
            payload.get("decision") == "adopt", f"adoption evidence {record['id']} does not match its metadata")
    hashes = payload.get("prompt_asset_hashes")
    require(isinstance(hashes, dict) and set(hashes) == set(lesson["affected_asset_ids"]),
            f"adoption evidence {record['id']} does not pin every affected asset")
    for asset in lesson["affected_asset_ids"]:
        require(asset in asset_by_id and hashes[asset] == asset_by_id[asset]["sha256"],
                f"adoption evidence {record['id']} has an invalid asset revision")
    test = payload.get("test_evidence")
    require(isinstance(test, dict) and all(isinstance(test.get(key), str) and test[key] for key in
            ("path", "sha256", "input_revision", "outcome")) and test["outcome"] == "pass",
            f"adoption evidence {record['id']} lacks exact test evidence")
    test_path = ROOT / test["path"]
    require(test["path"].startswith("shared/adoption-evidence/") and ".." not in Path(test["path"]).parts and
            test_path.is_file() and not test_path.is_symlink() and re.fullmatch(r"[0-9a-f]{64}", test["sha256"]) is not None and
            sha256(test_path) == test["sha256"], f"adoption evidence {record['id']} test evidence is not pinned")


def make_mermaid(core: dict[str, Any], profile: dict[str, Any] | None = None) -> str:
    lines = ["flowchart TD", "  classDef shared fill:#eef6ff,stroke:#2b6cb0,color:#102a43", "  classDef review fill:#fff8db,stroke:#b7791f,color:#3d2b00"]
    if profile is not None:
        lines += [f'  ADAPTER["{safe_label(profile["label"])}: {safe_label(profile["operator_record"])}"]:::shared',
                  f'  %% Transport {profile["transport"]}; MCP/API {profile["mcp_api"]}. See generated profile mapping.']
    for node in core["nodes"]:
        class_name = "review" if node["kind"] in {"review", "decision", "lesson"} else "shared"
        lines.append(f'  {node["id"]}["{safe_label(node["label"])}"]:::{class_name}')
    for edge in core["edges"]:
        lines.append(f'  {edge["from"]} -->|"{safe_label(edge["label"])}"| {edge["to"]}')
    if profile is not None:
        lines += ["  ADAPTER --> NODE.INTAKE"]
    return "\n".join(lines) + "\n"


def make_mapping(core: dict[str, Any], source_hash: str) -> str:
    lines = [
        "# Generated workflow and profile mapping",
        "",
        "Do not edit this file or `workflow.mmd`; run `python generator.py --write` after an approved core change.",
        f"Canonical definition: `core/workflow-core.json` (`sha256:{source_hash}`).",
        "",
        "## Profiles",
        "",
        "| ID | Profile | Transport | MCP/API status | Operator record |",
        "| --- | --- | --- | --- | --- |",
    ]
    for p in core["profiles"]:
        lines.append(f"| `{p['id']}` | {p['label']} | `{p['transport']}` | `{p['mcp_api']}` | {p['operator_record']} |")
    lines += ["", "## Shared nodes", "", "| ID | Node | Prompt / source assets | Dependency impact |", "| --- | --- | --- | --- |"]
    for node in core["nodes"]:
        refs = list(dict.fromkeys([*node['asset_ids'], *node['prompt_ids']]))
        assets = ", ".join(f"[{asset}](../{next(a['path'] for a in core['assets'] if a['id'] == asset)})" for asset in refs)
        lines.append(f"| `{node['id']}` | {node['label']} | {assets} | {node['impact']} |")
    lines += ["", "## Edges", "", "| ID | From | To | Contract |", "| --- | --- | --- | --- |"]
    for edge in core["edges"]:
        lines.append(f"| `{edge['id']}` | `{edge['from']}` | `{edge['to']}` | {edge['label']} |")
    lines += ["", "## Lesson ledger", "", "| ID | Revision and finding | State | Active profiles | Exact decision evidence |", "| --- | --- | --- | --- | --- |"]
    for lesson in core["lessons"]:
        active = ", ".join(lesson["active_profiles"]) or "—"
        evidence = lesson["adoption_evidence_id"] or "—"
        lines.append(f"| `{lesson['id']}` | `{lesson['revision_id']}`: {lesson['summary']} | {lesson['status']} | {active} | `{evidence}` |")
    return "\n".join(lines) + "\n"


def make_operating_brief(core: dict[str, Any], source_hash: str) -> str:
    lines = [
        "# Generated lesson operating brief",
        "",
        f"Derived from `core/workflow-core.json` (`sha256:{source_hash}`). Do not hand edit.",
        "",
        "Candidate lessons are visible to reviewers as hypotheses only. They do not alter a prompt, profile, adapter, or user operation. An adopted lesson is active only after its local digest-pinned decision and test evidence validates.",
        "",
    ]
    for profile in core["profiles"]:
        lines += [f"## {profile['label']} (`{profile['id']}`)", "", f"Operator mode: {profile['operator_record']}.", "",
                  "| Lesson | State | Operating instruction | Affected nodes / assets |", "| --- | --- | --- | --- |"]
        for lesson in core["lessons"]:
            applies = profile["id"] in lesson["active_profiles"]
            instruction = "Apply the adopted revision bound in its decision evidence." if applies else "Candidate only; preserve current imported prompt bytes and record evidence without changing behavior."
            refs = ", ".join([*lesson["affected_node_ids"], *lesson["affected_asset_ids"]])
            lines.append(f"| `{lesson['id']}`: {lesson['summary']} | {lesson['status']} | {instruction} | {refs} |")
        lines.append("")
    return "\n".join(lines) + "\n"


def expected_outputs(core: dict[str, Any]) -> dict[Path, str]:
    source_hash = sha256(SOURCE)
    mapping = make_mapping(core, source_hash)
    views = {GENERATED / "workflow.mmd": make_mermaid(core), GENERATED / "profile-mapping.md": mapping,
             GENERATED / "lesson-operating-brief.md": make_operating_brief(core, source_hash)}
    profile_files = ("mvp-prompt-only.mmd", "full-manual.mmd", "full-connected.mmd")
    for profile, filename in zip(core["profiles"], profile_files, strict=True):
        views[GENERATED / filename] = make_mermaid(core, profile)
    diagram_page = ['# Generated Mermaid diagrams', '',
                    f'Canonical SHA-256: `{source_hash}`. Generated alongside each standalone `.mmd`; do not hand edit.', '',
                    'These diagrams show the shared podcast and learning subsystem with each profile adapter. Connected bindings and prompt adoption still require their documented implementation/owner gates.', '']
    for profile, filename in zip(core['profiles'], profile_files, strict=True):
        diagram_page += [f"## {profile['label']}", '', '```mermaid',
                         views[GENERATED / filename].rstrip(), '```', '']
    views[GENERATED / 'diagrams.md'] = '\n'.join(diagram_page) + '\n'
    manifest = {
        "generated_by": "generator.py",
        "generator_sha256": sha256(ROOT / "generator.py"),
        "schema_version": 1,
        "source": "core/workflow-core.json",
        "source_sha256": source_hash,
        "import_asset_sha256": {asset["id"]: asset["sha256"] for asset in core["assets"]},
        "view_sha256": {str(path.relative_to(ROOT)).replace("\\", "/"): hashlib.sha256(content.encode("utf-8")).hexdigest() for path, content in views.items()},
        "outputs": [str(path.relative_to(ROOT)).replace("\\", "/") for path in views],
    }
    result = dict(views)
    result[GENERATED / "manifest.json"] = canonical_json(manifest)
    return result


def atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", newline="\n", delete=False, dir=path.parent) as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    os.replace(temporary, path)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--write", action="store_true", help="validate source and write generated views")
    mode.add_argument("--check", action="store_true", help="validate source and fail if generated views are stale")
    args = parser.parse_args(argv)
    try:
        core = load_source()
        validate(core)
        expected = expected_outputs(core)
        if args.write:
            for path, content in expected.items():
                atomic_write(path, content)
            print("validated core and regenerated views")
            return 0
        stale = [str(path.relative_to(ROOT)) for path, content in expected.items()
                 if not path.is_file() or path.read_text(encoding="utf-8") != content]
        if stale:
            raise ValidationError("stale generated view(s): " + ", ".join(stale))
        print("workflow core and generated views are fresh")
        return 0
    except ValidationError as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
