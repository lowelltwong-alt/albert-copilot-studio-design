# Regenerate and check all four diagrams

The only workflow definition is `core/workflow-core.json`. Every prompt binding is hash-pinned. After an authorized typed definition/import change, run from this package:

```text
python generator.py --write
python test_generator.py -v
python generator.py --check
```

The generator produces `workflow.mmd`, `mvp-prompt-only.mmd`, `full-manual.mmd`, `full-connected.mmd`, their Markdown views, file mapping and lesson brief. Commit definition, imports and generated views together. Check before regeneration in CI so stale committed views cause a failure. A change outside this subsystem must be reflected in its definition; the generator cannot infer undocumented workflow changes.

A repository owner can install a job triggered on push, pull request and manual dispatch. In a clean isolated checkout with Python 3.12, set the package directory to `outputs/Albert-Workflow-Core-0.2.0`, run `generator.py --check`, `test_generator.py -v`, then `generator.py --check`, and require the job before merging. Use the repository's reviewed action versions and permission policy. No workflow is installed or active in this local delivery.

Freshness validation is separate from visual QA. After each graph change, use the version-bound Mermaid renderer, render all four source files, and inspect the outputs for legibility, clipping and correct paths. Bind core/generator/renderer/source/preview hashes in a new receipt; preserve previous previews. Renderer maintenance is not needed to operate the prompt-only MVP. No live watcher, automatic lesson adoption or deployment is implied.
