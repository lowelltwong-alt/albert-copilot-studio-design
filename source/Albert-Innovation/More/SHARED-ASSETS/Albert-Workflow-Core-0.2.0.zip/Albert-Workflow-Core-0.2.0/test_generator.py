"""Focused checks for canonical invariants and generated-view freshness."""
from __future__ import annotations

import copy
import subprocess
import sys
import unittest

import generator


class GeneratorChecks(unittest.TestCase):
    def setUp(self) -> None:
        self.core = generator.load_source()

    def assert_invalid(self, changed: dict) -> None:
        with self.assertRaises(generator.ValidationError):
            generator.validate(changed)

    def test_clean_baseline(self) -> None:
        generator.validate(self.core)

    def test_rejects_duplicate_json_mapping_key(self) -> None:
        with self.assertRaises(generator.ValidationError):
            generator.strict_object([("id", "one"), ("id", "two")])

    def test_rejects_boolean_schema_version(self) -> None:
        changed = copy.deepcopy(self.core)
        changed["schema_version"] = True
        self.assert_invalid(changed)

    def test_rejects_duplicate_node_and_missing_edge_target(self) -> None:
        duplicate = copy.deepcopy(self.core)
        duplicate["nodes"].append(copy.deepcopy(duplicate["nodes"][0]))
        self.assert_invalid(duplicate)
        missing = copy.deepcopy(self.core)
        missing["edges"][0]["to"] = "NODE.DOES_NOT_EXIST"
        self.assert_invalid(missing)

    def test_rejects_stale_asset_hash_and_path_escape(self) -> None:
        stale = copy.deepcopy(self.core)
        stale["assets"][0]["sha256"] = "0" * 64
        self.assert_invalid(stale)
        escaped = copy.deepcopy(self.core)
        escaped["assets"][0]["path"] = "shared/imports/../outside.md"
        self.assert_invalid(escaped)

    def test_rejects_adoption_without_digest_pinned_evidence(self) -> None:
        changed = copy.deepcopy(self.core)
        lesson = changed["lessons"][0]
        lesson["status"] = "adopted"
        lesson["active_profiles"] = list(generator.PROFILE_IDS)
        lesson["adoption_evidence_id"] = "EVIDENCE.MISSING"
        self.assert_invalid(changed)

    def test_rejects_incomplete_candidate_and_duplicate_references(self) -> None:
        for key, invalid in [('revision_id', ''), ('summary', ''),
                             ('affected_node_ids', []), ('affected_asset_ids', [])]:
            changed = copy.deepcopy(self.core)
            changed['lessons'][0][key] = invalid
            with self.subTest(key=key):
                self.assert_invalid(changed)
        changed = copy.deepcopy(self.core)
        changed['profiles'][0]['node_ids'].append(changed['profiles'][0]['node_ids'][0])
        self.assert_invalid(changed)

    def test_review_repair_export_and_learning_stages_exist(self) -> None:
        required = {('NODE.PLAN', 'NODE.PLAN_REVIEW'),
                    ('NODE.PLAN_REVIEW', 'NODE.DRAFT'),
                    ('NODE.SOURCE_REVIEW', 'NODE.QUALITY_GATE'),
                    ('NODE.CRAFT_REVIEW', 'NODE.QUALITY_GATE'),
                    ('NODE.QUALITY_GATE', 'NODE.REPAIR'),
                    ('NODE.QUALITY_GATE', 'NODE.HOLD'),
                    ('NODE.REPAIR', 'NODE.FINAL_REVIEW'),
                    ('NODE.FINAL_REVIEW', 'NODE.EXPORT'),
                    ('NODE.FINAL_REVIEW', 'NODE.HOLD'),
                    ('NODE.REVISION', 'NODE.LESSON_LOOKUP')}
        actual = {(e['from'], e['to']) for e in self.core['edges']}
        self.assertTrue(required <= actual, f'Missing required stage edges: {required - actual}')

    def test_rejects_mermaid_and_html_injection(self) -> None:
        for payload in ('x"] --> NODE.DRAFT', '<img src=x>', 'a & b'):
            with self.subTest(payload=payload):
                with self.assertRaises(generator.ValidationError):
                    generator.safe_label(payload)

    def test_detects_stale_generated_view_and_restores_baseline(self) -> None:
        path = generator.GENERATED / "workflow.mmd"
        original = path.read_bytes()
        try:
            path.write_bytes(original + b"stale\n")
            result = subprocess.run([sys.executable, "generator.py", "--check"], cwd=generator.ROOT,
                                    text=True, capture_output=True, check=False)
            self.assertEqual(result.returncode, 2)
            self.assertIn("stale generated view", result.stderr)
        finally:
            path.write_bytes(original)
        result = subprocess.run([sys.executable, "generator.py", "--check"], cwd=generator.ROOT,
                                text=True, capture_output=True, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == "__main__":
    unittest.main()
