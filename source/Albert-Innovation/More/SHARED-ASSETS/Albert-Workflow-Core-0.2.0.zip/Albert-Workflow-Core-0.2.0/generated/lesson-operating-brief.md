# Generated lesson operating brief

Derived from `core/workflow-core.json` (`sha256:c86dd4d5ee578e75d01541c64770313b4af9ec6095fbb1e226ac637a37b4260a`). Do not hand edit.

Candidate lessons are visible to reviewers as hypotheses only. They do not alter a prompt, profile, adapter, or user operation. An adopted lesson is active only after its local digest-pinned decision and test evidence validates.

## MVP prompt-only (`PROFILE.MVP.PROMPT_ONLY`)

Operator mode: manual saves and reopen checks.

| Lesson | State | Operating instruction | Affected nodes / assets |
| --- | --- | --- | --- |
| `LESSON.CANDIDATE.SCORE_NOT_ADOPTION`: A good score is evidence to investigate, never automatic adoption. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.LEDGER, NODE.DECISION, ASSET.A01, ASSET.PROMOTION |
| `LESSON.CANDIDATE.SHARED_REVISION_GATE`: Active shared changes need owner evidence and profile-specific adapter rechecks. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.DECISION, NODE.REVISION, ASSET.WF04, ASSET.PROMOTION |
| `LESSON.CANDIDATE.SPEAKER_ATTRIBUTION`: Preserve source speaker attribution; do not collapse a source statement into an unattributed fact. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.SOURCE, NODE.CLAIMS, NODE.DRAFT, ASSET.P06, ASSET.P01 |
| `LESSON.CANDIDATE.MISSING_ARTIFACT_MEMORY`: A missing artifact does not establish a witness present-memory limit. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.SOURCE, NODE.WITNESS, NODE.CLAIMS, ASSET.P06, ASSET.P01 |
| `LESSON.CANDIDATE.CONDITIONAL_PROMISE_OWNERSHIP`: A conditional promise establishes neither present ownership nor absence of ownership. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.SOURCE, NODE.CLAIMS, ASSET.P06, ASSET.P01 |
| `LESSON.CANDIDATE.CLAIM_MAP_COVERAGE`: Every material spoken claim and qualification needs claim-map coverage. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.CLAIMS, NODE.DRAFT, NODE.SOURCE_REVIEW, ASSET.P06, ASSET.P01 |
| `LESSON.CANDIDATE.HOST_INTERACTION_EVIDENCE`: Two alternating topical paragraphs alone do not demonstrate consequential two-host interaction. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.CRAFT_REVIEW, ASSET.A02, ASSET.T05 |
| `LESSON.CANDIDATE.CLEAR_INSTRUCTION_DIAGNOSIS`: Check a failure against existing clear instructions before proposing an additional prompt rule. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.A01_AUDIT, NODE.LEDGER, ASSET.A01, ASSET.P05 |
| `LESSON.CANDIDATE.WRITER_REVIEWER_CALIBRATION`: Observed writer execution and reviewer calibration gaps are not yet a proven prompt defect. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.DRAFT, NODE.CRAFT_REVIEW, NODE.A01_AUDIT, ASSET.P06, ASSET.A02, ASSET.A01 |
| `LESSON.CANDIDATE.LEARNER_ALLOWED_EXTERNAL`: Author access to an external document is not permission to teach it; each proposition needs an explicit learner-allowed basis. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.WITNESS, NODE.CLAIMS, NODE.PLAN, ASSET.P06, ASSET.WF05 |
| `LESSON.CANDIDATE.PROPOSITION_SPECIFIC_UNKNOWN`: Unknown or inference limits are proposition-specific and cannot transfer to adjacent events. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.SOURCE, NODE.CLAIMS, NODE.SOURCE_REVIEW, ASSET.P06, ASSET.P01 |

## Full without MCP or API (`PROFILE.FULL.MANUAL`)

Operator mode: full manual ledger operations.

| Lesson | State | Operating instruction | Affected nodes / assets |
| --- | --- | --- | --- |
| `LESSON.CANDIDATE.SCORE_NOT_ADOPTION`: A good score is evidence to investigate, never automatic adoption. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.LEDGER, NODE.DECISION, ASSET.A01, ASSET.PROMOTION |
| `LESSON.CANDIDATE.SHARED_REVISION_GATE`: Active shared changes need owner evidence and profile-specific adapter rechecks. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.DECISION, NODE.REVISION, ASSET.WF04, ASSET.PROMOTION |
| `LESSON.CANDIDATE.SPEAKER_ATTRIBUTION`: Preserve source speaker attribution; do not collapse a source statement into an unattributed fact. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.SOURCE, NODE.CLAIMS, NODE.DRAFT, ASSET.P06, ASSET.P01 |
| `LESSON.CANDIDATE.MISSING_ARTIFACT_MEMORY`: A missing artifact does not establish a witness present-memory limit. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.SOURCE, NODE.WITNESS, NODE.CLAIMS, ASSET.P06, ASSET.P01 |
| `LESSON.CANDIDATE.CONDITIONAL_PROMISE_OWNERSHIP`: A conditional promise establishes neither present ownership nor absence of ownership. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.SOURCE, NODE.CLAIMS, ASSET.P06, ASSET.P01 |
| `LESSON.CANDIDATE.CLAIM_MAP_COVERAGE`: Every material spoken claim and qualification needs claim-map coverage. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.CLAIMS, NODE.DRAFT, NODE.SOURCE_REVIEW, ASSET.P06, ASSET.P01 |
| `LESSON.CANDIDATE.HOST_INTERACTION_EVIDENCE`: Two alternating topical paragraphs alone do not demonstrate consequential two-host interaction. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.CRAFT_REVIEW, ASSET.A02, ASSET.T05 |
| `LESSON.CANDIDATE.CLEAR_INSTRUCTION_DIAGNOSIS`: Check a failure against existing clear instructions before proposing an additional prompt rule. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.A01_AUDIT, NODE.LEDGER, ASSET.A01, ASSET.P05 |
| `LESSON.CANDIDATE.WRITER_REVIEWER_CALIBRATION`: Observed writer execution and reviewer calibration gaps are not yet a proven prompt defect. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.DRAFT, NODE.CRAFT_REVIEW, NODE.A01_AUDIT, ASSET.P06, ASSET.A02, ASSET.A01 |
| `LESSON.CANDIDATE.LEARNER_ALLOWED_EXTERNAL`: Author access to an external document is not permission to teach it; each proposition needs an explicit learner-allowed basis. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.WITNESS, NODE.CLAIMS, NODE.PLAN, ASSET.P06, ASSET.WF05 |
| `LESSON.CANDIDATE.PROPOSITION_SPECIFIC_UNKNOWN`: Unknown or inference limits are proposition-specific and cannot transfer to adjacent events. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.SOURCE, NODE.CLAIMS, NODE.SOURCE_REVIEW, ASSET.P06, ASSET.P01 |

## Full with MCP/API bindings (`PROFILE.FULL.CONNECTED`)

Operator mode: binding receipt plus full ledger operations.

| Lesson | State | Operating instruction | Affected nodes / assets |
| --- | --- | --- | --- |
| `LESSON.CANDIDATE.SCORE_NOT_ADOPTION`: A good score is evidence to investigate, never automatic adoption. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.LEDGER, NODE.DECISION, ASSET.A01, ASSET.PROMOTION |
| `LESSON.CANDIDATE.SHARED_REVISION_GATE`: Active shared changes need owner evidence and profile-specific adapter rechecks. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.DECISION, NODE.REVISION, ASSET.WF04, ASSET.PROMOTION |
| `LESSON.CANDIDATE.SPEAKER_ATTRIBUTION`: Preserve source speaker attribution; do not collapse a source statement into an unattributed fact. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.SOURCE, NODE.CLAIMS, NODE.DRAFT, ASSET.P06, ASSET.P01 |
| `LESSON.CANDIDATE.MISSING_ARTIFACT_MEMORY`: A missing artifact does not establish a witness present-memory limit. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.SOURCE, NODE.WITNESS, NODE.CLAIMS, ASSET.P06, ASSET.P01 |
| `LESSON.CANDIDATE.CONDITIONAL_PROMISE_OWNERSHIP`: A conditional promise establishes neither present ownership nor absence of ownership. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.SOURCE, NODE.CLAIMS, ASSET.P06, ASSET.P01 |
| `LESSON.CANDIDATE.CLAIM_MAP_COVERAGE`: Every material spoken claim and qualification needs claim-map coverage. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.CLAIMS, NODE.DRAFT, NODE.SOURCE_REVIEW, ASSET.P06, ASSET.P01 |
| `LESSON.CANDIDATE.HOST_INTERACTION_EVIDENCE`: Two alternating topical paragraphs alone do not demonstrate consequential two-host interaction. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.CRAFT_REVIEW, ASSET.A02, ASSET.T05 |
| `LESSON.CANDIDATE.CLEAR_INSTRUCTION_DIAGNOSIS`: Check a failure against existing clear instructions before proposing an additional prompt rule. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.A01_AUDIT, NODE.LEDGER, ASSET.A01, ASSET.P05 |
| `LESSON.CANDIDATE.WRITER_REVIEWER_CALIBRATION`: Observed writer execution and reviewer calibration gaps are not yet a proven prompt defect. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.DRAFT, NODE.CRAFT_REVIEW, NODE.A01_AUDIT, ASSET.P06, ASSET.A02, ASSET.A01 |
| `LESSON.CANDIDATE.LEARNER_ALLOWED_EXTERNAL`: Author access to an external document is not permission to teach it; each proposition needs an explicit learner-allowed basis. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.WITNESS, NODE.CLAIMS, NODE.PLAN, ASSET.P06, ASSET.WF05 |
| `LESSON.CANDIDATE.PROPOSITION_SPECIFIC_UNKNOWN`: Unknown or inference limits are proposition-specific and cannot transfer to adjacent events. | candidate | Candidate only; preserve current imported prompt bytes and record evidence without changing behavior. | NODE.SOURCE, NODE.CLAIMS, NODE.SOURCE_REVIEW, ASSET.P06, ASSET.P01 |

