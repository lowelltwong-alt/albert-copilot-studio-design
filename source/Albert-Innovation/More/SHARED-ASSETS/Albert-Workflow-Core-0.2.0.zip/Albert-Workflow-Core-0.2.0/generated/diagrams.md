# Generated Mermaid diagrams

Canonical SHA-256: `c86dd4d5ee578e75d01541c64770313b4af9ec6095fbb1e226ac637a37b4260a`. Generated alongside each standalone `.mmd`; do not hand edit.

These diagrams show the shared podcast and learning subsystem with each profile adapter. Connected bindings and prompt adoption still require their documented implementation/owner gates.

## MVP prompt-only

```mermaid
flowchart TD
  classDef shared fill:#eef6ff,stroke:#2b6cb0,color:#102a43
  classDef review fill:#fff8db,stroke:#b7791f,color:#3d2b00
  ADAPTER["MVP prompt-only: manual saves and reopen checks"]:::shared
  %% Transport manual_prompt_and_saved_markdown; MCP/API none. See generated profile mapping.
  NODE.INTAKE["Freeze intake and authority"]:::shared
  NODE.SOURCE["Build source and attribution map"]:::shared
  NODE.WITNESS["Separate author research from witness export"]:::shared
  NODE.CLAIMS["Create permitted claim map"]:::shared
  NODE.PLAN["Plan conversational two-host episode"]:::shared
  NODE.DRAFT["Draft and save conversational script"]:::shared
  NODE.SOURCE_REVIEW["Independent source review"]:::review
  NODE.CRAFT_REVIEW["Independent A02 craft review"]:::review
  NODE.A01_AUDIT["A01 reviewer audit"]:::review
  NODE.LEDGER["Record candidate or adopted lesson"]:::review
  NODE.DECISION["Human adoption decision"]:::review
  NODE.REVISION["Publish shared revision reference"]:::review
  NODE.LESSON_LOOKUP["Retrieve applicable lessons"]:::shared
  NODE.PLAN_REVIEW["Check source premises before drafting"]:::review
  NODE.QUALITY_GATE["Join source and craft decisions"]:::review
  NODE.REPAIR["One bounded conversational rewrite"]:::shared
  NODE.FINAL_REVIEW["Recheck the whole revised assembly"]:::review
  NODE.EXPORT["Export reviewed speech and timing"]:::shared
  NODE.HOLD["Retain unresolved findings and stop"]:::review
  NODE.INTAKE -->|"authorized case inputs"| NODE.SOURCE
  NODE.SOURCE -->|"attributed source view"| NODE.WITNESS
  NODE.WITNESS -->|"permitted proposition set"| NODE.CLAIMS
  NODE.CLAIMS -->|"claim-map coverage"| NODE.PLAN
  NODE.PLAN -->|"plan and supported recall anchors"| NODE.PLAN_REVIEW
  NODE.DRAFT -->|"frozen full assembly"| NODE.SOURCE_REVIEW
  NODE.DRAFT -->|"frozen full assembly"| NODE.CRAFT_REVIEW
  NODE.SOURCE_REVIEW -->|"evidence review receipt"| NODE.QUALITY_GATE
  NODE.CRAFT_REVIEW -->|"A02 craft review receipt"| NODE.QUALITY_GATE
  NODE.A01_AUDIT -->|"bounded candidate proposal"| NODE.LEDGER
  NODE.LEDGER -->|"candidate plus exact evidence"| NODE.DECISION
  NODE.DECISION -->|"human adoption only"| NODE.REVISION
  NODE.INTAKE -->|"local lesson search"| NODE.LESSON_LOOKUP
  NODE.LESSON_LOOKUP -->|"applicable IDs and test probes"| NODE.PLAN
  NODE.PLAN_REVIEW -->|"checked premises"| NODE.DRAFT
  NODE.PLAN_REVIEW -->|"unresolved source or permission gap"| NODE.HOLD
  NODE.QUALITY_GATE -->|"both pass on exact draft"| NODE.EXPORT
  NODE.QUALITY_GATE -->|"verified repairable findings"| NODE.REPAIR
  NODE.REPAIR -->|"new full assembly and change receipt"| NODE.FINAL_REVIEW
  NODE.FINAL_REVIEW -->|"both pass on exact new assembly"| NODE.EXPORT
  NODE.FINAL_REVIEW -->|"unresolved after bounded repair"| NODE.HOLD
  NODE.QUALITY_GATE -->|"triggered worker or reviewer issue"| NODE.A01_AUDIT
  NODE.FINAL_REVIEW -->|"instruction-output evidence"| NODE.A01_AUDIT
  NODE.REVISION -->|"next run with approved revision"| NODE.LESSON_LOOKUP
  NODE.QUALITY_GATE -->|"unresolved or non-repairable failure"| NODE.HOLD
  ADAPTER --> NODE.INTAKE
```

## Full without MCP or API

```mermaid
flowchart TD
  classDef shared fill:#eef6ff,stroke:#2b6cb0,color:#102a43
  classDef review fill:#fff8db,stroke:#b7791f,color:#3d2b00
  ADAPTER["Full without MCP or API: full manual ledger operations"]:::shared
  %% Transport operator_managed_files_and_ledger; MCP/API none. See generated profile mapping.
  NODE.INTAKE["Freeze intake and authority"]:::shared
  NODE.SOURCE["Build source and attribution map"]:::shared
  NODE.WITNESS["Separate author research from witness export"]:::shared
  NODE.CLAIMS["Create permitted claim map"]:::shared
  NODE.PLAN["Plan conversational two-host episode"]:::shared
  NODE.DRAFT["Draft and save conversational script"]:::shared
  NODE.SOURCE_REVIEW["Independent source review"]:::review
  NODE.CRAFT_REVIEW["Independent A02 craft review"]:::review
  NODE.A01_AUDIT["A01 reviewer audit"]:::review
  NODE.LEDGER["Record candidate or adopted lesson"]:::review
  NODE.DECISION["Human adoption decision"]:::review
  NODE.REVISION["Publish shared revision reference"]:::review
  NODE.LESSON_LOOKUP["Retrieve applicable lessons"]:::shared
  NODE.PLAN_REVIEW["Check source premises before drafting"]:::review
  NODE.QUALITY_GATE["Join source and craft decisions"]:::review
  NODE.REPAIR["One bounded conversational rewrite"]:::shared
  NODE.FINAL_REVIEW["Recheck the whole revised assembly"]:::review
  NODE.EXPORT["Export reviewed speech and timing"]:::shared
  NODE.HOLD["Retain unresolved findings and stop"]:::review
  NODE.INTAKE -->|"authorized case inputs"| NODE.SOURCE
  NODE.SOURCE -->|"attributed source view"| NODE.WITNESS
  NODE.WITNESS -->|"permitted proposition set"| NODE.CLAIMS
  NODE.CLAIMS -->|"claim-map coverage"| NODE.PLAN
  NODE.PLAN -->|"plan and supported recall anchors"| NODE.PLAN_REVIEW
  NODE.DRAFT -->|"frozen full assembly"| NODE.SOURCE_REVIEW
  NODE.DRAFT -->|"frozen full assembly"| NODE.CRAFT_REVIEW
  NODE.SOURCE_REVIEW -->|"evidence review receipt"| NODE.QUALITY_GATE
  NODE.CRAFT_REVIEW -->|"A02 craft review receipt"| NODE.QUALITY_GATE
  NODE.A01_AUDIT -->|"bounded candidate proposal"| NODE.LEDGER
  NODE.LEDGER -->|"candidate plus exact evidence"| NODE.DECISION
  NODE.DECISION -->|"human adoption only"| NODE.REVISION
  NODE.INTAKE -->|"local lesson search"| NODE.LESSON_LOOKUP
  NODE.LESSON_LOOKUP -->|"applicable IDs and test probes"| NODE.PLAN
  NODE.PLAN_REVIEW -->|"checked premises"| NODE.DRAFT
  NODE.PLAN_REVIEW -->|"unresolved source or permission gap"| NODE.HOLD
  NODE.QUALITY_GATE -->|"both pass on exact draft"| NODE.EXPORT
  NODE.QUALITY_GATE -->|"verified repairable findings"| NODE.REPAIR
  NODE.REPAIR -->|"new full assembly and change receipt"| NODE.FINAL_REVIEW
  NODE.FINAL_REVIEW -->|"both pass on exact new assembly"| NODE.EXPORT
  NODE.FINAL_REVIEW -->|"unresolved after bounded repair"| NODE.HOLD
  NODE.QUALITY_GATE -->|"triggered worker or reviewer issue"| NODE.A01_AUDIT
  NODE.FINAL_REVIEW -->|"instruction-output evidence"| NODE.A01_AUDIT
  NODE.REVISION -->|"next run with approved revision"| NODE.LESSON_LOOKUP
  NODE.QUALITY_GATE -->|"unresolved or non-repairable failure"| NODE.HOLD
  ADAPTER --> NODE.INTAKE
```

## Full with MCP/API bindings

```mermaid
flowchart TD
  classDef shared fill:#eef6ff,stroke:#2b6cb0,color:#102a43
  classDef review fill:#fff8db,stroke:#b7791f,color:#3d2b00
  ADAPTER["Full with MCP/API bindings: binding receipt plus full ledger operations"]:::shared
  %% Transport optional_documented_bindings; MCP/API untested_backend_or_tenant. See generated profile mapping.
  NODE.INTAKE["Freeze intake and authority"]:::shared
  NODE.SOURCE["Build source and attribution map"]:::shared
  NODE.WITNESS["Separate author research from witness export"]:::shared
  NODE.CLAIMS["Create permitted claim map"]:::shared
  NODE.PLAN["Plan conversational two-host episode"]:::shared
  NODE.DRAFT["Draft and save conversational script"]:::shared
  NODE.SOURCE_REVIEW["Independent source review"]:::review
  NODE.CRAFT_REVIEW["Independent A02 craft review"]:::review
  NODE.A01_AUDIT["A01 reviewer audit"]:::review
  NODE.LEDGER["Record candidate or adopted lesson"]:::review
  NODE.DECISION["Human adoption decision"]:::review
  NODE.REVISION["Publish shared revision reference"]:::review
  NODE.LESSON_LOOKUP["Retrieve applicable lessons"]:::shared
  NODE.PLAN_REVIEW["Check source premises before drafting"]:::review
  NODE.QUALITY_GATE["Join source and craft decisions"]:::review
  NODE.REPAIR["One bounded conversational rewrite"]:::shared
  NODE.FINAL_REVIEW["Recheck the whole revised assembly"]:::review
  NODE.EXPORT["Export reviewed speech and timing"]:::shared
  NODE.HOLD["Retain unresolved findings and stop"]:::review
  NODE.INTAKE -->|"authorized case inputs"| NODE.SOURCE
  NODE.SOURCE -->|"attributed source view"| NODE.WITNESS
  NODE.WITNESS -->|"permitted proposition set"| NODE.CLAIMS
  NODE.CLAIMS -->|"claim-map coverage"| NODE.PLAN
  NODE.PLAN -->|"plan and supported recall anchors"| NODE.PLAN_REVIEW
  NODE.DRAFT -->|"frozen full assembly"| NODE.SOURCE_REVIEW
  NODE.DRAFT -->|"frozen full assembly"| NODE.CRAFT_REVIEW
  NODE.SOURCE_REVIEW -->|"evidence review receipt"| NODE.QUALITY_GATE
  NODE.CRAFT_REVIEW -->|"A02 craft review receipt"| NODE.QUALITY_GATE
  NODE.A01_AUDIT -->|"bounded candidate proposal"| NODE.LEDGER
  NODE.LEDGER -->|"candidate plus exact evidence"| NODE.DECISION
  NODE.DECISION -->|"human adoption only"| NODE.REVISION
  NODE.INTAKE -->|"local lesson search"| NODE.LESSON_LOOKUP
  NODE.LESSON_LOOKUP -->|"applicable IDs and test probes"| NODE.PLAN
  NODE.PLAN_REVIEW -->|"checked premises"| NODE.DRAFT
  NODE.PLAN_REVIEW -->|"unresolved source or permission gap"| NODE.HOLD
  NODE.QUALITY_GATE -->|"both pass on exact draft"| NODE.EXPORT
  NODE.QUALITY_GATE -->|"verified repairable findings"| NODE.REPAIR
  NODE.REPAIR -->|"new full assembly and change receipt"| NODE.FINAL_REVIEW
  NODE.FINAL_REVIEW -->|"both pass on exact new assembly"| NODE.EXPORT
  NODE.FINAL_REVIEW -->|"unresolved after bounded repair"| NODE.HOLD
  NODE.QUALITY_GATE -->|"triggered worker or reviewer issue"| NODE.A01_AUDIT
  NODE.FINAL_REVIEW -->|"instruction-output evidence"| NODE.A01_AUDIT
  NODE.REVISION -->|"next run with approved revision"| NODE.LESSON_LOOKUP
  NODE.QUALITY_GATE -->|"unresolved or non-repairable failure"| NODE.HOLD
  ADAPTER --> NODE.INTAKE
```

