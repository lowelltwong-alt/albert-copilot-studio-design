# Presentation revision

Recipient titles normalized. Prior archive SHA-256: `bd7061b96f37c7bff556f37f2369e122daaf6b4f44e66735bdfbd7c00d7e6be9`. Historical validation reports describe the original revision; they are not fresh tenant or performance results. Manifest payload fingerprints reflect this naming copy. Source and license notices remain applicable.
