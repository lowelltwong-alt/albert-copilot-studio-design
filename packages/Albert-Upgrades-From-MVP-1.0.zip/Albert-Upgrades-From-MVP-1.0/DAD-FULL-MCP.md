# Full MCP digital-assets layer

`Albert-Digital-Assets-1.0.zip` is the full MCP digital-assets upgrade in this bundle. It is a separate service layer, not a replacement for the MVP or the case workflow.

Open its `AI_FRONT_DOOR.md` first. Then read `MCP-API.md`, `DATA-MODEL.md`, `LEARNING-LOOP.md`, `PROVENANCE.md` and both license files.

Local smoke test:

```powershell
python -B tests/test_runtime.py
python -B mcp_stdio.py
```

It includes local stdio MCP, a loopback Streamable HTTP surface, an authenticated API backup adapter, typed graph search, lifecycle checks, bounded content retrieval and explicit lesson-candidate intake. Azure, Copilot Studio, Foundry, Entra/OAuth and production hosting remain deployment work.

The DAD-style learning path is caller-driven and candidate-only. It deduplicates observations, records evidence, quarantines unsafe packets and requires distinct human review. Do not send private case source rows, raw conversations or secrets into it.

