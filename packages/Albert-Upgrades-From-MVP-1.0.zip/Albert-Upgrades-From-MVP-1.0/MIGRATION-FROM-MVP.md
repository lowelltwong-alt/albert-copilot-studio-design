# Migration from the MVP without rebuilding

The MVP produces the authoritative handoff packets. Upgrades consume those packets and add storage, service or reusable-asset capabilities around them.

## Preserve the MVP contract

Carry these fields forward unchanged whenever they exist: `case_id`, `source_id`, `page_anchor`, `semantic_exhibit_id`, `claim_id`, `witness_id`, `packet_id`, `revision_id`, `status`, `certainty`, `attribution` and `conflict_id`. A later package may add a typed field, but it must not silently rename or delete the MVP identity.

The original PDF remains source authority. OCR Markdown remains generated working text. Held conflicts, unproved identity, image uncertainty and witness knowledge boundaries remain visible in every upgrade.

## Stage mapping

| MVP stage | No-MCP overlay | MCP/API overlay | What is reused |
|---|---|---|---|
| `RUN-01` source intake | `C01` | `P01` | Source register, anchors, OCR limits and exhibit boundaries |
| `RUN-02` planning | `C04` | `P02`/`P03` | Case profile and witness scope |
| `RUN-03` evidence graph | `C02`/`C03` | `P01`/`P02` | Evidence items, typed edges and conflict ledger |
| `RUN-04` witness profile | `C04` | `P03` | Witness knowledge boundary and cross-risk map |
| `RUN-05` packet | `C05` | `P04` | Witness packet and claim coverage |
| `RUN-06` conversation review | `C06` | `P06` | Independent review and repair findings |
| `RUN-07` evidence revision | `C07` | `P01`/`P02` | Evidence-linked corrections and change receipt |
| `RUN-08` podcast script | `C08` | `P05` | Two-host conversational script and timing |
| `RUN-09` final package | `C09` | `P06` | Final source/evidence/craft reconciliation |
| `RUN-10` rehearsal | `C10` | `P07` | Truthful rehearsal and witness preparation |
| `RUN-11` independent audit | separate fresh checker | separate evaluator worker | Non-author audit and unresolved holds |

## Recommended sequence

1. Run the MVP on one fixture and save the final packet.
2. Run the no-MCP prompts against that packet, preserving the MVP IDs and recording the mapping in the manual case workspace.
3. When the manual outputs are stable, implement the MCP/API dispatcher and storage behind the same contracts. Do not change the prompt core to fit an unverified tool response.
4. Connect the digital-assets MCP service only for reusable asset discovery, lifecycle status and explicit privacy-safe lesson candidates. Keep case material in the case system.
5. Rerun the affected checks when the model, tenant, tool surface, schema, privacy boundary or authority changes.

