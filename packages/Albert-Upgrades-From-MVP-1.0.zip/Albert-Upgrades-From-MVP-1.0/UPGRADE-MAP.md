# Upgrade map

The three upgrades are layers around the MVP.

```mermaid
flowchart LR
    MVP[Prompt-only MVP
Copilot Studio chat + saved Markdown] --> MANUAL[No MCP/API
manual ledgers + longer stages]
    MANUAL --> CONNECTED[MCP/API
authenticated dispatcher + durable storage]
    DAD[Digital Assets full MCP
asset graph + lifecycle + learning intake] -. supports discovery and review .-> MANUAL
    DAD -. optional tools .-> CONNECTED
```

## No MCP or API

Use when the team needs a richer manual workflow immediately. It does not require a server, API key, database or SharePoint. The operator moves the MVP packet between prompts and saves each revision.

## MCP and API

Use after the manual workflow is understood. It defines authenticated MCP as the primary connection and HTTPS API as backup to the same dispatcher and authoritative storage. The included design still requires implementation, authentication, storage, tenant configuration and regression acceptance.

## Digital Assets full MCP

Use as a reusable capability service alongside either workflow. Its local stdio MCP is the easiest smoke test; its Streamable HTTP/API adapter is the Copilot Studio/Azure integration boundary. It exposes bounded search, content retrieval, typed neighbors, lifecycle status, runtime status and candidate-only learning intake. Human review is required before promotion, and it does not observe other AIs automatically.

