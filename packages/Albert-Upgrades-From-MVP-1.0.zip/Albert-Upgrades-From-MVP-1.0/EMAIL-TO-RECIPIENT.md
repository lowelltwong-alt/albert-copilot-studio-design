# Email to send with the upgrade bundle

**Subject:** Albert additive upgrade bundle — no-MCP workflow, MCP/API design and full digital-assets MCP

Hello,

The attached upgrade bundle is designed to build on the prompt-only MVP you received. It does not require recreating the MVP workflow.

Please start with `START-HERE.md`, then read `MIGRATION-FROM-MVP.md`. Keep the MVP packet IDs and source/evidence boundaries intact. The three standalone archives are under `PACKAGES/`:

- `Albert-No-MCP-or-API-1.0.zip` — expanded manual workflow with no service dependency.
- `Albert-MCP-and-API-1.0.zip` — connected workflow design using MCP as primary and API as backup.
- `Albert-Digital-Assets-1.0.zip` — full MCP digital-assets service with graph search, lifecycle checks and explicit learning intake.

Use the no-MCP package first if the team wants to extend the prompt workflow without infrastructure. Use the MCP/API package after the manual outputs are useful. Use the digital-assets MCP layer alongside either version for reusable asset discovery and governed improvement lessons; it does not receive private case material.

The bundle contains designs and local checks, not tenant deployment or gold-standard certification. Record the tenant's actual model labels, authentication, storage, DLP settings and human review receipts before production use.

Best,

