# Albert upgrades from the prompt-only MVP

This is an additive upgrade bundle. The prompt-only MVP remains the base workflow. These packages reuse its source-grounding rules, evidence boundaries, witness outputs, podcast stages and review gates; they do not ask the team to start over.

## Use this bundle

1. Finish one MVP pilot and preserve its complete Markdown packets. Keep the MVP package and its run receipt as the baseline.
2. Read `MIGRATION-FROM-MVP.md` and `UPGRADE-MAP.md`. Keep the same case identifiers, source anchors, exhibit semantics, claim IDs, witness IDs and packet revision IDs when moving forward.
3. Send or extract the package you need from `PACKAGES/`. Each package is also a standalone archive with its own prompts, diagrams, setup and license files.
4. Start with the no-MCP workflow when the team wants a longer manual workflow with no service. Move to MCP/API only after those outputs are useful and the service/tenant controls are implemented.
5. Treat `Albert-Digital-Assets-1.0.zip` as the full MCP digital-assets layer. It is a separate searchable catalog and learning service that can support the workflow; it does not replace the case workflow or ingest private case files.

## Packages

| Archive | Purpose | Build relationship |
|---|---|---|
| `Albert-No-MCP-or-API-1.0.zip` | Expanded manual case workflow | Adds stages and ledgers around the MVP packets; human operator remains the state manager. |
| `Albert-MCP-and-API-1.0.zip` | Connected case-workflow design | Maps the same packet contracts to authenticated MCP/API tools; it is an implementation design pending backend and tenant acceptance. |
| `Albert-Digital-Assets-1.0.zip` | Full MCP digital-assets service | Catalogs reusable agents, workflows, prompts, skills and harnesses; provides local stdio MCP, Streamable HTTP and API backup, typed graph, lifecycle checks and candidate-only learning intake. |

The MVP baseline archive is included in `PACKAGES/` for hash comparison and a clean handoff. It is not rebuilt by the upgrades.

## Important boundaries

- No package automatically promotes model output, lessons or case facts.
- Do not send private case source rows or raw conversations to the digital-assets service.
- Model names in Copilot Studio are adapter settings and must be recorded from the actual tenant picker.
- The MCP/API package and Azure adapter are not tenant-deployed by this bundle.
- The DAD-derived license remains separate from Albert-authored CC BY material; read each package's licensing files before publication.

