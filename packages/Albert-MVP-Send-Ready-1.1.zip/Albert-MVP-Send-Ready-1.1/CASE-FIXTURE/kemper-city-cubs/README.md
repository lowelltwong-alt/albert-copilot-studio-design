# Kemper v. Nita City Cubs case fixture

This folder is included so the first MVP pilot can start with a real, source-grounded test instead of an empty chat. It is the baseball stadium bat-injury mock-trial case.

## Files

- `KEMPER-original.pdf` — original case-file PDF. Treat this as the source authority.
- `KEMPER-ocr.md` — our existing OCR-derived Markdown snapshot. It is a working convenience copy, not source truth; preserve uncertainty and compare it to the PDF when the two differ.
- `CASE-START-PROMPT.md` — the exact first message to send after the Case Analyst agent is configured.

## Use and rights

This is a private test fixture for the recipient's licensed mock-trial work. Do not publish, commit to a public repository, or redistribute the PDF unless the recipient has the right to do so. The package contains no OCR engine; it only supplies the existing OCR snapshot so the prompt-only MVP can be exercised.

## Source boundary

The PDF is authoritative. The OCR Markdown may have recognition errors, missing layout, and imperfect exhibit boundaries. The Analyst must keep page anchors, semantic exhibit boundaries and conflicts visible, and must not turn an OCR guess into a fact. If the tenant cannot ingest the PDF, record that limitation in the source ledger and keep the PDF beside the run for human review.

## Integrity

- Original PDF SHA-256: `12e4c2e337ea41919f87573da987aac45459389c5c9e7fae42f46b7d232606be`
- OCR Markdown SHA-256: `9ab1c2083ffc41b00a2ab0761f9d03c2f18acbbddfc5f3a729a308610c859140`

