# Kemper v. Nita City Cubs (test fixture) — full OCR text


## Page 3

<IMP R V 
NITA CITY CUBS HOLDINGS, INC. 
Theresa D. Moore 
Attorney at Law 
University of California 
Hastings College of the Law 
Professor Adjunct 
with 
Patrick DePoy 
Attorney at Law 
TiIAL BY FIRE' CASE SERIES 
LEGAL ADVOCACY WITH NEW AND MODERN EVIDENCE 
NATIONAL INSTITUTE FOR TRIAL ADVOCACY

## Page 4

© 2015 by the National Institute for Trial Advocacy 
All rights reserved. No part of this work may be reproduced or transmitted in any form or by any means, electronic 
or mechanical, including photocopying and recording, or by any information storage or retrieval system without 
the prior written approval of the National Institute for Trial Advocacy unless such copying is expressly permitted 
by federal copyright law. 
Law students who purchase this NITA publication as part of their class materials and attendees of NITA-sponsored 
CLE programs are granted a limited license to reproduce, enlarge, and electronically or physically display, in their 
classrooms or other educational settings, any exhibits or text contained in the printed publication or online at the 
proprietary website. However, sharing one legally purchased copy of the publication among several members of 
a class team is prohibited under this license. Each individual is required to purchase his or her own copy of this 
publication. See 17 U.S.C. § 106. 
Address inquiries to: 
Reprint Permission 
National Institute for Trial Advocacy 
1685 38th Street, Suite 200 
Boulder, CO 80301-2735 
Phone: (800) 225-6482 
Fax: (720) 890-7069 
Email: permissions@nita.org 
ISBN 978-1-60156-486-3 
eISBN 978-1-60156-524-2 
FBA 1486 
Printed in the United States of America 
L7.) Wolters Kluwer 
Official co-publisher of NITA. 
WKLegaledu.com/NITA

## Page 5

CONTENTS 
ACKNOWLEDGEMENTS vii 
CASE SUMMARY 
SPECIAL INSTRUCTIONS FOR USE AS A FULL TRIAL  3 
COMPLAINT 5 
ANSWER 1 
Damns 
Exhibit 1—Nita City Cubs Employee Manual 17 
Exhibit 2—Tweets from Benjamin Stone  21 
Exhibit 3—Tweets from Jessica Kemper 23 
Exhibit 4—ImageGram 25 
Exhibit 5—Nita City Cubs Official Incident Report  27 
Exhibit 6—Nita City Cubs Official Incident Report, Supplemental Witness Statement, Daniel Kolleng  29 
Exhibit 7—Nita City Cubs Official Incident Report, Supplemental Witness Statement, Eddie Davis  31 
Exhibit 8—Nita City Cubs Official Incident Report, Supplemental Witness Statement, Jane Braasch  33 
Exhibit 9—Nita City Cubs Official Incident Report, Diane Sandberg  35 
Exhibit 10—Nita City Police Department Report Form 52 1-109   37 
Exhibit 11—Letter from Jane Braasch  39 
Exhibit 12—Emails  41 
Exhibit 13—Nita City Police Department Supplemental Reports  49 
Exhibit 14—Nita City Police Department Formal Letter of Reprimand   55 
Exhibit 15—Nita City Times Newspaper Articles  57 
Exhibit 16—August Security Summary  61 
Exhibit 17—Photos (17A, 17B, 17C, 17D)   65 
DEPOSITION TRANSCRIPTS 
Excerpts from Daniel Kolleng's Deposition   75 
Excerpts from Benjamin Stone's Deposition   S3 
Excerpts from Jessica Kemper's Deposition   91 
Excerpts from Lara Kotkin's Deposition  101 
National Institute for Trial Advocacy

## Page 6

CASE FILE 
APPENDICES 
Appendix A—Local Rules for Mock Trials and Pretrial Conferences   113 
Appendix B-State of Nita Compiled Statutes   121 
Appendix C—Jury Instructions and Verdict Form  123 
vi National Institute for Trial Advocacy

## Page 7

ACKNOWL DG EMENTS 
I would like to thank attorney Patrick DePoy for his stellar work on Kemper v. Nita City Cubs Holdings, 
Inc. He has the instincts and the work ethic of a true trial lawyer. His energy, enthusiasm, and legal 
acumen are immeasurable, and it has been my honor to work with him. 
I would like thank Ana Fatima Costa of Barkley Reporters for her graciousness and continual 
desire to aid legal education, and for truly making it happen to allow us to include actual transcripts in 
modern format. 
And, a special thank you to Balinda Dunlap of Barkley Reporters for her tireless work in preparing 
Kemper transcripts after hours of reporting actual cases. Balinda has traveled all over the world working 
on cases of great import and is one of the best reporters I have ever worked with in my legal career. 
The National Institute for Trial Advocacy wishes to thank Twitter for its permission to use likenesses 
of its website as part of these teaching materials. 
National Institute for Trial Advocacy vii

## Page 8

"Now there's three things you can do in a baseball game. 
You can win or you can lose or it can rain." 
Casey Stengel 
National Institute for Trial Advocacy

## Page 9

CASE SUMMARY 
What began as a fun afternoon at the ballpark turned into a nightmare for a baseball patron and a 
lawsuit for the Nita City Cubs organization. The plaintiff, Jessica Kemper, sued the baseball stadium 
for injuries caused by an allegedly intoxicated fan at a game. Kemper was looking forward to a baseball 
game with her children at Hannigan Field, home of the Nita City Cubs. What she got instead was a trip 
to the emergency room, several stitches, and a lawsuit for the damages she incurred. A fellow sports fan, 
arguably intoxicated, threw a small bat he was given as part of the Souvenir Bat Giveaway promotion and 
struck Kemper in the back of the head. 
Was this a simple case of drunken behavior, or an example of systemic, irresponsible revelry sanc-
tioned, and even encouraged, by the Cubs organization? Did the Cubs sacrifice safety and security to 
drive up "fun" at the park for all the wrong people? 
Kemper v. Nita City Cubs Holdings, Inc. is evenly balanced, and either side could prevail with proper 
strategy, finesse, and knowledge of the facts. 
National Institute for Trial Advocacy 1

## Page 10

SPECIAL INSTRUCTIONS FOR 
AS A FULL TRIAL. 
SE 
Issues for Trial 
This case shall be tried on the issue of liability only, unless instructed otherwise. 
Witnesses 
Each side is limited to four witnesses, including adverse witnesses. 
Required Stipulations 
That all employees are agents of Nita City Cubs Holdings, Inc. 
That Nita City Cubs Holdings, Inc. is liable for the actions of its agents and employees. 
That Nita City Cubs Holdings, Inc. has more than thirty employees. 
That the Factual Background as alleged in the Complaint in Paragraphs 6 through 12 is to be 
considered as included in the witnesses' depositions. 
That Daniel Kolleng received a souvenir bat as part of the Giveaway promotion on the day of 
the incident. 
That Jessica Kemper and Daniel Kolleng entered into a confidential settlement agreement in 
March YR-0. 
Other Instructions 
All years in these materials are stated in the following form: 
• YR-0 indicates the actual year in which the case is being tried (i.e., the present year); 
YR-1 indicates the preceding year (please use the actual year); 
YR-2 indicates the next preceding year (please use the actual year); et cetera. 
The Federal Rules of Evidence apply. 
The Local Rules for Mock Trials and Pretrial Conferences apply and are set forth in Appendix A. 
The applicable law is contained in the statutes and proposed jury instructions set forth in 
Appendices B and C, respectively. 
National Institute for Trial Advocacy 3

## Page 11

U.S. DISTRICT COURT 
FOR THE STATE OF NITA 
Civil Division 
JESSICA KEMPER, 
Plaintiff, 
v. 
NITA CITY CUBS HOLDINGS, 
INC., 
Defendant. 
NITA: YR-1-CIV-10784 
COMPLAINT FOR DAMAGES 
FOR NEGLIGENCE AND FOR 
VIOLATION OF THE NITA 
LIQUOR CONTROL ACT 
(DRAM SHOP) ACT OF YR-78 
DEMAND FOR JURY TRIAL 
COMES NOW the plaintiffJessica Kemper, by and through the undersigned counsel, and makes this 
complaint against the defendant Nita City Cubs Holdings, Inc. ("Cubs") and demands a trial by jury 
of all claims. In support thereof, the plaintiff alleges as follows: 
PARTIES 
1. The plaintiff is an individual who at all relevant times herein, resided in Nita City, Nita. 
2. The defendant Cubs is a corporation with over thirty employees, authorized to do business in the 
State of Nita, which at all relevant times owned, controlled, managed, and was the licensee of a 
certain baseball stadium, Hannigan Stadium. 
JURISDICTION 
3. This Court has diversity jurisdiction over this action pursuant to 22 Nita Code § 1332. 
4. This Court has personal jurisdiction over the defendant Cubs pursuant to 22 Nita Code § 1332. 
5. This Court is the proper venue for this matter pursuant to § 6-202(8) of the Courts and Judicial 
Proceedings Article of the Nita Code in that the cause of action which is the subject of this case 
arose in Nita City, Nita. 
FACTUAL BACKGROUND 
6. On Saturday, September 10, YR-2, the plaintiff Jessica Kemper attended a baseball game 
at Hannigan Stadium between the Nita City Cubs and the New Alexandria Sharks. 
7. The defendant Cubs act as the owners and operators of Hannigan Stadium, along with the 
Nita City Cubs baseball organization. 
National Institute for Trial Advocacy 5

## Page 12

CASE FILE 
8. The plaintiff Kemper sat in Section 101 on the lower level of Hannigan Stadium with her daughter 
and her son, both minors and not parties to this action. 
9. Another patron at Hannigan Stadium, Dan Kolleng, sat four rows behind Kemper with three 
companions. 
10. During the seventh inning "stretch," the period between the seventh and eighth innings of play 
during which time patrons sing the popular song "Take Me Out to the Ball Game," Kolleng 
propelled a souvenir bat in the direction of Kemper. 
11. The bat struck Kemper in the back of the head as she was standing to sing "Take Me Out to the 
Ball Game," causing her to fall forward. Kemper struck her shoulder on the back of the seat 
directly in front of her. 
12. Kemper was taken to Southeastern Medical Center, received four stitches in the back of her head, 
and was treated for a concussion and a broken collarbone. 
13. The incident was due to the negligence of the defendant Cubs, including but not limited to 
failing to properly train staff members selling alcohol on detecting and refusing to sell alcohol 
to intoxicated patrons; failing to supervise alcohol vendors distributing beer and spirits to 
patrons throughout the stadium; failing to implement adequate measures for removing intoxi-
cated fans; failing to adequately staff Hannigan Stadium to detect and remove intoxicated fans; 
failing to reprimand vendors whose improper distribution of alcohol had previously led to 
violence and/or inappropriate behavior by intoxicated patrons; negligent hiring, training, and 
supervision of Security and employees; and failing to prevent and/or guard against reasonably 
foreseeable harm to patrons of Hannigan Stadium. 
14. As a direct and proximate result of the incident, the plaintiff Kemper suffered bodily injuries that 
have caused, and will continue to cause, physical and mental pain and suffering for the rest of 
Kemper's life. The plaintiff Kemper has incurred, and will continue to incur, medical, therapeu-
tic, and related expenses. Moreover, the plaintiff suffered a loss of earnings and an inability to 
enjoy the normal functions of life. 
COUNT ONE: NEGLIGENCE 
15. The plaintiff restates and realleges each and every allegation set forth above as if fully set 
forth herein. 
16. At all relevant times, the plaintiff was a business invitee of Hannigan Stadium, located at 1060 
West Nosidda, Nita City, Nita. 
17. At all relevant times, the defendant Cubs and its agents had the duty to use reasonable care to see 
that Hannigan Stadium and its premises, which a business invitee may be expected to use, are 
safe; maintain the premises in a safe condition for the purpose of offering services to patrons; and 
prevent and/or guard against reasonably foreseeable harm to invitees. 
18. In violation of those duties, the defendant's failures include, but are not limited to, failing to use 
reasonable care to see that those portions of Hannigan Stadium that an invitee may be expected to 
6 National Institute for Trial Advocacy

## Page 13

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
use or occupy are safe; failing to use reasonable care when selling alcohol to intoxicated patrons; 
failing to use reasonable care when alcohol vendors are distributing beer and spirits to patrons 
throughout the stadium; failing to implement adequate measures for removing intoxicated fans; 
failing to adequately staff Hannigan Stadium to detect and remove intoxicated fans; failing to 
reprimand vendors whose improper distribution of alcohol had previously led to violence and/or 
inappropriate behavior by intoxicated patrons; and failing to prevent and/or guard against reason-
ably foreseeable harm to patrons of Hannigan Stadium. 
19. As a proximate result of the defendant's negligence, the plaintiff suffered injuries as set 
forth above. 
20. The above injuries were proximately caused by the negligence of the defendant without any 
contributory negligence by the plaintiff. 
COUNT TWO: VIOLATION OF NITA LIQUOR CONTROL ACT OF YR-78 
21. The plaintiff restates and realleges each and every allegation set forth above as if fully set 
forth herein. 
22. At all relevant times, the plaintiff Kemper was a business invitee of Hannigan Stadium, located 
at 1060 W. Nosidda, Nita City, Nita. 
23. At all relevant times, the defendant Cubs were licensed by the State of Nita to sell intoxicating 
liquors pursuant to the Liquor Control Act of YR-78, and in the business of serving alcoholic 
liquors to patrons of Hannigan Stadium. See 100 NCCS 5/01-10. 
24. On September 10, YR-2, the defendant Cubs sold or gave certain alcoholic beverages to Dan 
Kolleng, who became intoxicated as a result. 
25. As a direct and proximate result of his intoxication, Dan Kolleng negligently threw a souvenir bat 
provided to him by the defendant Cubs as part of a promotion. 
26. As a proximate result of Dan Kolleng's intoxication, the plaintiff Kemper suffered severe injuries 
that required emergency medical treatment; suffered pain, shock, and anguish as a result of her 
injuries; expended substantial funds for medical care, surgery to her broken clavicle, and other 
medical treatments related to her injuries; and has been prevented from attending to her usual 
work and affairs, thereby losing income. 
27. The defendant negligently and recklessly trained, advised, and supervised its employees autho-
rized to sell and distribute alcoholic liquor within the confines of Hannigan Stadium, and there-
fore violated 100 NCCS 5/10(c). 
* * * 
National Institute for Trial Advocacy

## Page 14

CASE FILE 
WHEREFORE, the plaintiff respectfully requests judgment against the defendant in an amount to 
be determined at trial, plus costs of suit, attorney fees, and such other and further relief as this Court 
deems just and proper. 
Dated: April 1, YR-1 
Respectfully Submitted, 
pet -ex golovale/ 
Peter Roseville, Esq. 
Attorney for Plaintiff 
8 National Institute for Trial Advocacy

## Page 15

KEMPER V. NITA CITY Cuss HOLDING'S, INC. 
JURY DEMAND 
The plaintiff, by and through the undersigned counsel hereby demands trial by jury of all issues in 
this matter. 
Dated: April 1, YR-1 
Respectfully Submitted, 
Peter ROSPA/ale,
Peter Roseville, Esq. 
Attorney for Plaintiff 
National Institute for Trial Advocacy 9

## Page 16

U.S. DISTRICT COURT 
FOR THE STATE OF NITA 
Civil DivI8ion 
JESSICA KEMPER, 
Plaintiff, 
v. 
NITA CITY CUBS HOLDINGS, 
INC., 
Defendant. 
NITA: YR-1-CIV-10784 
ANSWER 
COMES NOW the defendant, Nita City Cubs Holdings, Inc. ("Cubs"), by and through the under-
signed counsel, and makes this answer to the plaintiff, Jessica Kemper. 
PARTIES 
1. The defendant Cubs are without sufficient information to admit or deny the allegations in ¶ 1 and, 
therefore, demands strict proof thereof. 
Admit. 
JURIST)! C . I ON 
3. The allegation in ¶ 3 states a legal conclusion as to which no response is required. 
4. The allegation in ¶ 4 states a legal conclusion as to which no response is required. 
5. The allegation in 15 states a legal conclusion as to which no response is required. 
6. Admit. 
FACTll A L BACKGROUND 
7. Admit. 
8. Admit. 
9. Cubs are without sufficient information to admit or deny the allegations in ¶ 9 and, therefore, 
demands strict proof thereof. 
National Institute for Trial Advocacy 11

## Page 17

Case FILE 
10. Cubs are without sufficient information to admit or deny 
demands strict proof thereof. 
11. Cubs are without sufficient information to admit or deny 
demands strict proof thereof. 
12. Cubs are without sufficient information to admit or deny 
demands strict proof thereof. 
13. Denied. 
14. Denied. 
the allegations 
the allegations 
the allegations 
COUNT I: NEGLIGENCE 
in ¶ 10 and, therefore, 
in ¶ 11 and, therefore, 
in ¶ 12 and, therefore, 
15. Defendant Cubs herein reincorporates the responses set forth above in 1111 through 14. 
16. Admit. 
17. Admit. 
18. Denied. 
19. Denied. 
20. Denied 
COUNT TWO: VIOLATION OF N I TA LIOUOR CONTROL ACT 
21. Defendant Cubs herein reincorporates the responses set forth above in 411111 through 20. 
22. Admit. 
23. Admit. 
24. Cubs are without sufficient information to admit or deny the allegations in ¶ 24 and, therefore, 
demands strict proof thereof. 
25. Denied. 
26. Denied. 
27. Denied. 
* * * 
12 National Institute for Trial Advocacy

## Page 18

KEMPER V. NITA Cm CUBS HOLDINGS, INC. 
WHEREFORE, the defendant respectfully requests that the Court dismiss the plaintiff's claim; order 
that the plaintiff recover no relief of any kind against the defendant; enter judgment in favor of the 
defendant Cubs; and award the defendant costs, attorney fees, and such other and further relief as the 
Court deems appropriate. 
Dated: May 1, YR-1 
Respectfully Submitted, 
crizee-e-%,te fad&ezwza 
Theodore Williams, Esq. 
Attorney for Defendant 
National Institute for Trial Advocacy 13

## Page 20

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Exhibit 1 
E YEE MA 
C 
u 
The Cubs' W y Is the Right Way! 
Dear Employee: 
On behalf of the Nita City Cubs, I'd like to personally welcome you to the Cubs family. We at the 
Cubs believe that to deliver the best experience for our dedicated and passionate fans, we need to 
provide not only a quality product on the field, but an enjoyable, fun, and safe environment around 
the field. 
Please take the time to read the manual outlining the Cubs' Way. We believe it's critical that you stick 
to the principles and guidelines outlined below. Cubs' baseball and the Hannigan Stadium experience 
have delighted fans for generations. To honor this tradition, it is up to you to continue providing a 
great place to enjoy America's pastime. 
If you have any questions or concerns, please contact your supervisor or our Director of Security 
Services for Hannigan Stadium, Lara Kotkin. Welcome to the Cubs family! 
Best, 
get .we gadegeo/cff 
Bernie Barleycorn 
CEO, Nita City Cubs Holdings, Inc. 
National Institute for Trial Advocacy 17

## Page 21

CASE hie-
Section 6: Alcohol Sales 
The following guidelines apply to all vendors of beer or liquor within the confines of Hannigan 
Stadium. The Cubs strive to ensure that fans can enjoy beer and spirits, as well as other refreshments, 
in a responsible manner. We pride ourselves on being a family organization. Therefore, it is absolutely 
imperative that all alcohol vendors act responsibly when selling alcoholic beverages at Hannigan. 
1. Identification is a must. 
Pursuant to state liquor laws, every patron must present valid photo identification when purchasing 
beer or alcohol. Valid forms of ID include: 
➢ State-issued driver's license 
• State-issued identification card 
➢ United States passport 
• Valid military identification 
Any fan under the age of thirty-five must present a photo identification to purchase alcohol. The Cubs 
expect vendors to use their best judgment when asking for identification, but to always err on the side 
of caution. In other words, only those patrons clearly, obviously, and unmistakably over the age of 
thirty-five should be allowed to purchase alcohol without an ID. 
Any patron attempting to purchase alcohol with a fake ID or with an identification that is not their 
own should be reported to stadium Security Services immediately, and they will be escorted from 
the premises. 
2. No more than two drinks per patron per serving. 
The Cubs organization prides itself on providing a safe, fun, and family-friendly environment for 
enjoying baseball. As part of that mission, no vendor may sell any patron more than two alcoholic 
beverages at a single time. This rule applies to stand-alone vendors and section vendors alike. 
3. No beer or alcohol after the first pitch of the seventh inning. No exceptions. 
Baseball games can be long affairs—a typical nine-inning game can last over three hours, and with 
extra innings, fans can be at the Stadium for over four or five hours at a time. Because it is impossible 
to predict how long a game will last, the "cutoff" time for alcohol is not a time but rather a pitch: the 
first pitch of the seventh inning. 
For free-standing vendors within the concourse and for food vendors also selling alcohol, the final 
pitch of the sixth inning will bring many fans looking for that "last pop." Make it clear to all fans 
waiting in line that once the Cubs take the field and throw the first pitch, beer and alcohol sales stop 
immediately. 
18 National Institute for Trial Advocacy

## Page 22

KEMPER V. NITA Cm' CUBS HOLDINGS, INC. 
For section vendors, sales must similarly stop once the first pitch is thrown for the start of the seventh 
inning. Return to your loading station, and report your receipts during the period between the end of 
the sixth inning and the beginning of the seventh. If, while heading to your loading station, patrons 
request alcoholic beverages, feel free to sell beverages until the first pitch but not after. 
4. Receipts for section vendors. 
Each time a section vendor receives new beverages at his loading station, he must account for the 
beverages sold. Vendors must provide, dollar for dollar, the amount that corresponds to the number 
of beverages with which they left the loading station. For example, for a standard cooler of thirty 
beers, the vendor must pay his loading station chief $240 in cash: $8.00 per beer for thirty beers. The 
vendor keeps the remainder as tips. 
5. Intoxicated fans—how to handle "too much fun." 
As with any establishment selling alcoholic beverages, occasionally fans will become intoxicated. 
In other words, you as the vendor must be aware of the fan having "too much fun"—or TMF, as we 
say at Hannigan. 
TMF fans come in all shapes and sizes, which means vendors must be alert to detect signs of intoxica-
tion. Not every TMF fan will display obvious signs of drunkenness: making rude comments, becom-
ing violent, or stumbling visibly while walking. If you are uncertain as to whether a fan is intoxicated 
or past the point at which you can still safely serve alcohol, contact your supervisor immediately. We 
at the Cubs want all fans to enjoy themselves thoroughly but safely. 
If a fan is clearly intoxicated, stop selling him or her alcohol. If it becomes obvious that friends or 
fellow patrons are giving the TMF fan alcohol, stop serving alcohol to those fans. If any fan displays 
signs of violence, either physical or verbal, report his behavior to Security personnel immediately. 
National Institute for Trial Advocacy 19

## Page 23

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Exhibit 2 
Tweets from Benjamin Stone 
i4y.1{1.• ••10 
*.: 
OIPIMINP.MMO100 
Ben Stone 
I .44.1 0. 
f 1-.• I nil U. a.... till'. i(• 4(411 
.1.'14 NIA 
C. Ii'a t ly lit 
GE= 
See hrtp://bit.ly/lKykslo. 
Twee & & witzos 
rf Benta•ow 
Got a real live Me in my section today, foil'.. He's hammeled, but on ababoo.t, std: 
mod have a t,•fter shot at II.? plate di-1n Hendry,' 
4 
Nr Ben,  ..it 
▪ Ofigis a.K nig' Lan0ll, I•ack ligs Friday! "op by to lu a of mks 
from the *to* tap. ... 
•. eon 
▪ How “, ow ,a Le- sdaes tt 1...I 1 Ifq• tn. • a Von ••-a? I kn • c •*. e.4 but 
wel find out when •14 Cubs win the I. mat? :don ilicgdyourbrealli 
.* Len: • 
; •,ottxu : :I. dui . ,...n ready to Mot, 
National Institute for Trial Advocacy 21

## Page 24

KEMPER V. NffA CITY CUBS HOLDINGS, INC. 
Exhibit 3 
Tweets from Jessica Kemper 
11..1, 4• 111. 
y0  41' 
4 X * Ati 
3essica Kemper 
loday rot :DA vett, r, tug, th:htlIP. 
nu'. is OD one i.(' %%no IS .1(4.er thlii 
rt Brow iisaii•L:m..u. la Ivo,
¢tbtaOw.JA 
El= 
ilhathrtt 
Tweets Tweets Z. replies Photos & we•s., 
,,• ft. 1. 
;‘ , S. 8 • 1• • !.e 
This guy might be the Mal straw —how can Dabs my to a gan. when oe 
get the, Insane? 
. k Mum( 
Cla. Jr Cubs st..-naiki on Reg al. Artely bri.crous I. •1-Mor In :le start -I How 
many .i-iges• it• • druid..; does it l to ch lg. oig a , • %...hvb me, 
slope. 411. 
1• a kempte 
.4. t Cubs Pans' i.• • i.xt--"Aie we gc •• 1 to : M.P.?' I nt l..ve the 
Ite • rto 1 • I II..., i.,evea, 
t act 
I: • .1 • Cubs F <pis, e• ...roe • • . to Van, t: n I clant Nom' .. 
See ap://bit.ly/ 1 H3FYtE. 
National Institute for Trial Advocacy

## Page 25

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Exhibit 4 
ImageGram 
Dante! kotien9 
26 Likes 
Dame) Kollen9 
•i:epteniLei 1O. VR.2 11 p 
0 
Daniel Kotleng iOiEddirif ) Great day at the ballpark Hope we get 
extra innings ,tibilinnifmn 
See fittp://biLly/1 L2yZ8O. 
National Institute for Trial Advocacy 25

## Page 26

KEMPER V. NITA CITY CUBS HOLDINCS, INC. 
Exhibit 5 
Nita City Cubs Official Incident Report 
111Cs 
•t• 
1 
Official Incident Report 
Date:  9,/30/YR-7 Time:  6:25 p.m. Inning: 7th Section:  101
Reporting Officer:  Danny Boyle/LK 
Supervising Officer:  Lara Kotkin 
Police Called?  No  Ambulance Called?  Yes
SUMMARY: Victim Jessica Kemper was struck by bat from perpetrator. Dan Kolleng. Kemper injured but 
not an emergency —slight bleeding. complaints of shoulder pain, No police called. 
ACTIONS TAKEN: Kolleng was brought into the office. Explained his bat slipped from his hand. 
Kemper was hysterical, threatening to sue. yelling at Kolleng, Typical drama queen. Said everyone is 
always drunk, Thanked her for statement and let her go to the hospital. 
FURTHER RECOMMENDATIONS: 
looking for a quick buck. Contact Kolleng ASAP and keep him happy. 
I certify and attest that the information contained herein is an accurate and complete description of the 
incident, as reported to me by relevant witnesses, staff members, and Security personnel. 
ion. Kemaea threatened  to sue. ur 
,Gaga Icaticin Supervisor 
National Institute for Trial Advocacy 27

## Page 27

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Exhibit 6 
Nita City Cubs Official Incident Report 
Supplemental Witness Statement, 
Daniel Kolleng 
Official Incident Report 
Date:  9/10/YR-2 Time:  6:25 o.m. Inning;  7th  Section:  101
Reporting Officer:  Danny Boyle/LK 
Supervising Officer:  Lars Kotkin 
Police Called? No Ambulance Called?  Yes 
SUPPLEMENTAL WITNESS STATEMENT 
Daniel Kolleng gave the following statement regarding the incident with Jessica Kemper: 
I came to the game today to watch the Cubs-Sharks with friends from high school. We had lunch and a 
few beers nearby before coming into the game. Over the course of the game, we had several Old Fashions, 
but I am not sure how many. I don't think it could have been more than four or five total over the span of 
several hours. I am not sure of the exact numbers. 
During the seventh inning stretch, I started waving the bat to pretend like I was conducting the band 
to sing "Take Me Out to the Ball Game." It was warm that day, so my hands were sweaty and the bat 
slipped. The bat flew out of my hands and hit the woman in the back of the head, but it didn't look like 
it hit her that hard. The bat is really tiny, and I didn't think it did any damage. Then Security came up 
behind me and grabbed me behind the neck. They took me to the office, and I'm here now telling you 
what happened. 
I was not drunk during the game. I was enjoying myself with my friends for a high school reunion, and 
I don't think I should have to explain my behavior. It was an accident and I am very sorry about it. I've 
already offered to pay the lady's hospital bills. I feel bad, but I wasn't drunk and don't think I should be 
thrown out for this. 
National Institute for Trial Advocacy 29

## Page 28

CASE FILE 
I have read the statement above, and by signing below, I affirm it is a true and accurate recordation of my 
own words and description of the events. 
Darr R-oile, 
Witness 
I certify and attest that the information contained herein is an accurate and complete description of the 
incident, as reported to me by relevant witnesses, staff members, and Security personnel. 
Supervisor 
30 National Institute for Mal Advocacy

## Page 29

KEMPER V. NITA CITY Cuss HOLDINGS, INC. 
Exhibit 7 
Nita City Cubs Official Incident Report 
Supplemental Witness Statement, 
Eddie Davis 
e 
Official Incident Report 
qt) 
Date: 9/:10/YR-7 Time: 6:2. 0.m. 
Reporting Officer:  Danny Boyle/LK 
Supervising Officer:  Lara Kotkin 
Inning:  7th  Section:  1.0a
Police Called?  No  Ambulance Called?  Yes 
SUPPLEMENTAL WITNESS STATEMENT 
Eddie Davis was a witness to the incident and gave the following statement: 
Nobody meant for anybody to get hurt. Danny didn't do anything on purpose. The bat just slipped from 
his hand. Your security guards went nuts, and poor Danny was totally defenseless. He should sue this 
whole team for treating him like that, and I've got half a mind to call the cops on that guy. 
What happened was we went out for some beers and lunch before the game. When we got here, we 
each had maybe five or six beers a piece. This was between the first inning and the seventh though, so it 
wasn't that much. We didn't do anything wrong, and throwing us out is totally ridiculous. 
Danny already said he was sorry to the woman and even said he'd pay for her hospital bills because he 
felt so bad. He did the right thing, and now you're throwing us all out of the game. I'm only giving this 
statement because 1 think you need to hear you're losing fans when this team already stinks. You can't 
afford to be making lifetime diehards like me, and Danny, and the rest of us hate this team. 
National Institute for Trial Advocacy 31

## Page 30

CASE FILE 
I have read the statement above, and by signing below, I affirm it is a true and accurate recordation of my 
own words and description of the events. 
Eeldu Dievvz4 
Witness 
I certify and attest that the information contained herein is an accurate and complete description of the 
incident, as reported to me by relevant witnesses, staff members, and Security personnel. 
in ?catkin Supervisor 
32 National Institute for Trial Advocacy

## Page 31

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Exhibit 8 
Nita City Cubs Official Incident Report, 
Supplemental Witness Statement, Jane Braasch 
Offida ncident fr t 
Date:  9/i1/YR-2  Time:  1400  Inning;  7th  Section:  1D1
Reporting Officer:  taro Kotkin 
Supervising Officer:  Lara Kotkin 
Police Called?  No  Ambulance Called? 
SUPPLEMENTAL WITNESS STATEMENT 
Jane Braasch was a witness to the incident and provided the following statement: 
I was sitting about four seats over from the lady who was hit with the bat. I was on the aisle, my friend 
was next to me, and then the lady's two kids were next to my friend. We were talking the whole game; 
her kids were really cute. They were excited to be at the game. 
The guys behind us seemed fine most of the game, a little loud but nothing unusual for Hannigan. In 
the fifth inning, I remember they started getting louder, started cursing a bit and using foul language. 
I asked them to stop, and one of them, not the guy with the bat, told me to shut my mouth. I didn't want 
any trouble, so I just let it be. I wish 1 had spoken to Security or something because they started to get 
really rowdy. 
At one point, it looked like Security was coming to speak with them, but it turns out they were just 
kicking out some kids up in the front row. They were teenagers who snuck down earlier in the game for 
better seats. 
When the organ started to play "Take Me Out to the Ball Game," we all stood up and got ready to cheer. 
All of a sudden, the guys behind us stood up on their seats instead of the ground. The man with the bat 
started waving it around, and his friends were laughing. About midway through the song, the bat came 
National Institute for Trial Advocacy 33

## Page 32

CASE FILE 
flying out of his hands. I was shocked Security didn't come stop him before that; he was clearly loaded 
by that point. 
When the lady was hit, she went down very hard. Her kids started to cry, so I ran to get a security guard 
or EMTs or whomever. I told the guard what section we were and for some reason he said, "Dammit, 
Ben." We ran back to the stands, and the guard I was with went straight to the lady. There was already a 
security guard with his hands on the gentleman's neck who threw the bat. 
I am giving this statement because I was really sad to see this happen. I just want to say I love the Cubs, 
I don't want any trouble, and I still want to keep coming to Hannigan. I hope this doesn't get me in any 
trouble, but I just think this guy had a few too many. Seemed fine most of the game, but definitely got a 
little rowdy towards the end there. 
I have read the statement above, and by signing below, 1 affirm it is a true and accurate recordation of my 
own words and description of the events. 
7ifne atzocit, 
Witness 
1 certify and attest that the information contained herein is an accurate and complete description of the 
incident, as reported to me by relevant witnesses, staff members, and Security personnel. 
£, lcotkin Supervisor 
34 National Institute for Trial Advocacy

## Page 33

KEMPER V. NITA CITY Cuss HOLDINGS, INC. 
Exhibit 9 
Nita City Cubs Official Incident Report, Diane Sandberg 
111 C 
Official Incident Report 
Date:  9/11/YR-2 Time:  1400  Inning:  7th  Section:  101
Reporting Officer:  Lara Kotkin 
Supervising Officer:  Lard Kotkin 
Police Called? No Ambulance Called? Yes 
Diane Sandberg is an employee involved in the incident and provided the following statement: 
I received a call from your office early this morning to come and discuss what I could remember from 
yesterday's game and the incident involving the fan in Ben's section. I take full responsibility, but would 
like to explain that I don't think Ben did anything wrong. 
Firstly, Ben's sales were not astronomical yesterday. Generally, if the sales are exceeding by leaps and 
bounds the sales of other sections, 1 ask the vendor what's going on, to make sure he's sticking to pro-
tocol. In this case, Ben's sales by the fifth inning were unremarkable. He had returned for a "re-up" each 
inning, but on two occasions I think he hadn't even sold out. 
Additionally, I spoke with other vendors because I was nervous Ben might be not keeping an eye on his 
section and the appearance of drunken fans. According to Mitch Caruso, a security guard, things were 
OK out there. 
When the seventh inning came, I received a radio call that there was an injured fan in Ben's section. 
I didn't jump to any conclusions because sometimes people fall or get injured. Then Mitch came back 
into the serving area and said, "Another TMF." I was so sure Ben had been careful, so I went and talked 
to him later that day. 
Ben told me that he wasn't sure if the guy was drunk, and with so many fans he couldn't remember how 
many beers he served. I told Ben he had better be straight with me because I knew the lady had been 
National Institute for Trial Advocacy 35

## Page 34

CASE FILE 
hurt pretty badly. He told me I should mind my own business and that I needed to realize who the real 
moneymaker was around Hannigan. 
I realize Ben can be brash, but I truly believe he's a great seller and his behavior can be improved over 
time. He's just a kind of bygone-era vendor, and he came up in a time when anything went at Hannigan 
and it was the Wild West. He just is having a hard time adjusting to the new regime, so we should give 
him a chance and make sure he knows what the deal is now. 
If there is anyone to be blamed, it's me because I'm kind of in charge of supervising the guy. But that 
being said, I really think this was an accident because the numbers just don't add up. It doesn't feel like 
a classic case of TMF to me. 
I have read the statement above, and by signing below, I affirm it is a true and accurate recordation of my 
own words and description of the events. 
Diane Sandberg 
Witness 
I certify and attest that the information contained herein is an accurate and complete description of the 
incident, as reported to me by relevant witnesses, staff members, and Security personnel. 
L. Icotkin Supervisor 
36 National Institute for Trial Advocacy

## Page 35

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Exhibit 10 
Nita City Police Department Report Form 52 1-109 
Page 1 of I 
NCH)  `NITA CITY POLICE DEPARTMENT 
41 REPORT FOR 52 4.109---
2. COOE REVTION414 3, 3. ME 
9 1)
4.C'' ROATION 
I)
5. RE 
8. DATE AND TIME OCCURRED-DAY 
ail 0 
7. QATE D TIME 
0 \JR-a_ 0. RESIDENCE 
14. ABET 
REPORTED 
____G.i ADDRESS 
15.008 
8. LOQAT1ON 
,....... /:-. 
9. VIC 'S NAME-LAST, FIRST, MIDDLE 
A) A- _ 
11. RES. PHONE 
12. OCC UP TION 13. RACE-SEX 16. BUS. PHONE 
cr eigov ; AND ut ,.21 FieSETPIRITVIlit ill fht R gra tC401VE 
20. RESIDENOLADDRESS 
R ED CRIME liar "  I - 
16. NAME-LAST, FIRS MIDDLE 
IC 0 t.l c , A 
19. 
b3 N• pc i(' )-4 
21. RES. PHONE 
r ic, \A 
22. =UMW 23. RACE-SEX 
AA, 
24. AGE 
5 
25. DOB 28. BUS. PHONE 
27. NAME LAST, FIRST, MIDDLE 28. 29. RESIDENCE RESS 3D. 
35. 
RES. PHONE 
31. OCCUPATION j 32. RACE-SEX 33. AGE T 34.008 BUS. PHONE 
MU OPERA= 
36. DESCRIBE CHARACTER' OF PREMISES AND AREAWIERE OCCUREO 
cA (-- alit A -( 0011 7 .115 TAA1147d (-AD - _Cluet4 .
37. DECSRIBE BRIEFLY 
clit 4 red - 5Ivyet 
HOW 
INSTRUMENT, 
..4.1 
OFFENSE WAS COMMITTED 
Coin_ 01/1 j cAkt5 14-4 -€4, -(tw4Ard ,
38. DESCRIBE WEAPON, TRICK OR F E USED te. / t-ii.c7 .. 
39. MOTIVE-TYPE OF PROPERTY TAKEN OR OTHER REASON FOR OFFENSE 
41. ESTIMATED LOSS VALUE la -rpw+ 
42. WHAT DID SUSPECT SAY 
43. TRADEMARK OR OTHER DISTINCTWE AC'T'ION 
44. VEHICLE USED 
IGATING OFFICER RECORDING OFFICER I TYPED BY I DATE AND TIME 
63- 
 ROUTED BY 
FURTHER ACTION YES 
RECEIVED BY 
National Institute for Trial Advocacy

## Page 36

KEMPER V. MIA OlY CMS HOLD/NO, INC. 
Exhibit 11 
Letter from Jane Braasch 
c1/14 Nk 
.04-4. 1
sa..6 
at,,d A.A1.>*.St YA-6m) 
Vimp-e 
-pc.Doevo, kitY Wds kali 4-, 
Vt touikt vat -Q.-Ks. 
frcv.A. *AAA, -k-,e ,k.k f 1 14.5 L:4- a, 
AL& V.4.0,4 INAA. 40 sel l -, 
O-4 0.04a. o c -\t '42Ve4 4 S • t trl-A 
ik1/4-0ttAla. 14AZ 044A , \CLVINfatk. • 
akso, A. 
&xi 0,4 &Jos Wr 
0%4- &War 6w9.1 .  AD Tot iPORAireaA 
--Itt;4-C CW-5 , e'%Ar•leLaAe reC 1 404. Vtki 
11-t  CAC-ekS 1 tP`Mk citu.st . 
C..elvdCAL-k-  11V4z. Sepo‘N. • 
National Institute for Trial Advocacy 39

## Page 37

CASE FILE 
-1 7 1.--v'ap..5cCA 
Sv31 '1\) .164S 
1\J 
k.s 
-1)(mckut 
Nib czti culos 
vsouNA4.60,„, ikasuu_Arv,
40 National Institute for Trial Advocacy

## Page 38

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Exhibit 12 
Emails 
To: Ben Stone 
From: Lara Kotkin 
Date: August 10, YR-2 
Subject: Re: Recent Incidents—Future Protocol 
Always the comedian, aren't you Ben?;) 
You've been with us a long time, so you know the deal. Make sure the rookies are following your lead as 
our model vendor! Fan favorite who keeps them comin' back. 
To: Lara Kotkin 
From: Ben Stone 
Date: August 4, YR-2 
Subject: Re: Recent Incidents—Future Protocol 
Hey Lara, 
You're telling us we can't get these knuckleheads drunk when Castro can't find the plate with a map and 
compass!? C'mon Lara—you know what the people want! And it sure ain't the Nita City Cubs this season. 
New motto for the team: Wait 'til next beer! 
O 
To: ALL PERSONNEL 
From: Lara Kotkin 
Date: August 4, YR-2 
Subject: Recent Incidents—Future Protocol 
Hello everyone, 
I know we have discussed in meetings the recent behavior of some of our TMF fans. On the one hand, 
the fun of Hannigan Stadium is part of its appeal, and that's never more true than when the team is doing 
poorly. When our product on the field is less than spectacular, we have got to make sure they're having fun 
in the stands. 
We can't have fans being bored, but we can't have fights or dangerous incidents either. If you have questions 
about intoxicated fans, please check with Security personnel before serving them. But Hannigan is still going to 
be the biggest party in Nita City—can't let a few morons ruin everyone else's fun! Thanks for your cooperation. 
Lara 
National Institute for Trial Advocacy 41

## Page 39

CASE FILE 
To: Lara Kotkin 
From: Diane Sandberg 
Date: August 12, YR-2 
Subject: Re: August Training 
I guess that will work. I really wish you had cleared this with me before talking to Ben and the others. In the 
future, bring this to me first. I need our employees to know that Security is a high priority, and to be honest, 
Diane, you're focused on the sales side. Having been on the business side, totally understand where you're 
coming from. But in the future, clear this with me first. 
Lara 
To: Lara Kotkin 
From: Diane Sandberg 
Date: August 12, YR-2 
Subject: Re: August Training 
Lara, 
Just talked to Ben and a few others in my sections. They're going to just meet with me and go over 
protocols. I know you trust me on this. We're just swamped down here with the Sharks games coming up 
and the Old Fashion promotional deals. Let me handle it —sound good? 
To: ALL PERSONNEL 
From: Lara Kotkin 
Date: August 11, YR-2 
Subject: August Training 
People, 
I am still waiting for about half of you to sign up for these trainings. I know we just had one in June, but 
I just want to get everybody together to remind us of protocol. I think this will be a good idea as we head 
into the final month or so of the season. 
Thanks for cooperating, 
Lara 
P.S. Monday spots are taken. Please sign up for either the Wednesday or Thursday spots. 
42 National Institute for Trial Advocacy

## Page 40

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
To: ALL PERSONNEL 
From: Lara Kotkin 
Date: August 9, YR-2 
Subject: August Training 
Folks, 
As I mentioned last week, we have been experiencing some incidents that give me concern of late. 
Accordingly, I am scheduling additional training sessions this coming week. Please see the schedule below 
and email me with your availability. I will be there, and vendors who do not attend will be disciplined, up 
to and including suspension. 
Thanks for your cooperation, 
Lara 
MONDAY August 13: 2:00 p.m. and 3:00 p.m. 
WEDNESDAY August 15: 10:00 a.m. and 11:00 a.m. 
THURSDAY August 16: 5:00 p.m. and 6:00 p.m. 
National Institute for Trial Advocacy 43

## Page 41

CASE FILE 
To: Lara Kotkin 
Cc: Diane Sandberg 
From: Ben Stone 
Date: June 24, YR-2 
Subject: Re: Midseason Training 
All right, Lara. The buzzkill, as always. I'll see you bright and early Saturday morning for a "training session." 
Should be highly educational. 
To: Lara Kotkin 
Cc: Ben Stone 
From: Diane Sandberg 
Date: June 24, YR-2 
Subject: Midseason Training 
No way, Ben. Get yourself to one of those training sessions. You should have picked an early shift. If it 
interferes with your standup act, that's too bad and it's on you. You have been doing better, but I need you 
to keep that up and not start learning old habits like forgetting when the 7th Inning starts... No goofing 
around. 
To: Lara Kotkin 
Cc: Diane Sandberg 
From: Ben Stone 
Date: June 18, YR-2 
Subject: Midseason Training 
All these weekend sessions!? On the one week we've got time off. C'mon Lara. Lighten up, you know my 
record's been awesome since May. 
Diane, back me up. 
To: Ben Stone 
Cc: Diane Sandberg 
From: Lara Kotkin 
Date: June 24, YR-2 
Subject: Midseason Training 
Ben, 
Can you pick a date for midyear training? The highlighted sections below all have one spot left. If you need 
to coordinate with Diane, let me know. Thanks. 
44 National Institute for Trial Advocacy

## Page 42

KEMPER V. NITA CITY CUBS HOLDINGS, 
Hey everyone, 
So next week, our Cubbies are on a long road trip. What better time to schedule training 
sessions for midyear? I am looking forward to going over our protocols, how they're doing, 
and what we can do better. Please see the schedule below and sign up with your Section 
Manager. I am making myself available, so as soon as I have ten people in any given slot, 
the meeting will be set. Thanks! 
Lara 
Time Mon -25 Tue-26 Wed-27 Thurs-28 Fri-29 Sat-30 Sun-1 
9:00 
12:00 
2:00 
5:00 
To: 
From: 
Date: 
Subject: 
ALL PERSONNEL 
Lara Kotkin 
June 18, YR-2 
Midseason Training 
Hey everyone, 
So next week, our Cubbies are on a long road trip. What better time to schedule training sessions for 
midyear? I am looking forward to going over our protocols, how they're doing, and what we can do better. 
Please see the schedule below and sign up with your Section Manager. I am making myself available, so as 
soon as I have ten people in any given slot, the meeting will be set. Thanks! 
Lara 
Time Mon -25 Tue-26 Wed-27 Thurs-28 Fri-29 Sat-30 Sun-1 
9:00 
12:00 
2:00 
5:00 
National Institute for Trial Advocacy 45

## Page 43

CASE FILE 
To: Lara Kotkin 
From: Diane Sandberg 
Date: May 27, YR-2 
Subject: Re: Ben Stone—Section Difficulties 
I really wouldn't sweat the small stuff; Lara. Ben's my best seller, and I keep an eye on him. He's a goof but 
never does anything dangerous. Sometimes, you just get unlucky with the wrong fan at the wrong time —
there's no accounting for that. Even if he were the most careful vendor we have (and God knows he's not), 
you'd still get a fight now and then. Let me handle him going forward! 
To: Diane Sandberg 
From: Lara Kotkin 
Date: May 25, YR-2 
Subject: Ben Stone—Section Difficulties 
Hi Diane, 
I was wondering if you have a chance to chat about Ben Stone. I know he's a great seller and does well with 
fans, which I love. My question is whether or not he's too good a seller if you catch my drift —lots of issues 
and we're not even a few weeks into the season. Thoughts? 
46 National Institute for Trial Advocacy

## Page 44

KEMPER V. NITA CITY Cues HOLDINGS, INC. 
To: Ben Stone 
From: Lara Kotkin 
Date: April 1, YR-2 
Subject: New Sherriff in Town C) 
Sure, Ben, be in my office at 10:30. Emily will be there, too. 
To: Ben Stone 
From: Lara Kotkin 
Date: April 1, YR-2 
Subject: Re: Training Sessions 
Lara—so sorry I missed these sessions. Can I come in tomorrow to do a training? 
To: ALL PERSONNEL 
From: Lara Kotkin 
Date: March 30, YR-2 
Subject: Training Sessions 
Hi everyone, 
The following vendors have not attended the Pre-Season Training Session and missed the Make-Up Session: 
Monica Alou 
Harold Dawson 
Jamie Prior 
Ben Stone 
Emily Wood 
Please email me immediately to (a) explain your absence and (b) schedule a supplemental training with me 
personally before Opening Day. 
Thank you, 
Lara 
National Institute for Trial Advocacy 47

## Page 45

CASE FILE 
To: Ben Stone 
From: Lara Kotkin 
Date: January 8, YR-2 
Subject: New Sherriff in Town 414 
Hi Ben, 
Totally understanding ribbing the new boss, but keep in mind I am still your boss. I know how things 
operated around here before, and I'm trying to change the culture. I hope you will get on board with that; 
I know you're a real treasure here and a fan favorite. I just don't want you to be a fan favorite because you 
keep the tabs running the whole game. 
You know our bottom line is important. I'm from the corporate side; I'm not some washed-up old cop here 
to be a drill sergeant. But I also know that while I want fans to have fun, Too Much Fun (TMF) fans will cost 
us money eventually, one way or another. 
If you have any questions come see me right away. Looking forward to working with you in this new capacity. 
Lara 
To: ALL PERSONNEL 
From: Benjamin Stone 
Date: January 8, YR-2 
Subject: Re: New Sherriff in Town O 
Easy there, Quick Draw! We've been doing things a certain way in this dude ranch for a while, so maybe we 
should take some baby steps. How serious are we about all this? 
O 
To: ALL PERSONNEL 
From: Lara Kotkin 
Date: January 8, YR-2 
Subject: New Sherriff in Town O 
Hello everyone, 
I just want to say how excited I am to have just been named the new head of the Security Department at 
Hannigan Stadium. I speak for everyone in the organization when I say that the safety and security of our 
fans is Priority #1. We know what people think of Hannigan, and there's nothing wrong with having a good 
time. But from now on, dangerous behavior won't be tolerated. 
To get prepared for the upcoming season, please check your emails regularly for updates regarding training 
sessions. This goes for newer employees and old salts alike. I don't want to reinvent the wheel, but I do 
want to make sure we're all doing our best. 
Signups for training will be forthcoming. Dust off those manuals before Spring Training! 
Lara 
48 National Institute for Trial Advocacy

## Page 46

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Exhibit 13 
Nita City Police Department Supplemental Reports 
Nita City Police Department 
Third Precinct 
4270 West Barry Avenue 
Nita City, Nita 
SUPPLEMENTAL REPORT 
CASE NO: 
VICTIM NAME: 
LOCATION: 
OFFICER: 
DATE OF INCIDENT: 
DATE OF REPORT: 
I 7420-KOL 
N/A 
Third Precinct 
Jack Wambach. 
September 10, YR-2 
September 17, YR-2 
I received a notice from Dispatch that an unidentified female was present at the Precinct HQ and 
wanted to give a statement re: arrest of Daniel Kolleng. Kolleng had been arrested on a 402 at Hannigan 
Stadium two days before the witness volunteered the following information. 
Witness, Jessica Kemper, maintains that Daniel Kolleng was drunk, disorderly, and intoxicated 
within the stadium prior to arrest on the street. Kemper informed me that Kolleng struck her in the head 
with a souvenir bat during the sixth or seventh inning of the game. She said that most of the game, 
Kolleng and his associates were making rude comments, being "disgusting," and offending those around 
them. She said when she complained to staff, nothing was done. 
I interrupted Kemper and asked why she was informing me of this, and asked if she was seeking 
to press criminal charges for her injuries. Kemper was wearing a sling at this time, and I inquired as to the 
nature of her injury. She informed me that the injuries were from Kollenv incident. She informed me that 
the Cubs had done nothing and she wanted something to be done. Kemper was not aware that 
immediately after being ejected, Kolleng was arrested by NCPD for 402 and had spent the night in 
lockup. When 1 informed Kemper of this, she stated it served him right and she wanted to help anyway 
that she could. I asked her to provide a written statement regarding his behavior prior to arrest. She did 
not want to pursue additional criminal charges and said she would be willing to testify against Kolleng if 
needed during any subsequent trial or court encounter related to his 402 misdemeanor charge. 
National Institute for Trial Advocacy 49

## Page 47

KEMPER V. NITA CI1Y CUBS HOLDINGS, INC. 
NC P1) 
Nita City Police Department 
Third Precinct 
4270 West Barry Avenue 
Nita City, Nita 
SUPPLEMENTAL REPORT 
CASE NO: 
VICTIM NAME: 
LOCATION: 
OFFICER: 
DATE OF INCIDENT: 
DATE OF REPORT: 
17420-KOL 
N/A 
Third. Precinct 
Jack Wambach 
September 10, YR-2 
September 11, YR-2 
Witness Eddie Davis came to Precinct 3 to remove suspect from custody. When he arrived, he 
volunteered the following statement: 
I am sorry for the misunderstanding yesterday evening. I understand I never should have put my 
hands on you, but 1 had a few too many and was not myself. This is really nor Danny's 
(suspect's) fault since he was the one of us who drank the least. We were all mad leaving the 
stadium because we had just been thrown out. Danny accidentally threw one of those little 
souvenir bats and bumped some lady in the elbow. The security guards overreacted and tossed us 
out of the stadium. 
We were upset with each other at first, but when you made your arrest, we had just been joking 
around. Danny did not hit me; he jokingly shoved me in a friendly way. I only put my hand on 
your shoulder to explain that it wasn't his fault and was not a big deal. I apologize for this 
inconvenience. Danny did nothing wrong, and this was mainly my fault for being obnoxious. 
Witness seemed sincere. Suspect committed no major offenses aside from being intoxicated in 
public. Charges not likely. Suspect paid fine for 402 and was released. 
National Institute for Trial Advocacy 51

## Page 48

KEMPER V. NITA Cm' Cues HOLDINGS, INC. 
Nita City Police Department 
Third Precinct 
4270 West Barry Avenue 
Nita City, Nita 
SUPPLEMENTAL REPORT 
CASE NO: 
VICTIM NAME: 
LOCATION: 
OFFICER: 
DATE OF INCIDENT: 
DATE OF REPORT: 
7420-KOL 
N/A 
Third Precinct 
Jack Wambach 
September 10, YR-2 
September 10, YR-2 
Was on patrol near the southeast gates ofHannigan Stadium on the evening of Saturday, 
September 10, YR-2. Other officers in the area, including equine units and bike units at the northwest 
gates of Hannigan Stadium. Suspect in question exited the southeast gates escorted by Cubs Security. 
Suspect was accompanied by several companions, all of whom were screaming loudly at the security 
officers escorting them from the premises. Radioed to units around the stadium and confirmed that Cubs 
Security had not called in any 402s_ 
I approached the subject and asked him to calm down. Suspect asked me who I thought I was, and 
I asked him to calm down. Companion shouted, "Danny, that's enough for one day." Suspect was upset 
by that comment, which led to a shouting match between the two. I asked both to calm down, and suspect 
initially did. He explained to me that he had been escorted out of the stadium by security. I asked why, 
and he said it was none of my business. I told him to relax because drunks in the area were my business 
and the business of the Nita City PD. His companion approached me and got close to my face and told me 
that I was out of line. I asked him to stand back, and he complied. 
I told the group to head home and sleep it off. I turned north and as I walked away heard a 
commotion behind me, in the direction the gentlemen had been walking. I turned south to see suspect 
shove one of his companions. I approached suspect, who told me I should lighten up. I told him to put his 
hands behind his head and kneel on the gound, and 1 was arresting him for disorderly conduct and 
battery. Before I could. provide him with his Miranda rights, one of his companions put his hand on my 
shoulder and told me it was his fault. At that point, I sternly warned the companion to back away, and he 
complied immediately. Suspect was cooperative, and I placed him under arrest for a 402. Suspect has 
been booked on a 402. 
National Institute for Trial Advocacy 53

## Page 49

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Exhibit 14 
Nita City Police Department 
Formal Letter of Reprimand 
Nita City Police Department 
Third Precinct 
4270 West Barry Avenue 
Nita City, Nita 
June 11, YR-2 
Officer Jack Wambach 
FORMAL LETTER OF REPRIMAND 
Dear Officer Wambach: 
This is to notify you that 1 am issuing you a formal Letter of Reprimand (LOR) pursuant to the 
Management Directives of the Nita City Police Department (NCPD). This action is being taken 
to improve the efficiency and effectiveness of the NCPD and to advise you that future acts of mis-
conduct as described below will be dealt with more severely in accordance with the Management 
Directives and the Collective Bargaining Agreement. 
Charge 1: Excessive Use of Force 
On May 1, you placed three individuals under arrest for suspicion of drunken and disorderly conduct. 
Your location was outside Murphy's Bleachers near Hannigan Stadium. At approximately 7:05, you 
requested backup and officers arrived on the scene to assist. 
The assisting officers, Lieutenant Kevin Morley and Officer Amy McGrath, interviewed the suspects 
and determined that none of the three had been drunk or disorderly. After interviewing all three 
suspects, both assisting officers determined that you accosted the fans as they were leaving opening 
day and asked them to stand against a back wall near Murphy's. One suspect, an attorney, asked for 
the basis of your arrest. According to multiple witnesses, you told the suspect to "shut [his] face," 
then forcibly pushed him against the wall. At this point, the other two suspects complied with your 
requests but asked for your badge number. You refused to provide your badge number and name, in 
National Institute for Trial Advocacy 55

## Page 50

CASE Fn 
clear violation of NCPD protocol. The assisting officers released all three suspects with the apologies 
of the NCPD and filed a report related to your behavior. 
On May 22, you were given the opportunity to respond orally to the charges against you. I met with 
you to discuss the charges and carefully weighed your account of the story. You maintain the three 
suspects were intoxicated and that each suspect, individually and collectively, resisted your requests 
for information and presented a threat. You also asked me to consider the setting, given the high 
instances of drunken behavior and 402 arrests around Hannigan in recent memory. 
I have determined that you used excessive force. You lacked any reasonable suspicion to find these 
individuals intoxicated. According to the assisting officers and the attorneys for the three suspects, they 
had left the bar early to avoid dealing with an intoxicated crowd once the Cubs game had dispersed. 
In determining the appropriate punishment, I have considered your record and disciplinary history. 
It is my determination that this LOR will serve as an appropriate warning to use better judgment and 
caution when in the field in the future. You have the right to appeal this letter through your union 
representative, either in writing or orally, within thirty days of issuance. 
By signing below, you are merely acknowledging receipt of this action. You still maintain the right 
to appeal, and your signature in no way indicates you agree with the action against you„ We look 
forward to providing any support, guidance, or further training so that you continue to serve the 
NCPD honorably and responsibly. Please do not hesitate to contact me with questions. 
Yours truly, 
Nike Quinton 
Captain Mike Quinlan 
Third Precinct 
1,0a,ratxch
Officer Jack Wambach 
Received 6/11/YR-2 
56 National Institute for Trial Advocacy

## Page 51

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Exhibit 15 
Nita City Times Newspaper Articles 
The Nita City Times 
OCTOBER 8, YR-2 
AT HANNIGAN, PARTY ATMOSPHERE OR SAFETY CONCERN? 
BY MARK SWANTEK 
Editorial 
NITA CITY—For as long as the 
Nita City Cubs have played 
baseball at Flannigan Stadium, Old 
Fashion Beers have been a staple 
of the concession stands. The Cubs 
and Old Fashion have gone 
together like "peas and carrots," 
according to Old Fashion CEO 
Jared floppsman. But recently, 
concerned fans have wondered if 
this old friendship has developed 
into a safety concern. 
"1 just couldn't believe that the 
Cubs would allow someone to get 
that drunk," says Jessica Kemper. 
Kemper, a mother of three and 
lifelong Cubs fan, was injured by a 
fan she claims was drunk and 
violent during a game she attended 
with her children in September. 
According to Kemper, a and 
his friends sitting near her on 
September 9. YR-2, became drunk 
National Institute for Trial Advocacy 
and disorderly during the Cubs 
game against their rivals, the 
Sharks. 
"He and his friends drank nonstop 
the entire game." Kemper says that 
she and fans around her noticed the 
behavior, but security guards and 
vendors at the stadium did nothing. 
Eventually, the fan threw a 
souvenir bat, hit Kemper in the 
back of the head, and sent her to 
the hospital. This was not the first 
such incident in recent memory. 
Officer Jack Wambach, a Nita City 
Police Department (NCPD) 
official reached for comment, said 
he could not comment on 
Kemper's injury, but did note that 
drunken behavior has become "a 
real concern in the Third Precinct." 
Wambach stated that NCPI) 
officials and Cubs security work 
together to prevent over-
consumption of alcohol, but that 
lately he and other officers noted 
an uptick in arrests. 
The Nita City Cubs would not 
speak to the Nita city Times for 
this article. When reached for 
comment, Cubs Security Director 
Lam Kotkin said she would not 
comment, except to note that the 
fan had been ejected immediately 
and the Cubs were further 
investigating the matter. 
Floppsman stated Old Fashion will 
continue its long relationship with 
Hannigan and the Cubs despite the 
recent incidents. 
For Kemper, the solution is simple. 
"They need to provide a safe 
environment for fans and their 
families." 
57

## Page 52

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
The Nita City Times 
APRIL 2, YR-2 
KOTKIN LOOKS TO IMPROVE HANNIGAN, ADDRESS SAFETY CONCERNS 
BY JOE MORLEY 
Reporter 
NITA CITY—This summer at 
Hannigan Stadium, the boys of 
summer might not make it to the 
World Series. The Nita City Cubs 
are projected by most in the know 
to finish in dead last in their 
division. But as with every 
summer, tourists and diehard fans 
alike will fill Hannigan Stadium's 
historic grounds. This year, Lam 
Kot kin, Director of Security for the 
Cubs, hopes to improve the fan 
experience from top to bottom. 
"We know our fans love to enjoy 
their team and the stadium, but 
they're going to have to start doin€ 
it more responsibly." Since 
assuming her role, Kotkin has been 
working tirelessly to improve the 
safety at Flannigan Stadium. She 
has pushed the organization to start 
installing cameras in the '.radium, 
though that will have to wait until 
next season. when the team takes 
on major renovations. "There arc 
National Institute for Trial Advocacy 
things we can and must do for the 
safety of our fans," Kotkin said. 
Lieutenant Sheryl Myers of the 
Nita City Police Department's 
Third Precinct says she looks 
forward to the changes. "We have 
been on the organization for a 
while now to clean up the 
stadium." LL Myers notes that 
though violent crime in the area is 
down significantly since Kotkin 
assumed her position, arrests for 
drunk and disorderly conduct 
remain around the stadium. "We 
know fans like to have fun," says 
Lt. Meters. "but this has to stop so 
we can focus on real police work." 
In addition to the cameras to be 
installed next season, Kotkin is 
taking a stronger hand in 
Hanninan's biggest industry: beer 
sales. Last season, beers sales 
generated more revenue than food 
and. souvenir sales combined. 
Kotkin says she is not concerned if 
people become intoxicated, as long 
as they allow others to enjoy the 
game in peace. "We know people 
are here to have a good time. I 
don't want to be anyone's nanny, 
but we can't have a few bad apples 
spoiling the experience for others." 
Kotkin says she plans on 
instituting a comprehensive 
training program for beer vendors 
to help them identify overserved 
patrons, and to increase 
communication between vendors 
and security staff. Kotkin says she 
hopes the changes will make 
Hann' n. "a more fat ily- friendly 
environment for taking in a 
ba ['game." 
59

## Page 57

KEMPER Y. NffA CITY CUBS HOLDINGS, INC. 
17C 
National Institute for Trial Advocacy 69

## Page 58

KEMPER V. NITA of CUBS HOLDINGS, INC. 
17D 
L 
-"‘ 
eit tlifOr 
National Institute for Trial Advocacy 71

## Page 60

KEMPER v. NITA On' CUBS HOLDINGS, INC. 
EXCERPTS FROM DANIEL KOLLENG'S DEPOSITION 
1 
2 
3 
4 
6 
7 
8 
9 
10 
11 
12 
13 
14 
15 
16 
17 
18 
19 
20 
21 
22 
23 
24 
25 
Page 1 
IN THE U.S. DISTRICT COURT 
DISTRICT OF NITA CITY, NITA 
CIVIL DIVISION 
JESSICA KEMPER 
Plaintiff, 
Vs. CAL: YR-3-C1V-10784 
NITA CITY CUBS HOLDING, INC. 
Defendants. 
DEPOSITION OF DANIEL KOLLENG 
REPORTER: BALINDA DUNLAP, CSR NO. 10710, CRR, RMR 
Page 3 
1 Q. Do you live alone at 4632 N. Kilpatrick? 
2 A. No, I'm married. 
3 Q. Do you have children? 
4 A. Yes, two girls. 
5 Q. Were you at Hannigan Stadium on September 
6 10, YR-2? 
7 A. Yes, I was. 
8 Q. Why were you at the stadium that day? 
9 A. I was attending a Cubs game with friends 
10 of mine from high school. 
11 Q. Where did you attend high school? 
12 A. Nowhere around here. I'm originally from 
13 Rutheford, a small town downstate. I went to 
14 Jackson High. 
15 Q. When did you move to Nita City? 
16 A. Two years after graduating from college. 
17 Gosh, it must have been 15 or 16 years ago. 
18 Q. Why you did you move to Nita City at that 
19 time? 
20 A. My girlfriend at the time, now my wife, 
21 Amanda, had a job up here so I decided to follow 
22 along. 
23 Q. Where did you go to college? 
24 A. I went to Kenesaw College, a small liberal 
25 arts college downstate. Then I moved here and went 
Page 2 
1 DEPOSITION OF DANIEL KOLLENG 
2 BE IT REMEMBERED THAT, pursuant to notice, 
3 commencing at the hour of 2:45 p.m. thereof, at 3200 
4 E. Clymont, Nita City, Nita, before me, 
5 Balinda Dunlap, a Certified Shorthand Reporter, there 
6 personally appeared on September 15, YR-1 
7 DANIEL KOLLENG 
8 called for oral examination by counsel for 
9 Plaintiff, who, after having been duly sworn to 
10 tell the truth, the whole truth, and nothing but 
11 the truth, testified as follows: 
12 ---o0o---
13 Q. What is your name sir? 
14 A. Daniel Kolleng. 
15 Q. Can you tell us your address? 
16 A. I live at 4632 N. Kilpatrick. 
17 Q. What city do you live in? 
18 A. Nita City, Nita. 
19 Q. What is your current occupation? 
20 A. I am a speech therapist at lames Monroe 
21 Middle School. 
2? Q. How long have you been a speech therapist? 
23 A. Since YR-13. 
24 Q. How old are you? 
2.5 A. I am 41. 
Noe 4 
1 to grad school for speech therapy. 
2 Q. On the day in question, you were with your 
3 friends from Jackson High? 
4 A. That's correct. We were having our own 
5 kind of high school reunion. 
6 Q. How many of your friends attended? 
7 A. It was myself and three other friends. We 
8 had four tickets to the game total. 
9 Q. Had you attended a Cubs game before that 
10 day? 
11 A. Oh yes, dozens. I am a lifelong fan of 
12 the Cubs unfortunately. 
13 Q. Why do you say "unfortunately"? 
14 A. I'm sorry, I was only kidding. Yes, I had 
15 been to games before. 
16 Q. Prior to the event in question, when was 
17 the last time you had attended a game? 
18 A. I went to a game on the Fourth of July, 
19 and I was also at Opening Day. I have been lucky 
20 to make a few games this years. 
21 Q. Returning to the clay in question, when did 
22 you arrive at the game? 
23 A. We got there about half -way through the 
21 first inning. 
25 Q. Why were you late to the game? 
1 (Pages 1 to 1) 
National Institute for Trial Advocacy 75

## Page 61

KEMPER V. NITA QTY CUBS HOLDINGS, INC. 
Page 5 
1 A. We were having lunch and beers at a bar 
2 nearby, and just like most Cubs fans, we weren't in 
3 any hurry to get in to watch the game. 
4 Q. What do you mean by that? 
5 A. Well, since the Cubs are so bad, but 
6 Hannigan is a fun place to be; the bars are always 
7 packed on the game day. 
8 Q. Were they crowded on the day in question? 
9 A. Absolutely. It was a beautiful Saturday 
10 afternoon, so many people came to the area just to 
11 be part of the scene. 
12 Q. When you arrived at the game, was the 
13 stadium full? 
14 A. No. 
15 Q. Was your section full? 
16 A. Maybe half full, it wasn't very crowded 
17 yet. 
18 Q. How many alcoholic beverages did you 
19 consume during lunch? 
20 A. I can't remember. Not many. We were just 
21 enjoying the day. My friends had many more beers 
22 than I did. 
23 Q. I-low many did they have? 
24 A. I can't recall. 
25 Q. When you arrived at the stadium, how did 
1 
2 
3 
4 
5 
6 
7 
8 
9 
10 
11 
12 
13 
14 
15 
16 
17 
18 
19 
20 
21 
22 
23 
24 
25 
Page 7 
the game. 
Q. And you added none? 
A. No. At the beginning of the game, I took 
a quick pull just to get Eddie off my back about 
it. 
Q. Why were you concerned about being thrown 
out? 
A. Well, Hannigan Security are always on the 
prowl. Eddie told me they would be careful since 
the Cubs started cracking down on drinking. 
Q. But they continued to drink the outside 
liquor anyways? 
A. Yes, it was all in good fun. Also, I've 
been to Hannigan enough times to know they're all 
bark and no bite. You're only getting thrown out 
if you punch the starting pitcher. 
Q. What happened in between the bottom and 
top halves of the seventh inning? 
A. That's when the bat slipped from my hands 
and hurt the plaintiff, Ms., urn, Kemper. 
Q. When the bat hit her, what happened to 
Ms. Kemper? 
A. She fell over, and it looked like she was 
bleeding. 
Q. Where was she in relation to your seats? 
1 
2 
3 
4 
S 
6 
7 
8 
9 
10 
11 
12 
13 
14 
15 
16 
17 
18 
19 
20 
21 
22 
23 
24 
25 
Pane 6 
you order beers? 
A. I mean, I got them from, what do you mean? 
Q. Did you buy them from a kiosk or vendor 
walking around? 
A. I ordered a beer from our vendor and 
bought the first round. 
Q. Were you asked to present identification? 
A. No, but my friend Mike looks younger than 
he is, so he had to show his I.D. 
Q. How would you describe the environment in 
your section? 
A. It was loud, it was raucous, but overall 
people were just having a good time. 
Q. When did you order your next beer? 
A. Well, I took my time with my beers because 
my friend Eddie brought alcohol with him, which he 
added to his beers. Eddie called it "putting them 
on their feet." 
Q. Did any Cubs personnel see you do this? 
A. No, Eddie was pretty sneaky about it. I 
was nervous we'd get in trouble. 
Q. How much liquor did your friends add to 
their beers? 
A. Not much, I told them I thought it was 
stupid. I also didn't want to get thrown out of 
Page 8 
1 A. I don't know, maybe a few rows ahead of 
2 me. Close, but not directly in front of me and my 
3 friends. 
4 Q. How did the people around you reacted? 
5 A. Confused. They were looking around, 
6 trying to figure out what happened. 
7 Q. What happened then? 
8 A. One security guard went right to 
9 Ms. Kemper, and another came to me and grabbed me 
10 by the arm and by the neck. 
11 Q. What did you do? 
12 A. I said, "Oh, my God. I am so sorry. It 
13 just slipped from my hand." 
14 Q. What happened after that? 
15 A. The security guard said, "Whatever you 
16 say, rummy. Tell it to the cops." I was really 
17 annoyed when he said that, because it was an 
18 accident, and I wasn't drunk. 
19 Q. What happened next? 
20 A. He escorted me to the security office on 
21 the other side of the stadium. 
22 Q. Once you were there, what did the security 
23 personnel do? 
24 A. They sat me on a bench at the far end of 
25 the room. 
National Institute for Trial Advocacy 
2 (Pages 5 to 8) 
77

## Page 62

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Page 9 
1 Q. What interactions did they have while in 
2 the Security office? 
3 A. Well, besides the security guard who 
4 manhandled me to the office, their head of Security 
5 was there, and she was terrifying. 
6 Q. How do you mean? 
7 A. Just so serious, made it sound like I 
8 murdered someone. She said, "We take this kind of 
9 drunken nonsense pretty seriously." 
10 Q. How did that make you feel? 
11 A. I explained to her that I wasn't drunk, 
12 and is that it was a simple mistake. 
13 Q, How many beers had you consumed during the 
14 game? 
15 A. By the time I was taken to the office, 
16 don't know. Maybe two or three, no more than that. 
17 Q. But some had liquor in them, the liquor 
18 your friend Eddie gave you? 
19 A. Not much in mine. Maybe one or two beers 
20 had a drop of whiskey. Also these were beers 
21 drank over the span of several hours. 
22 Q. How was the weather that day? 
23 A. It was a scorcher, pretty humid. We were 
24 also in the sun for a lot of the game. 
25 Q. When the head or Security questioned you, 
Page 11 
1 Q. She mentioned a lawsuit? 
2 A. She told me people love to sue the Cubs 
3 for silly things. The security guard who brought 
4 me in said that everyone who bumps their knee on a 
5 seat thinks they can retire off it if they sued the 
6 Cubs. We all laughed a bit. 
7 Q. What else did you tell the Security 
8 personnel? 
9 A. Nothing. Before I could say anymore to 
10 her, Ms. Kemper came in. 
11 Q. What happened then? 
12 A. I just sat there silently. I didn't say a 
13 word I was so embarrassed. 
14 Q. What did the Security personnel ask her? 
15 A. Many of the same questions she asked me, 
16 but Ms. Kemper was pretty upset. Her kids were 
17 there, and they were crying. It was a complete 
18 mess, and I felt awful. 
19 Q. What, if anything, did she say to you? 
20 A. She looked at me and yelled a lot. 
21 Something like, "If that drunken idiot doesn't get 
22 arrested, I'll be suing you people." She was 
23 furious. 
2.4 Q. What did you say? 
25 A, I started to talk, but the security woman 
Page 10 
1 what did you say? 
2 A. I gave her my side of the story. I told 
3 her I wasn't drunk, my hands were slippery and it 
4 just slipped. 
5 Q. Did she believe you? 
6 A. She listened to me and said, "Well, I'm 
7 glad to hear we won't need to call the police." 
8 Q. How did you feel when she said that? 
9 A. Great. I thanked her. She was really 
10 reasonable. She said, "Don't get me wrong. I 
11 don't get any pleasure from calling the police. It 
12 makes us all look bad." 
13 Q. What other questions did she ask' 
A. She asked me how many alcoholic beverages 
15 I had consumed, what section I was in, if I could 
16 describe my vendor, pretty standard questions. 
17 Q. What did you tell her' 
18 A. I told her I was as sober as a judge, only 
19 had a few beers. Told her what our vendor looked 
tl like. I said I was willing to cooperate. 
7.1 O. How Old she t espoi id? 
22 A. She was so nice after that. She was glad 
23 to hear I was sober. She said that made her job 
.!..1 much easier, especially if there was some kind of 
lawsuit. 
1 
3 
5 
6 
7 
8 
10 
11 
12 
13 
14 
15 
16 
.17 
18 
19 
.11) 
1 
2 2. 
24 
25 
Page 12 
put her hand up, like I shouldn't say anything. 
Q. What happened after Ms. Kemper left? 
A. I gave a statement, and then I was 
escorted out of the stadium which was insane. 
Q. Why do you say that? 
A. I wasn't drunk; it was just an accident. 
Then they threw me and all my friends out. I felt 
terrible, and Eddie was pretty mad about the whole 
thing. 
Q. What happened when you left? 
A. Eddie and I were yelling at the guard who 
let us out. We were obviously mad. Then Eddie 
kind of shoved me, just kidding around, and out of 
nowhere this cop came up to us. 
Q. What happened then? 
A. He was incredibly aggressive, basically 
like he was just waiting for us. We told him we 
were leaving and he should mind his own business. 
He didn't like that and we kind of exchanged words, 
but everything cooled off. 
Q. Did yon leave'' 
A. Yeah, we started to walk away. 
Q. which direction from the st,idii 
A. I don't even remember, it didn't matter, 
he was on us again in five seconds. 
NaliOnal Institute for Trial Advocacy 
3 (Pages 9 to 12 
79

## Page 63

REAPER V. Nn Cm Cuss HOLDINGS, INC. 
Pagt: 13 
Q. What caused u n to come back? 
2 A. Eddie and I were kind of laughing about 
3 all this nonsense, and I shoved him jokingly. 
4 That's when the cop was on us and said he was 
5 arresting me for battery and drunker behavior or 
6 something. 
7 Q. Were you handcuffed? 
8 A. He started to cuff me, then Eddie put his 
9 hand on his shoulder and he absolutely freaked out. 
10 I told everyone to just calm down; I'd go in and 
11 just diffuse the situation. 
12 Q. Were you taken to the station? 
13 A. Yeah, put in the squad car in front of all 
14 those fans. Totally humiliating. Then I spent the 
15 night in the drunk tank with a bunch of fans who 
16 were actually really drunk. 
17 Q. When were you released? 
18 A. The next day. I was so mad when I saw 
19 Eddie, we both never wanted to watch the Cubs 
20 again. 
21 Q. If you were so mad, why are you testifying 
22 for the Cubs today? 
23 A. Because I feel bad. I didn't do anything 
24 wrong and neither did they. It was just an 
25 accident. Once I got calmed down, still a fan 
1 
2 
3 
4 
5 
6 
8 
9 
10 
11 
12 
13 
11 
15 
16 
17 
113 
19 
20 
21 
22 
2.3 
24 
25 
Pale 
DEPOSITION REPORTER'S CERTIFICA1 E 
I hereby certify that the witness in the 
foregoing deposition named, 
DANIEL KOLLENG 
Was by me duly sworn to testify the truth, the whole 
truth, and nothing but the truth in the within-entitled 
cause; that said deposition was taken at the time and 
place therein stated; that the testimony of said 
witness was reported by me, Balinda Dunlap, a Certified 
Shorthand Reporter, a disinterested person, and was 
taken down by me in stenotype and transcribed through 
computer-aided transcription; and that the pertinent 
provisions of the applicable code or rules of civil 
procedure relating to the notification of the witness 
and counsel for the parties hereto of the availability 
of the original transcript of deposition for reading, 
correcting and signing have been complied with, 
And I further certify that I am not of counsel 
or attorney for either or any of the parties to said 
deposition, nor in any way interested in the outcome of 
the cause named in said caption, 
IN WITNESS WHEREOF, I have hereunto subscribed 
my hand this October 10, YR-
in/ i radar Dunlap 
Balinda Dunlap, CSR No. 10710, CRR, RMR 
Pone 14 
1 through and through. 
2 Q. How did the accident happen? 
3 A. I was waving the bat they gave all the 
4 first guests a little bit to get the crowd excited 
5 for the seventh inning stretch. It just slipped; 
6 my hands were a bit sweaty. 
7 Q. What happened after Ms, Kemper left? 
8 A. I stayed with security, and they explained 
9 to me how to handle things if there was a lawsuit. 
10 Don't say anything, give them a call, they could 
11 handle it, 
12 Q. When did you give them a call? 
13 A. As soon as I knew the suit had been filed. 
14 I was so mad at this lady. It was an accident, and 
15 she was suing a bunch of people to get nothing but 
16 just a meal ticket. It's ridiculous. 
17 Q. Have you spoken with her since the date in 
18 question? 
19 A. No. 
20 (Whereupon the proceedings were 
21 concluded.) 
22 ---o0o---
23 
24 
25 
Page 16 
1 DECLARATION OF WITNESS 
2 1', DANIEL KOLLENG, hereby declare that I have read the 
3 foregoing testimony, and the same is true and correct 
4 transcription of my said testimony except as I have 
5 corrected. 
6 
7 
8 
10 
11 
12 
1:3 
1.1 
15 
16 
17 
18 
19 
20 
21 
22 
23 
24 
25 
Da Hie  I Kolleng 
Signature 
October 21 Y R - 1 
Date 
4 (Pages 13 to 16) 
National Institute for Trial Advocacy 81

## Page 64

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
EXCERPTS FROM BENJAMIN STONE'S DEPOSITION 
Page 1 
3 
5 
6 
Plaintiff, 
IN THE U.S. DISTRICT COURT 
DISTRICT OF NITA City, N rrA 
CIVIL DIVISION 
JESSICA KEMPER 
Vs. 
13 
NITA CITY CUBS I IOLDING, INC. 
9 
Defendant•:. 
10 
I 
12 
13 
1.1 
15 
16 
17 
18 
19 
20 
21 
22 
23 
24 
CAI.: YR-3-CIV•10784 
DEPOSITION Of' BENJAMIN STONE 
REPORTER: BALINDA DUNLAP, CSP NO. 10710, CPR, RVIR 
1 A. No, I'm single. 
2 Q. Are you currently employed? 
A. No, I am not. 
Q. Do you have any children? 
5 A. Not that I'm aware of, but who knows. 
6 Q. Is that a "yes" or "no"? 
7 A. Sorry, I was just kidding -- no, I do not 
8 have any children. 
9 Q. Were you at Hannigan Stadium on September 
10 10, YR-2? 
11 A. Yes, I was. 
12 Q. Why were you at the stadium that day? 
13 A. I was working my shift as a vendor. 
14 Q. What were you selling that day? 
15 A. Beers, specifically Old Fashion and Old 
16 Fashion Light, the official beer of the Cubs. 
17 Q. How long have you been working at 
1.8 Hannigan? 
19 A. Two years. 
20 Q. How did you come to be a beer vendor at 
21 Hannigan? 
22 A. Just lucky I guess, it's a nice job for 
23 someone who doesn't have a college degree. 
24 Q. Did you attend college at all? 
2.5 A. Yes. 
4 
Page. 2 
1 DEPOSITION OF BENJAMIN STONE 
2 BE IT REMEMBERED THAT, pursuant to notice, 
3 commencing at the hour of 12:15 p.m. thereof, at 
4 3200 E. Clymont Street, Nita City, Nil.a, 
5 before me, Balinda Dunlap, a Certified Shorthand 
6 Reporter, there personally appeared on Sept. 15, YR-1 
7 BENJAMIN STONE 
6 called for oral examination by counsel for 
9 Plaintiff, who, after having been duly sworn to 
10 tell the truth, the whole truth, and nothing but 
1t the truth, testified as follows: 
12 —000-
13 Q. Please state your full name, first and 
14 last. 
15 A. Benjamin Stone. 
16 Q. What is your current address? 
17 A. I live at 781 Fairmont in Nita City. 
18 Q. Do you live alone? 
19 A. No. I have two roommates. 
20 Q. Carl you identify those roommates? 
21 A. Yes. My friends Jeff Onyiego and Mike 
22 Conohan; we knew each other in college. 
23 Q. How old are you? 
24 A. I'm 26. 
25 Q. Are you married? 
Page •1 
1 Q. Where did you go to college,
2 A. I went to Nita State for two years but 
3 did not get my degree. 
4 Q. Why not? 
5 A. In my sophomore year, I was suspended for 
6 copying a paper from one of my fraternity brothers. 
7 Q. How long have you been living in 
8 Nita City? 
9 A. Since I got my first job here, waiting 
10 tables after leaving State. 
Q. How long has that been? 
12 A. Well, I left state five years ago. 
13 Q. Are you still employed by the Cubs? 
14 A. No. They fired me right after the events 
15 we're here to discuss. 
16 Q. How soon after the events did they fire 
17 you? 
18 A. It was at the end of the season, so not 
10 immediately after the fact, but I knew they were 
20 covering their tracks. 
21 Q. When did you begin selling beer on the day 
22 in question? 
23 A. Well, it was a 3:05 start, so I was 
24 selling beer right after the first pitch. 
25 Q. Do you sell beers before the game starts? 
1 (Page 1 to 4) 
83 
National Institute for Trial Advocacy

## Page 65

KEMPER V. NiTA Cm CUBS HOLDINGS, INC. 
P.Jcie 5 
1 A. No, we load up in the loading station and 
2 wait until the game starts. 
3 Q. What is the loading station? 
4 A. That's the area where they keep all the 
5 beers, sodas, ice creams in these massive 
6 refrigerators. We go back there to load coolers 
7 and then sell in the stands. 
8 Q. Where is that located? 
9 A. For my section, it's between the entrance 
10 for the home team's locker room and the training 
11 room, kind of this long corridor hidden from the 
12 fans. 
13 Q. How close is it to your section? 
14 A. I don't know, it's hard to say, I would 
15 say --
16 Q. 11 you had to estimate in yards, would you 
11 
J 8 A. Probably 20, 25 yards down the concourse. 
19 It's pretty close. 
20 Q. How often did you work as a Hannigan 
21 Stadium vendor over the last two years? 
22 A. Every home game for two seasons, almost. 
23 So it depended on the home game schedule. 
24 Q. In total, how many games did you work? 
25 A. Well just doing the math, there are 81 
Pair 7 
1 Q. What other training did you receive? 
2 A. That was it -- they really didn't do much. 
3 Q, What was the environment at Hannigan on 
4 the day in question? 
5 A. Everyone was having a pretty great time, 
6 beautiful day, but a late start so that's always 
7 trouble. 
8 Q. Why is that trouble? 
9 A. People drink before coming to the game --
10 usually around noon or so for a 3:00 p.m. start. 
11 Q. Where do they drink? 
12 A. Mostly around the stadium. There are many 
13 bars and restaurants for people to get loaded 
11 before coming to the game. 
15 Q. How was business that day? 
16 A. Great. It was a hot, sunny day so people 
17 were throwing back beers like water. 
18 Q. How many beers did you sell? 
19 A. I couldn't answer that. 
20 Q. Were you returning more or less frequently 
21 to your station? 
22 A. More frequently probably, but I don't 
23 know. 
24 Q. How were the patrons behaving that day? 
25 A. Rowdy, but that's not surprising. 
Page 
1 home games a year -- not including playoffs, but 
2 that goes without saying for these losers. 
3 Q. So over 100? 
A. Easily, probably more like 160, but I 
5 don't know the exact number. 
6 Q. What kind of training did you receive? 
7 A. Kind of, we had a manual. 
8 Q. What did the manual say? 
9 A. Basic stuff relating to the Cubs Way, 
10 respecting the organization, getting our receipts 
11 in properly. Things like that. 
12 Q. When did you receive the manual? 
13 A. We had an orientation process, but it was 
14 a total joke. When the training supervisor said we 
15 should feel free to fall asleep. 
16 Q. What happened during orientation? 
17 A. We talked us through the manual --
18 Q. I am sorry to interrupt, but who is "he"? 
19 A. My bad. "He" is referring to my boss at 
20 the time, Jim Stancil. He left after my first 
21 year. 
22 Q. And Mr. Stancil provided the training to 
23 you and your co-workers? 
A. Yes, he walked us through the manual, told 
25 us to read it, made some jokes and that was it. 
Page 8 
Q. Do you remember any incidents among the 
2 fans? 
3 A. Aside from the obvious --
4 Q. Yes, of course, arid we'll get to that 
5 shortly. But other than Mr. Kolleng, were there 
6 any incidents? 
7 A. A few scuffles, security stepped in, a few 
8 fans getting taken to the Shark Tank. 
9 Q. Can you explain the Shark Tank? 
1.0 A. It's just the name we all give the 
11 security office where they take some TMF fans. 
12 Q. Mr. Stone, can you avoid using acronyms 
13 just for the record because --
14 A. I'm sorry. TMF stands for Too Much Fun. 
15 Q. Did you personally report any of the 
16 individuals to security? 
17 A. I didn't need to -- they were all over the 
38 guys who were obviously drunk. 
19 Q. Did you make any comments to anyone 
20 regarding this behavior? 
A. I sent out a few tweets about the 
22 section I was working at that time. 
23 Q. How do you send tweets while working? 
24 A. Well, it's not difficult. It only takes a 
25 moment and you can send them as you're watching 
National Institute for Trial Advocacy 
2 (Pages 5 to 8) 
35

## Page 66

KEMPER V. Nir CITY CUES HOLDINGS, INC. 
Rity! 
1 something. I usually just Tweet out a joke or two, 
2 and it's a great way to self-promote. 
3 Q. For what are you self-promoting? 
4 A. I do stand-up comedy around the city and 
S people love my bits on Cubs fans. Even my old 
6 bosses loved the bits. 
7 Q. What was the nature of these jokes and 
8 chatters? 
9 A. Just commenting on how much fun people 
10 were having, and a Tweet with a picture of 
11 Mr. Kolleng. 
12 Q. Why did you send the Tweet out. of 
13 Kolleng? 
11 A. I didn't know him at the time. He was 
15 trying to start the wave, or shouting "Here we go, 
16 Cubbies." Just being the typical TMF fan. 
17 Q. How did you feel when you realized a fan 
18 had been hurt in the area? 
19 A. I felt terrible, I just didn't think it 
20 was anything unusual. People getting hurt based on 
21 drinking at Hannigan is nothing unusual. 
22 Q. How often did you see people getting hurt? 
23 A. Every once in a while, not every game, but 
24 it was obvious that people were drinking too much. 
25 Q. Did any members of the security personnel 
Paw I ► 
1 A. Not right away, but they fired me at the 
2 end of the season. 
3 Q. On the day in question, how did you 
4 perceive Mr. Kolleng? 
5 A. Like I said, he seemed like he was rowdy, 
6 enjoying the game, but I didn't think he was drunk. 
7 He certainly didn't seem dangerously drunk. 
8 Q. What do you look for in behavior before 
9 you stop serving someone alcohol? 
10 A. We're mainly looking for people who are 
11 either violent or just absolutely unable to stand 
12 up, falling -down drunk. They have to be obviously 
13 dangerous to themselves or other fans, not just 
14 acting funny or silly. We'd lock up half of 
15 Hannigan if that was the standard. 
16 Q. Did you get guidelines for determining 
17 whom to cut off? 
18 A. Sort of, but I mean, they left it up to 
19 us. They trusted us to use our best judgment. 
20 Q. Did you do that on the date in question? 
21 A. Look, I was trying to do my job -- make 
22 the fans happy. That's what the organization 
23 always told me to do. He never seemed dangerous. 
24 Q. How many beers did you serve him? 
25 A. There's no way I can remember that or keep 
Pane 10 
1 diSCUSS these problems with you arid the vendors? 
2 A. We had briefings regularly on increases in 
3 fights, or violence, and public intoxication 
4 arrests near the stadium. It just never seemed 
5 like they were serious. 
6 Q. What do you mean? 
7 A. The meetings we had always led to 
8 laughing, swapping stories about funny drunks, just 
9 everything was done with a wink and a nod. 
10 Q. What kind of actions did Security take 
11 whorl these reports came out? 
12 A. Every once in a while, someone would be 
13 suspended for a game or two. Generally, they would 
14 send an email to just cool it for the next home 
15 game. 
16 Q. Had you ever been suspended? 
17 A. Only once, and it was totally bogus --
1.8 some woman said that I had laughed when a drunk guy 
14 spilled beer all over her. 
20 Q. What happened after the game in question? 
21 A. Security, and specifically Lara, went 
22 completely off the rails and told us it would be 
23 "our hides" the next time something like this 
24 happened. 
25 0. Did you face any consequence-2 
ri.lcio 12 
1 track of it. The only way to keep track of who is 
2 drinking how much is by their behavior. 
3 Q. What behavior did Mr. Kolleng display? 
A. The same behavior of a lot of fans: He 
S was loud; he was being a goof; he was getting a lot 
6 of people looking at him. That was it. 
7 Q. Why would you not cut him off? 
8 A. Keeping the fans happy is the name of the 
9 game. You'd be surprised how easy it is to get 
10 fired over cutting someone off who is not drunk, 
11 and you don't get a medal for cutting someone off 
12 who might be hammered. 
13 Q. Where are you employed now? 
14 A. I'm working on my stand-up. Now that the 
15 Cubs let me go, I can really let them have it; and 
16 the people love hearing me absolutely rip the Cubs. 
17 Q. Do you have a full-time job other than 
18 stand-up? 
19 A. No, not at the moment. 
20 (Whereupon the proceedings were 
21 concluded.) 
22 ---000---
23 
24 
25 
National Institute Ion Trial Advocacy 
3 (Pages 9 to 12) 
37

## Page 67

KEMPER V. NITA Cm' CURS HOLDINGS, INC. 
Page 1.1 
1 DEPOSITION REPORTER'S CER1 I FICA]. E 
1 hereby certify that the witness in the 
3 foregoing deposition named, 
4 BENJAMIN STONE 
5 Was by me duly sworn to testify the truth, the whole 
6 truth, and nothing but the truth in the within-entitled 
7 cause; that said deposition was taken at the time and 
8 place therein stated; that the testimony of said 
9 witness was reported by me, Belinda Dunlap, a Certified 
10 Shorthand Reporter, a disinterested person, and was 
11 taken down by me in stenotype and transcribed through 
12 computer-aided transcription; and that the pertinent 
13 provisions of the applicable code or rules of civil 
14 procedure relating to the notification of the witness 
15 and counsel for the parties hereto of the availability 
16 of the original transcript of deposition for reading, 
17 correcting and signing have been complied with. 
1.8 And I further certify that I am not of counsel 
19 or attorney for either or any of the parties to said 
20 deposition, nor in any way interested in the outcome of 
21 the cause named in said caption. 
22 IN WITNESS WHEREOF, I have hereunto subscribed 
23 my hand this October 10, YR- . 
24 is/rialinda Dunlap 
25 Belinda Dunlap, CSR No. 10710, CRR, RMR 
Page 1,1 
1 DECLARATION OF WITNESS 
2 I, BENJAMIN STONE, hereby declare that I have read the 
3 foregoing testimony, and the same is true and correct. 
4 transcription of my said testimony except as I have 
5 corrected. 
6 
7 Benjapn111  Storir: 
Signature 
8 0 
10 
11 
12 
13 
14 
15 
16 
17 
19 
:)() 
21 
23 
24 
-5 
Novpint)pr 1
Date 
National hist i tine for Trial Advocacy 
4 (Pages 13 to 14) 
89

## Page 68

KEMPER v. NITA CITY Cuss HOLDINGS, INC. 
EXCERPTS FROM JESSICA KEMPER'S DEPOSITION 
Page 1 
1 
2 
3 
5 
6 
7 
8 
9 
IN hIE U.S. DISTRICT COURT 
DISTR1Cr OF NITA Cily, NITA 
CIVIL DIVISION 
JESSICA KEMPER 
Plaintiff, 
Vs. CAL: YR-3-CIV-10Z84 
NITA CITY CUBS IR/DING, INC. 
Delendant.i. 
10 
it 
12 
DEPOSITION OF' JESSICA KEMPER 
13 
1,1 
IS 
16 
17 
18 
19 
20 
21 
22 
23 REPORTER: BALINDA DUNLAP, CSR NO. 10710, CRR, RMR 
24 
1 
2 
5 
6 
7 
8 
9 
10 
11 
12. 
13 
14 
15 
16 
17 
18 
.19 
20 
21. 
22 
23 
25 
:; 
Junction at Berry College, and I studied abroad in 
France for a year, 
Q. When did you move back to Nita City? 
A. I don't know, pretty quickly. After 
graduation I started teaching and working on my 
certification. 
Q. 
A. 
A. 
A. 
A. He worked construction, mainly cement 
pouring. 
Q. Do you have any children? 
A. Yes, my husband Joe and I are lucky to 
have two kids. Jack is 10, and Rose is 7. 
Q. Where do you live with your husband and 
children? 
A. In Nita City. 
Q. I'm sorry, what is your exact address? 
A. We are at 6141 N. Hiawatha on the North 
Side. 
Q. How long have you lived at 6141? 
Are you married? 
Yes. I have been married 12 years. 
What is your spouse's name? 
Joseph. 
What does he do for a living? 
He is unemployed. 
What was- his most recent job? 
1 
2 
4 
5 
6 
7 
8 
9 
10 
11 
12 
13 
1-1 
15 
16 
17 
18 
19 
2.0 
21 
2 
2K 
Pane 2 
DEPOSITION OF JESSICA KEMPER 
BE IT REMEMBERED THAT, pursuant to notice, 
commencing at the hour or 10:00 a.m. thereof, at 
3200 E. Clymont, Nita City, Nita, before 
me, Balinda Dunlap, a Certified Shorthand Reporter, 
there personally appeared on October 15, YR-I 
JESSICA KEMPER 
called for oral examination by counsel for 
Plaintiff, who, after having been duly sworn to 
tell the truth, the whole truth, and nothing but 
the truth, testified as follows: 
—000—
Q. Please state your name for the record. 
A. Jessica Kemper, 
Q. What do you do for a living? 
A. I'm a school teacher in Nita City. 
Q. What subject do you teach? 
A. I teach high school English -- honors 
English for juniors and Advanced Placement for 
seniors. 
Q. How long have you lived in NITA City? 
A. I've lived in Nita City most of my life. 
Q. When did you live anywhere other than 
Nita City? 
A. Well, I went to college in Franklin 
Paw 4 
1 A. The last three years. 
2 Q. Were you at Hannigan Stadium on September 
3 10, YR-2? 
4 A. Yes, I was. 
5 Q. Why were you at the stadium that day? 
6 A. I was taking my kids to their very first 
7 Cubs' game. 
8 Q. Had you attended Cubs games before? 
9 A. Yeah, a few. 
10 Q. How did you get to the stadium from home? 
11 A. I drove to the train station, and parked 
12 our car there. We took the train to Shefford 
13 Station. 
14 Q. What time did you live at: the game? 
15 A. Early. The kids wanted to see batting 
16 practice. 
17 Q. Do you recall the time? 
18 A. We got there about 2:00 p.m. 
19 Q. What section were your seals? 
20 A. Our seats were in Section 101. 
21 Q. Did you purchase the tickets? 
22 A. No, a family friend gave them to us. 
23 Q, How did he acquire the tickets? 
24 A. He's a season ticket holder -- diehard 
25 Cubs fan, but he couldn't use the tickets that 
1 (Pages 1 lo 4) 
National Institutv for Trial Advocacy 91

## Page 69

KEMPER V, NITA Cm, CUBS HOLDINGS, INC. 
Page 5 
1 weekend. 
2 Q. Have you used the tickets before? 
3 A. My husband has, but I had never been in 
4 those seats. 
5 Q. Had you been to a Cubs game before 
6 September 10, YR-2? 
7 A. Many, many times. 
8 Q. Can you approximate how many times? 
9 A. No, I can't. 
10 Q. Would you say it's closer to 10 games? 50 
11 games? 100 games? 
12 A. If I had to guess, since I've grown up in 
13 Nita City, I'd say it's a few dozen, but I can't 
14 really ballpark it -- pun intended. 
15 Q. When was the most recent time before 
16 September 10 you'd been to a Cubs game? 
17 A. I went for a work outing earlier in that 
18 summer. 
19 Q. Where did you observe batting practice? 
20 A. We went to the area near the Cubs dugout. 
21 Q. Was that near your seats? 
22 A. No, but the security guards let us get 
23 close just for the kids to see the players up 
24 close. 
25 Q. When did you go to your seats? 
Page 7 
1 A. I was in a lot of pain, and I don't 
2 remember much after that. 
3 Q. Did you see who threw the object? 
4 A. No. But I had a decent guess who might 
5 have done it. 
6 Q. Who did you believe at the time you threw 
7 the object? 
8 A. The drunk gentleman sitting behind me and 
9 my kids making a fool of himself most of the game. 
10 Q. What happened right after the blow to your 
11 head? 
12 A. Well, I heard both my kids crying and Jack 
13 said, "Mommy, that mean man hit you." 
14 Q. What did you say? 
15 A. I mumbled something and felt the back of 
16 my head, and when I brought my hand forward there 
17 was blood. 
18 Q. What happened next? 
19 A. A security guard came over to me and 
20 helped me stand up. I was a bit dizzy so I needed 
21 the help. 
22 Q. What did the security guard say? 
23 A. Nothing, I don't really know -- I can't 
24 remember. 
25 Q. Did you see what happened to the man you 
1 
2 
3 
4 
5 
6 
7 
8 
9 
10 
11 
12 
13 
14 
15 
16 
17 
18 
19 
20 
21 
22 
23 
24 
25 
Page 6 
A. Before the first pitch. 
Q. The first pitch of the game? 
A. No. Before the ceremonial first pitch, 
you know, where they, um --
Q. Allow a guest to throw --
A. Yes, where some fan or random person 
throws the pitch, and then they have the anthem. 
Q, So you were in your seats well before the 
start? 
A. Yes. 
Q. What happened in between the sixth and 
seventh innings of the game on September 10? 
A. Some moron behind me hit me in the back of 
the head with a bat. 
Q. Where did he get the bat from? 
A. I have no idea; it was small. It could 
have been a souvenir. 
Q. Can you describe being hit? 
A. Yes. I was facing the fi eld and a hard 
object struck me -- I didn't know what it was at 
the time. 
Q. What happened when you were hit? 
A. I fell forward and whacked my shoulder 
against the chair in front of me. 
Q. Do you remember what happened next.? 
Page 8 
1 thought hit you? 
2 A. No. I wasn't paying attention to that 
3 idiot; I was trying to get my kids. 
4 Q. What happened next? 
5 A. I went to a holding cell, some kind of 
6 back office area where I got some first aid. 
7 Q. Who delivered the first aid? 
8 A. I can't remember -- I didn't get a name or 
9 anything. 
10 Q. What kind of first aid was administered? 
11 A. Just the basics; a bandage for my head, a 
12 cold compress for my shoulder. Nothing fancy. 
13 Q. Did you talk to any Cubs personnel? 
14 A. Yes, I spoke with the head of Security. I 
15 can't remember her name. 
16 Q. What did you discuss? 
17 A. The entire day, it felt like. She wanted 
18 every annoying detail and was writing it all down. 
19 I just wanted to go to the hospital. 
20 Q. What questions (lid she ask? 
21 A. She kept asking who had done it„ what he 
22 was acting like, if anyone around me seemed 
23 suspicious -- more of a detective than a medical 
21 technician, which is what I needed. 
25 Q. What else did you discuss? 
National Institute for Trial Advocacy 
2 (Pages 5 to 8) 
93

## Page 70

KEMPER v. NITA CITY Cuss HOLDINGS, INC. 
Page 9 
1 A. I gave her a piece of my mind about the 
2 drunks at the ballpark. 
3 Q. What did you say? 
4 A. I told her the whole stadium was drunk all 
5 the time, that they were just begging for a 
6 lawsuit, and that I was going to take them to the 
7 cleaners. 
8 Q. What do you mean the whole stadium was 
9 drunk? 
10 A. It'd been a problem at Hannigan for years 
11 now -- too many people drinking too much, too 
12 quickly. 
13 Q. What made you think the whole stadium was 
14 drunk? 
15 A. You can just tell. I have been around 
16 long enough. Even the man sitting next to me said 
17 this was a classic Hannigan mishap. 
18 Q. How could you tell the man was drunk? 
19 A. lie was loud. He was being obnoxious. He 
20 was yelling the whole game, even though the Cubs 
21 were getting killed. 
22 Q. Where was he seated? 
23 A. I am not completely sure, maybe five or 
24 six rows behind me. 
25 Q. Did you say anything to him? 
Page 11 
1 A. Yes, but I still didn't press charges. 
2 Q. Why go to the police at all? 
3 A. I wanted to see if he had been punished, 
4 or if the Cubs had done anything to handle things. 
5 Q. What happened when you went to the police? 
6 A. I went down to the local precinct near 
7 Hannigan. I spoke with an officer there and gave 
8 him the description of what happened. I asked if 
9 they had any complaints from Hannigan or any 
10 arrests of someone matching Kolleng's description. 
11 They said no. 
12 Q. How did you respond? 
13 A. I was upset, really angry, but then the 
14 officer said he brought the guy in that night and 
15 he slept in the drunk tank. That made me feel 
16 better. I didn't want the guy getting the electric 
17 chair, but I wanted him to feel some punishment. 
18 It wouldn't be right. 
19 Q. Going back to the interview with Kotkin, 
20 did you say anything else? 
21 A. I told them I'd never come to another Cubs 
2.2 game. 
2.3 Q. What was the Security Director's reaction? 
24 A. She was apologetic, but didn't seem to 
25 really care -- it's not like Hannigan is hurting 
Page 10 
1 A. I didn't, but the man next to me told him 
2 to cool it on the beers. 
3 Q. When you were in the office space, was the 
4 man with you? 
5 A. He was there, just sitting really quietly. 
6 He didn't say anything to me, besides that he was 
7 really sorry. 
8 Q. Did the Cubs ask him any questions? 
9 A. They didn't let me stay for that part of 
10 the interview. 
11 Q. Where was he in the room relative to you? 
12 A. He was in the corner, not saying anything, 
13 just looking at his shoes. 
14 Q. Did he say anything at all? 
15 A. Not to me during the interview. He 
16 apologized when I left, but it didn't seem sincere. 
17 Q. What other questions did the security 
18 personnel ask you? 
19 A. If I wanted to press charges, if I thought 
20 the police should be called, I can't remember -- a 
21 few other questions. 
22 Q. What did you say? 
23 A. I didn't want to press charges. 
24 Q. Did you speak to the police later that 
25 week? 
Page 12 
1 for attendance. 
2 Q. How long did the interview last? 
3 A. It felt like forever, I don't know. 
4 Q. Would you say more than 10 minutes? 
5 A. Definitely, much longer. 
6 Q. Would you say more than 20 minutes? 
7 A. I don't know, something like that. 
8 Q. Did you hear anything from the Cubs prior 
9 to this suit? 
10 A. Nope. The woman I met with said -- and 
11 I'll never forget this — "We're so sorry for this 
12 inconvenience. We feel awful" 
13 Q. Hour did the interview end? 
14 A. An ambulance came, and the paramedics came 
15 into the office with a stretcher. 
16 Q. Did you get on the stretcher? 
17 A. No, I walked off on my own. I just wanted 
18 to leave with my kids. 
19 Q. Where did you go from the office? 
20 A. The EMTs took me in the ambulance to 
21 Southeastern Medical. I needed stitches, an MR1, 
22 plus all the damage to my collar bone -- even they 
2.3 weren't surprised. 
%).4 Q. Who weren't surprised? 
25 A. The EMTs. 
National Institute for Trial Advocacy 
3 (Pages 9 to 12) 
95

## Page 71

KEMPER V. NITA OTY OAS HOLDINGS, INC. 
Page 13 
1 Q. What makes you say that? 
2 A. One turn to the other and laughed and 
3 said, "Just another day at the ballpark." 
4 Q. Where were your children at this point? 
5 A. They stayed with me the whole time. 
6 Q. What impact have these injuries had on 
7 your life since that day? 
8 A. It's been a huge pain, but I am lucky. 
9 The doctor said that it could have been much worse. 
10 Q. How did it impact you immediately after 
11 the incident? 
12 A. Well, thank God I have great insurance 
13 through the teachers's union, because the bills 
14 were substantial. Between the ambulance, stitches, 
15 the MRI, the broken collarbone -- it was 
16 outrageous, over $50,000! 
17 Q. Did you miss work? 
18 A. No, I was able to go to work on Monday. 
19 My colleagues were all incredibly supportive. 
20 Q. Have you had any contact with the Cubs 
21 since that day? 
22 A. No. 
23 Q. How did your recovery go? 
24 A. It was fine. The stitches came out the 
25 week after they went in. My shoulder still bothers 
1 
2 
3 
4 
5 
6 
7 
8 
9 
10 
11 
12 
13 
14 
15 
16 
17 
18 
19 
20 
21 
22 
23 
24 
25 
Page 15 
believed hit you, ever contact you? 
A. No, I've never heard from him. 
(Whereupon the proceedings were 
concluded.) 
---000---
1 
2 
3 
4 
5 
6 
7 
8 
9 
10 
11 
12 
13 
14 
15 
16 
17 
18 
19 
20 
21 
22 
23 
24 
25 
Page 14 
me, but nothing serious. 
Q. Have you attended a Cubs game since? 
A. Absolutely not. 
Q. Have your family members? 
A. My husband has been to a game, but I won't 
let my kids go there anymore. The bottom line is 
that with so many drunks at Hannigan, it's just not 
safe. 
Q. Has anyone from the Cubs contacted you 
since the incident? 
A. Yes. The security officer, Kotkin, called 
me at home later in the week. 
Q. What did you discuss? 
A. She was trying to butter me up saying: 
"The organization was so sorry about the incident," 
let her know if she could do anything. 
Q. How did you respond? 
A. I told her she was going to hear from my 
lawyer, but I didn't think there was anything else 
she could do for me. 
Q. Did the man who was in the office with you 
ever contact you? 
A. The man who hit --
Q. Yes. The man who hit you with the bat, my 
apologies. Did the man in the office, the one you 
Page 16 
1 DEPOSITION REPORTER'S CERTIFICATE 
2 I hereby certify that the witness in the 
3 foregoing deposition named, 
JESSICA KEMPER 
5 Was by me duly sworn to testify the truth, the whole 
6 truth, and nothing but the truth in the within-entitled 
7 cause; that said deposition was taken at the time and 
8 place therein stated; that the testimony of said 
9 witness was reported by me, Balinda Dunlap, a Certified 
11) Shorthand Reporter, a disinterested person, and was 
11. taken down by me in stenotype and transcribed through 
12 computer-aided transcription; and that the pertinent 
13 provisions of the applicable code or rules of civil 
14 procedure relating to the notification of the witness 
15 and counsel for the parties hereto of the availability 
16 of the original transcript of deposition for reading, 
17 correcting and signing have been complied with. 
18 And I further certify that I am not of counsel 
19 or attorney for either or any of the parties to said 
20 deposition, nor in any way interested in the outcome of 
21 the cause named in said caption. 
22 IN WITNESS WHEREOF, I have hereunto subscribed 
23 my hand this November 10, Y12-__. 
24 /; t;.,? iecia caetilo 
25 Balinda Dunlap, CSR No. 10710, CRR, RMR 
National Institute for Trial Advocacy 
4 (Pages 13 to 16) 
97

## Page 72

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Page 17 
1 DECLARATION OF WITNESS 
2 I, JESSICA KEMPER, hereby declare that I have read the 
3 foregoing testimony, and the same is true and correct 
4 transcription of my said testimony except as I have 
5 corrected. 
6 
7 Jessica Kemper 
8 
Signature 
9 December 1, YR- 1 
10 
Date 
11 
12 
13 
14 
15 
16 
17 
18 
19 
20 
21 
22 
23 
24 
25 
5 (Page 17) 
National Institute for Trial Advocacy 99

## Page 73

KEMPER V. NITA CM' CUBS HOLDINGS, INC. 
EXCERPTS FROM LARA KOTKIN'S DEPOSITION 
1 
2 
3 
4 
Page 1 
IN THE U.S. DISTRICT COURT 
DISTRICT OF NITA City, NITA 
CIVIL DIVISION 
5 
6 JESSICA KEMPER 
7 Plaintiff, 
8 Vs. CAL: YR-3-CIV-10784 
9 NITA CITY CUBS HOLDING, INC. 
10 Defendants. 
11 
12 
13 
14 
15 
16 
17 
18 
19 
20 
21 
22 
23 
24 
25 
 I 
DEPOSITION OF LARA KOTKIN 
REPORTER: BALINDA DUNLAP, CSR NO. 10710, CRR, RMR 
1 
2 
3 
4 
5 
6 
7 
8 
9 
10 
11 
12 
13 
14 
15 
16 
17 
18 
19 
20 
21 
22 
23 
21 
25 
Page 3 
13 years, but I have only been at Hannigan Stadium 
for 3. 
Q. How old are you? 
A. I'm 37. 
Q. Did you attend college? 
A. Yes, I went to Dartford College. 
Q, What degrees did you pursue at Dartford? 
A. I got my bachelor's degree in economics at 
Dartford. 
Q. 
A. 
Q. 
A. 
30. 
Q. 
and starting school? 
A. I worked a series of odd jobs right out of 
school. I was a waitress at a bar near Hannigan 
Stadium actually, a place called Sully's. Then I 
got a position in the ticket office with the Cubs. 
Q. When did you start with the Cubs? 
A. Thirteen years ago. 
Q. Were you working at Hannigan Stadium on 
September 10, YR-2? 
A. Yes, I was. 
Do you have any advanced degrees? 
I have my MBA from Wilbur University. 
When did you get your MBA? 
I went to business school when I turned 
What did you do between graduating college 
Page 2 
1 DEPOSITION OF LARA KOTKIN 
2 BE IT REMEMBERED THAT, pursuant to notice, 
3 commencing at the hour of 12:15 p.m. thereof, at 28 
4 N. Moragane, Nita City, Nita, before me, 
5 Balinda Dunlap, a Certified Shorthand Reporter, 
6 there personally appeared on October 1, YR-1 
7 LARA KOTKIN 
8 called for oral examination by counsel for 
9 Plaintiff, who, after having been duly sworn to 
10 tell the truth, the whole truth, and nothing but 
11 the truth, testified as follows: 
12 ---o0o---
13 Q. What Is your name ma'am? 
14 A. Lara Kotkin. 
15 Q. Can you tell us your address? 
16 A. My primary residence is at 18 N. Michigan 
17 here in Nita City. 
18 Q. What city do you live in? 
19 A. Like I said, Nita City. 
20 Q. What is your current occupation? 
21 A. I am the Director of Security at Hannigan 
22 Stadium. 
23 Q. How long have you been working at Hannigan 
24 Stadium? 
25 A. Well, I've been with the Cubs for the past 
Page 4 
1 Q. Why were you at the stadium that day? 
2 A. As head of Security, I'm at every home 
3 game. Even on off days, I'm at the stadium because 
4 that's where my office is located. 
5 Q. How did you learn of the incidents in 
6 question on that day? 
7 A. I was in my office, just sitting back and 
8 watching the game. It was quieter than usual for a 
9 summer 3:05 start like this. 
10 Q. What is the usual environment for a game 
11 like that? 
12 A. 3:05 game times are later, which means 
13 fans have more time to enjoy the bars and taverns 
11 near the stadium. They're worse than night games 
15 even. 
16 Q. What do you mean by "worse"? 
17 A. Just that people drink more. Saturday 
18 mornings the bars around the stadium open -- it's 
19 crazy. I've begged the local restaurants not to 
20 open until afternoon, but they never listen to me. 
21 Q. Why do they open early? 
22 A. The all-mighty dollar, I suppose. They 
23 make a lot of money on game day. 
24 Q. How many 3:05 games are there per season 
25 A. Not many, maybe a handful. They're 
National Institute for Trial Advocacy 
1 (Pages 1 to 4) 
101

## Page 74

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Page 5 
1 usually for nationally televised games, and the 
2 Cubs have been awful this year. The networks don't 
3 want anything to do with us. 
4 Q. Where is your office located in the 
5 stadium? 
6 A. It's right near the batter's eye in center 
7 field. It's kind of behind the main concourse by 
8 the bleacher section. 
9 Q. Is there a reason your office is behind 
10 the stadium? 
11 A. Not really, it was just an office 
12 available. The main work my department performs is 
13 out in the stands. 
14 Q. Can you describe that work? 
15 A. Do you mean my work or do you --
16 Q. Just describe the general work of the 
17 security department. 
18 A. Sure, well, we are in charge of, on 
19 average, 32,000 Cubs fans every game. It is our 
2.0 job to ensure that fans are enjoying games 
21 satisfactorily, respectfully, and in a way that 
22 doesn't impair any other fan's ability to enjoy the 
23 game. 
24 Q. How many security guards are there at 
25 Hannigan? 
Page 7 
1 A. I spent most of the game in the stadium, 
2 checking on my people and making sure things were 
3 all right. We were playing the Sharks, big 
4 rivalry, so we needed to be cautious. 
5 Q. What training do you give your personnel 
6 to handle emergencies? 
7 A. Different departments get different 
8 training, so do you mean my security personnel or 
9 the entire staff? 
10 Q. Let's start with your personnel. 
11 A. It's a fairly rigorous training program 
12 for Security personnel. We make sure that each new 
13 security guard follows a more experienced guard for 
14 an entire week before starting on their own. We 
15 also teach them communication techniques, CPR and 
16 other emergency first aid measures, and 
17 self-defense to ensure they aren't harmed in case 
18 of a fight. 
19 Q. Are there physical qualifications for the 
20 position? 
21 A. No, not really. Anyone can apply, we have 
22 Men, women, small people, big people. They're not 
23 bouncers. 
24 Q. What training do you provide other 
25 Hannigan staffers? 
Page 6 
1 A. It depends on the game. 
2 Q. How many at the game in question? 
3 A. There were 42 security guards on duty that 
4 day. 
5 Q. How many are at a night game? 
6 A. It's usually more like 60 for night games. 
7 That includes security personnel outside the 
8 stadium after the game. 
9 Q. And for a normal day game? 
10 A. Do you mean a 12:05 or 1:15 start? 
11 Q. For a day game that starts at either time, 
12 how many security guards are present? 
13 A. Forty-two, same as a later afternoon game. 
14 Q. How do you supervise your security 
15 personnel? 
16 A. I usually walk the concourses, make sure 
17 that is everyone has the tools they need to 
18 intervene in case of an emergency. I am always 
19 reachable by two-way radio, just a handheld 
20 walkie-talkie. 
21 Q. Do you spend more time in your office or 
22 on the concourse? 
23 A. It depends, and it varies game to game. 
24 Q. On the day in question, were you out more 
25 or in your office more? 
1 
2 
3 
4 
6 
7 
8 
9 
10 
11 
12 
13 
14 
15 
16 
17 
18 
19 
2.0 
2.1 
22 
23 
24 
25 
Page 8 
A. We give them basically the "Reader's 
Digest" version of security training. 
Q. What do you teach them? 
A. Just the basics, and most importantly, how 
to get the attention of an actual security guard. 
Q. What are the basics? 
A. Spotting inappropriate behavior, when to 
intervene, how to recognize an intoxicated fan. 
Q. How often do you train non-security 
personnel on these matters? 
A. We train all the new hires at the 
beginning of the season, and then there is a 
separate refresher course for veteran personnel. 
That happens at the start of the season as well. 
Plus, my door is always open for questions. 
Q. How did you manage to become the head of 
security? 
A. Hard work and doing the right thing. 
Q. Certainly, but I meant chronologically and 
from the ticket --
A. How did I get from A to B? 
Q. Exactly. How long did you work in the 
ticket: office? 
A. Not long. I was only there for half of 
the season. I said to my boss at the time, Arnold 
National Institute for Trial Advocacy 
2 (Pages 5 to 8) 
103

## Page 75

KEMPER V. NITA CITY CUBS HOLDINGS, INC. 
Page 9 
1 Darschner, "I am too talented to be doing this. 
2 know you can use me elsewhere." 
3 Q. What happened then? 
4 A. Arnold told me he thought I was going to 
5 be a real asset to the club and transferred me to 
6 marketing. 
7 Q. How long did you stay in marketing? 
8 A. I worked for the marketing department for 
9 several years. I was really most interested in the 
10 business aspects of the game. 
11 Q. What was your next position? 
12 A. Right after joining the marketing 
13 department, I decided I wanted to go back to 
14 business school, but it helps to have experience. 
15 I got a position as an assistant vice president in 
16 the department when I was 28. 
17 Q. Did you stay there until school? 
18 A. Yes. And the Cubs were great. There's a 
19 scholarship for the best and brightest, and they 
20 paid for me to get my MBA. 
21 Q. Did you return to the Cubs after 
22 graduating? 
23 A. Yes. Part of the deal is that you have to 
24 come back to the Cubs once you graduate. They 
25 don't want people taking their degrees after the 
Page /1 
1 A. He told me he was administering first aid 
2 to the victim, and asked what he should do. 
3 Q. What was your response? 
4 A. I told Danny safety first, make sure the 
5 victim was all right. 
6 Q. When did the victim come into your office? 
7 A. Well, actually another security guard 
8 brought in Mr. Kolleng first, he was being led by 
9 the neck, almost in a headlock. 
10 Q. What happened when he came in? 
11 A. We spoke about what happened, and I took 
12 his statement for our records. 
13 Q. Why do you keep records? 
14 A. Well, when I took over at Security, 
15 wanted to make sure we had better data to monitor 
16 how our policies were working, when we had spikes 
17 in violence, drunken behavior, things like that. 
18 Q. How long have you been compiling this 
19 data? 
20 A. The last two years or so. 
21 Q. What, if anything, has it revealed? 
22 A. I think we're doing our jobs. Fans are 
23 having fun, violent incidents haven't spiked and 
24 have remained steady, drunken fans aren't causing 
25 major problems. I'm happy with it. 
Page 10 
1 scholarship and using it to benefit someone else. 
2 Q. What role did you play after school? 
3 A. I went right back to the marketing 
4 department, but then something opened up in 
5 security. 
6 Q. What attracted you to the security 
7 position? 
8 A. The money and the promotion. I had no 
9 experience, but I knew the right people. 
10 Q. When did you get the position? 
11 A. About three years ago, They were 
12 interviewing lower -level Security personnel, former 
13 police officers, a few candidates who ran Security 
14 at other teams. They saw potential in me and gave 
15 me the job. 
16 Q. Returning to the clay in question, when did 
17 you hear about the incident? 
18 A. I received a call over the radio that my 
19 office was about to get a TMF. That's shorthand 
20 for "too much fun" fan. 
21 Q. What happened 
22 A. I told the security personnel on the 
23 scene, Danny Boyle, to bring the suspect to my 
24 office. 
75 Q. What did he !jay in response? 
1 
2 
3 
4 
S 
6 
7 
8 
9 
10 
11 
12 
13 
14 
15 
16 
17 
10 
10 
20 
21 
22 
23 
24 
25 
Page 12 
Q. l-bov; do you compile the data? 
A. I code every incident that gets reported 
to my office. I have different codes for violence: 
Accidental injuries; drunken behavior called "O and 
D"; verbal altercations with staff; just a 
slip-and-fall. The important thing for me is to 
have as much information as we can have. 
Q. Do you relay this information to your 
staff? 
A. I keep them updated if there is too high a 
spike or I notice trends I'm not happy about. And 
I usually send an email about the monthly summary. 
Q. What is the monthly summary? 
A. Basically, each month, I compile the data 
and send it out to the staff to let them know how 
we're doing. 
I give them a detailed list of every major 
incident and the coding so they can see trends and 
improve their own performance. 
Q. why do you send it to everyone and no; 
just security? 
A. We're all a team. Security is the 
enforcement mechanism, but I want my people to know 
that they can prevent problems before we have to 
ever step in to fix them. 
3 (Pages 9 to 12) 
National Institute for Trial Advocacy 105

## Page 76

KEMPER v. NITA ON CUBS HOLDINGS, INC. 
Page 13 
1 Q. The report you took from Mr. Kolleng, did 
2 that become part of your data? 
3 A. Yes. I coded it as an accidental injury 
4 based on the information I took from him and the 
5 security guard, as well as the victim. 
6 Q. What did he tell you occurred? 
7 A. lie said the bat slipped from his hand and 
8 that he was very sorry it happened. I told him we 
9 understood, and he should let us take it from 
10 there. 
11 Q. How did he explain the slip? 
12 A. He said the bat got slippery. He was 
13 waving it around to get the other fans pumped, and 
14 it just slipped. 
15 He kept saying he'd pay for the victim's 
16 hospital bills. He was crying briefly. He was 
17 being a bit melodramatic, in my opinion. The man 
18 was just genuinely sorry. 
19 Q. What happened when the victim arrived? 
20 A. She was genuinely distraught, even angry. 
21 Her children were with her, and they were both 
22 sobbing. Danny looked at me like he'd seen a 
23 ghost lie had blood on his hands and shirt. It 
24 was a nightmare. 
25 Q. What happened when she arrived? 
Page 15 
1 than five minutes, but she was so furious. I had 
2 to ask her to calm down. She was already throwing 
3 around the word "lawsuit," which didn't surprise 
4 me. 
5 Q. How often does the stadium get sued? 
6 A. Every so often. You get these fans who 
7 think that anything that happens to them is our 
8 fault, but sometimes mistakes happen. We do 
9 everything we can. 
10 Q. How often do drunk fans cause problems? 
11 A. Incidents are down since I joined, but 
12 look, we're in the entertainment business. People 
13 come to the ballpark to have a good time, and it's 
14 not our job to be babysitting. 
15 Q. What do you do to prevent drunkenness, if 
16 anything? 
17 A. We card people vigorously. I make sure of 
18 that. We have a good staff that keeps an eye out 
19 for certain tell -tale signs of bad behavior or 
20 drunkenness. 
21 There's not much else I think we can do to 
22 make this place safer, short of calling in the 
23 National Guard or something. 
2.4 Q. What plans, if any, do you have to change 
25 the stadium protocol? 
Page 14 
1 A. I had Mr. Kolleng sit over in the corner, 
2 and I told him not to say anything and to pretend 
3 like Ms. Kemper wasn't even there. 
4 Q. What questions did you ask her? 
5 A. I just went through the motions to get her 
6 statement. Really, I wanted to see how she felt 
7 about calling the police. Obviously, we try to 
8 avoid that when we can. 
9 Q. What: did she say about the incident? 
10 A. Well, she came in screaming at first and 
11 said, "Hope you had a good time, buddy! Hope those 
12 beers were worth it!" I asked her to speak only to 
13 me, and we'd get her to the hospital as quickly as 
14 possible. 
15 Q. Why did you not send her to they hospital 
15 fust? 
17 A. She was fine, really. There was nothing 
18 that led me to believe that she couldn't answer a 
19 few questions before leaving. 
20 Q. What: did you Fist(' 
21 A. Standard questions: Her name, the 
22 section, what happened, if she wanted to press 
23 charges. It's all there in the reports I wrote. 
24 Q. When did she leave? 
25 A. The questioning couldn't have lasted more 
Page 16 
1 A. Nothing, we're doing our jobs. 
2 (Whereupon the proceedings were 
3 concluded.) 
4 ---00o---
5 
6 
7 
8 
9 
10 
11 
12 
13 
14 
15 
16 
17 
18 
19 
20 
21 
22 
23 
25 
4 (Pages 13 to 16) 
National Institute for Trial Advocacy i0

## Page 77

KEMPER V. NITA CITY CUBS HOLDINGS, 
Page 17 
1 DEPOSITION REPORTER'S CERTIFICATE 
2 I hereby certify that the witness in the 
3 foregoing deposition named, 
4 LARA KOTKIN 
5 Was by me duly sworn to testify the truth, the whole 
6 truth, and nothing but the truth in the within-entitled 
7 cause; that said deposition was taken at the time and 
8 place therein stated; that the testimony of said 
9 witness was reported by me, Balinda Dunlap, a Certified 
10 Shorthand Reporter, a disinterested person, and was 
11 taken down by me in stenotype and transcribed through 
12 computer-aided transcription; and that the pertinent 
13 provisions of the applicable code or rules of civil 
14 procedure relating to the notification of the witness 
15 and counsel for the parties hereto of the availability 
16 of the original transcript of deposition for reading, 
17 correcting and signing have been complied with. 
18 And I further certify that I am not of counsel 
19 or attorney for either or any of the parties to said 
20 deposition, nor in any way interested in the outcome of 
21 the cause named in said caption. 
22 IN WITNESS WHEREOF, I have hereunto subscribed 
23 my hand this October 10, YR- . 
24 /o/lialinda Dunlap 
25 Balinda Dunlap, CSR No. 10710, CRR, RMR 
Page 18 
1 DECLARATION OF WITNESS 
2 I, LARA KOTKIN, hereby declare that I have read the 
3 foregoing testimony, and the same is true and correct 
4 transcription of my said testimony except as I have 
5 corrected. 
6 
7 Lara Kotkin 
8 
Signature 
9 November 6, YR-1 
10 
Date 
11 
12 
13 
14 
15 
16 
17 
18 
19 
20 
21 
22 
23 
24 
25 
5 (Pages 17 to 18) 
National Institute for Trial Advocacy 109

## Page 79

KEMPER V. NITA OTY CUBS HOLDINGS, INC. 
Appendix A 
OCAL RULES FOR MOCK IALS 
AND PRETRIAL CONFERENCES 
MOCK TRIAL 
1. Trial Realism 
The trial should be conducted as realistically as possible. 
Each participant—judge, lawyer, witness—should stay in "role." For example, do not stop the trial for 
critique; no objections on the ground that it is not in the script; if you get mixed up or lose your place, 
stay in character as if you were in front of a real jury; regroup and continue. 
2. Trial Materials 
The factual basis for the trial is the case file, which is available to all persons participating in the trial. 
If a witness testifies inconsistent with the materials in the case file, the witness may be impeached. For the 
purpose of impeachment at trial, it is assumed that the statement or deposition was given by the witness, 
and was read and signed by the witness. 
The objection that "it's not in the script or case file" will not be permitted. 
3. Pretrial Order 
A pretrial order summarizing the results of the pretrial conference shall be given to the trial judge the 
morning of the trial. The pretrial order shall be signed by counsel for both sides and cover the following: 
a) Issues to be determined at trial 
b) Admissions and stipulations 
c) Witness list 
d) Exhibit list 
e) Stipulations regarding exhibits 
f) Motions in limine 
g) Proposed jury instructions 
h) Any further matters 
4. Motions 
Procedural motions at trial are discouraged. If a parry wishes to make a motion in limine relating to the 
evidence, it should be raised and heard at the pretrial conference (PTC). No more than two motions per 
party are permitted. 
National Institute for Trial Advocacy 113

## Page 80

CASE FILE 
5. Documents, Charts, Exhibits 
All documents, charts, and exhibits of any kind that will be used at trial must be marked for identifica-
tion. Plaintiffs use 1, 2, 3, etc. Defendants use A, B, C, etc. This should be done before the PTC. 
A document should not be marked for identification by both parties. If both parties wish to use a 
particular document, it should be marked as one party's exhibit and then it is available for use at trial by 
any party. 
6. Stipulations 
All stipulations should be reached between counsel before the PTC if at all possible. Any stipulations 
reached after the PTC should be put in writing, signed by counsel for both parties, and appended to the 
pretrial order. 
7. Time Limits 
Opening statement—ten minutes per side, maximum 
Plaintiff case in chief (including cross-examination)—seventy-five minutes 
Defense case in chief (including cross-examination)----seventy-five minutes 
Argument—twenty minutes per side; plaintiff can reserve five minutes for rebuttal 
It is important that the trial proceed within the time guidelines so that time is available for critique. 
8. Jury Selection 
The jury will be seated prior to the start of trial. No voir dire will take place. 
Counsel might note those jurors that they may have challenged and then after the verdict compare their 
evaluation with the juror's actual vote. 
9. Counsels' Division of Responsibility 
Counsel may divide the opening statements, summations, and witness examinations in any way they 
wish. However, it shall be an even division of labor. Only one counsel per witness examination is 
permitted. See rule 12, below. 
10. Objections 
Objections and motions should be made and determined realistically. Side-bar conferences should be 
kept to a minimum. 
No objections may be made that "those facts are not within the materials." If you believe that the witness 
has gone outside the trial materials, then impeach the witness on cross-examination by using his statement 
or deposition. 
11. Adverse Witnesses 
Adverse witnesses may be called. However, each parry may call only one adverse witness and subject to 
time limits of ten minutes for adverse examination and five minutes for cross-examination. The cross-
examination is limited to the scope of the adverse examination. Any matters covered during the adverse 
examination may not be covered again during the case in chief, unless within the court's discretion and 
the interests of justice so require, the court allows such. 
1 1 4 National Institute for Trial Advocacy

## Page 81

KEMPER V. NITA CITY Cuss HOLDINGS, INC. 
12. One Counsel to a Witness 
Only one lawyer may make objections or participate in the examination of any given witness. The 
trial partner may not ask questions or make objections during that examination, but should always be 
unobtrusively aiding her partner as part and parcel of a team. 
13. No Exclusion of Witnesses 
A motion to exclude witnesses may be made as a matter of form for the experience of doing it. Such 
motion can be made orally, and must be made before examination of witnesses commences. However, 
witnesses shall not be excluded at the trial. 
14. Jury Instructions 
Proposed jury instructions are limited to those provided. No additional instructions will be permitted 
unless authorized by the pretrial judge. 
15. Critique 
When the jury retires to deliberate, the judge will critique counsel's performance. 
16. Comments by the Jury 
After the verdict is returned, the jury the judge should poll the jury. Thereafter, the judge will thank and 
excuse the jury. The court will then invite jurors to comment on the case and counsel's performance. Each 
juror will have the opportunity to express his comments. 
Counsel permitted to talk with the jury regarding the deliberations and counsel's performance during 
the trial. This is an excellent opportunity for a learning experience. Counsel should use it to discover 
the jury's perceptions of the case and counsel's performance, not to quibble with the jury regarding the 
verdict. The verdict itself, who won or lost, is not important as it is a simulated trial. What is important 
in the learning process is how the jury perceived the case. What the jury thought was significant is the 
key element for discussion. 
Counsel cannot impeach the jury verdict or win this case on appeal, but they can learn why the jury did 
what they did. Counsel should use the time well, as it will pay many dividends. 
17. Evidence 
The students have learned the Federal Rules of Evidence (FRE). Many of the visiting judges preside 
using their own state evidence code. For that reason, please state the objection itself and not just the 
rule number. Have available the FRE and the state evidence code section—e.g., "Your Honor, I object 
on the ground that the question is leading" (FRE 611(c), EC 767(a)), as opposed to, "I object under 
FRE 611(c)." 
PRETRIAL CONFERENCE 
A pretrial conference (PTC) will be held with your instructor or trial judge in the week or days before 
each trial. The following is an agenda for the PTC. The indicated items must be prepared before the 
conference to ensure that the conference proceeds smoothly and within the time schedule. Counsel shall 
prepare a joint proposed pretrial order and include these items for each side. 
National Institute for Trial Advocacy 115

## Page 82

CASE FILE 
1. Meet and Confer 
All counsel are to meet and confer prior to the PTC. This meet-and-confer should occur no later than 
one day prior to the PTC. Counsel shall exchange any necessary papers and serve the papers on the pre-
siding PTC judge (email service is acceptable). Any agreements or stipulations should be worked out at 
this time. 
2. Issues 
The issues to be resolved at trial should be listed. A short statement of your client's claim(s) or defense(s) 
should be included. 
3. Admissions in the Pleadings 
Any admissions in the pleadings should be set forth with a citation to the paragraph and page number. 
Any disputes as to whether an admission has been made should be raised and resolved at the PTC. 
4. Stipulations 
Any stipulations of facts or other stipulations relating to any aspect of the case (except exhibits) should be 
raised at this point in the PTC. 
Any stipulations not resolved in the meet-and-confer session should be brought to the attention of the 
judge for possible action by the court. 
5. Witness List 
Each side shall prepare a list of their witnesses in the order they will be called at trial. Only the witnesses 
listed in the trial materials will be permitted. 
6. List of Exhibits 
Each side shall prepare before the PTC a list of all documents, charts, and exhibits of any kind that will be 
used at the trial. All exhibits must be marked for identification: plaintiffs use 1, 2, 3, etc., and defendants 
use A, B, C, etc. 
The list of exhibits and marking for identification should include any documents used for impeachment, 
as the record should reflect any documents that may be used during the trial even though it is not intro-
duced or received in evidence. 
A suggested format for the list of exhibits follows: 
Plaintiff's List of Exhibits 
No. Title 
1 Life Insurance Policy 
2 Letter from John Smith to Assure Insurance 
3 Deposition of William Jones 
4 Statement by Robert Hall 
7. Stipulations Regarding Exhibits 
There are two basic stipulations pertaining to exhibits: admissibility and authenticity. 
Stipulation 
Authentic 
Authentic 
Authentic 
1 1 6 National Institute for Trial Advocacy

## Page 83

KEMPER V. NITA Cm' CUBS HOIDINGS, 
A stipulation to the admissibility of an exhibit means that it will automatically be received into evidence 
when it is offered at trial. The exhibit must be formally offered, on the record, at the trial unless the 
judge at the PTC has specifically ordered that it be received in evidence at that time. Note that it is often 
best not to stipulate, so that counsel may ask questions of the witness in front of the jury regarding the 
foundation 
A stipulation to the authenticity of an exhibit means that the document is authentic. At trial, counsel 
must lay the necessary foundation for its admissibility. 
8. Motions 
All motions shall be written motions. The motion shall include a statement of the motion itself, relevant 
facts, points and authorities, argument, prayer for relief, and a conclusion. All parties shall have been 
served with the motion at least two days prior to the PTC. Lengthy research is not expected. A motion, 
and any response, may be between one paragraph and three pages long. 
Procedural motions are discouraged. 
Motions in Limine. Motions to limit or exclude evidence at the trial should be made at this point in the 
PTC. Motions in limine are usually made for evidence that is clearly inadmissible or for evidence that is 
of such a nature that once the jury has heard it the cautionary or limiting instruction will not be effective 
(often characterized as "you cannot un-ring a bell"). 
The judge at the PTC will either rule on the motion at that time or reserve the matter to be handled 
at trial. 
• The judge will rule on the motion at the PTC when the evidence is such that even at this 
preliminary stage of the proceeding the law is clear that it is either inadmissible or admissible. 
• The judge will reserve ruling until trial when the admissibility of the evidence depends on 
how the facts are developed at trial. That is, a foundation for its admissibility must be laid at 
trial, the relevance of the evidence may or may not outweigh the prejudicial impact depend-
ing on what facts are developed at trial, or the judge determines that the evidentiary point is 
such that it is best determined within the context of the facts as they are developed at trial. 
If the judge grants the motion in limine, the evidence, of course, may not be mentioned in the opening 
statements or otherwise brought to the attention of the jury by the counsel who opposed the motion. 
Many lawyers do not consider this sufficient protection because a witness may "inadvertently" blurt out 
the evidence at trial. The revealing of the evidence completely circumvents the motion in limine and 
forces the lawyer to choose between requesting a mistrial and gambling on the jury verdict, a poor choice 
under any circumstances. To prevent this, many lawyers who are successful on a motion in limine then 
request the court to order opposing counsel to instruct their witnesses not to mention or allude to the 
evidence. Most judges will also add that they are holding counsel responsible for the conduct of their 
witnesses in this regard. 
If the judge reserves the motion in limine for trial, attention should be given to the use of the evidence in 
the opening statements. The proponent of the evidence should consider that mentioning the evidence in 
the opening statement may be sufficient grounds for a mistrial if the evidence is later ruled inadmissible. 
However, the enticement to get the evidence out early and up front in the minds of the jury is often so 
great that opposing counsel will gamble that it is admissible or not sufficiently inflammatory for a mistrial. 
National Institute for Trial Advocacy 117

## Page 84

CASE FILE 
Therefore, when a motion is reserved, counsel should make a motion requesting that the evidence not 
be mentioned in the opening statement or otherwise brought to the attention of the jury until the court 
has had an opportunity to rule on the admissibility of the evidence. It is an eminently fair request and 
is usually granted. If this request is granted, as in the prior situation, counsel should request the court to 
order opposing counsel to instruct their witnesses not to mention the evidence. Counsel should instruct 
the witness that she is not permitted to testify about that evidence unless she is specifically asked about it. 
If a motion in limine has been reserved for trial and counsel has been instructed not to bring the evidence 
to the attention of the jury until the court has ruled, the proper procedure is for counsel at the appro-
priate time during the trial (the foundation has been laid or the facts are fully developed) to approach 
the bench and request a ruling on the admissibility of the evidence that was the subject of the motion 
in limine. 
The rulings of the judge at the PTC shall not be re-litigated with the trial judge the morning of trial. The 
trial judge should be aware of the action taken on the motions in limine from the written pretrial order. 
Counsel may wish to direct the trial judge's attention to the pretrial order for informational purposes, 
particularly any motions that were reserved for action during the trial. 
9. Pretrial Order 
Counsel should have a joint proposed pretrial order prepared at the time of the PTC, which includes all 
of the above items. 
Any motions in limine can be listed by title with a space for the court's ruling, and the actual motion pre-
sented in a separate document. If the order is accurately phrased, the court strikes "proposed" and signs 
the order. Otherwise, an order will have to be prepared, approved as accurate by opposing counsel, and 
later presented to the court for signature. All counsel must sign the court's order prior to the trial starting. 
The trial judge must be given a copy of the final order signed by the court and all counsel. 
10. Jury Instructions 
Jury instructions have been provided in the trial materials. Preliminary and general jury instructions are 
included. Specific jury instructions relating to the law and facts of the particular case are with the trial 
materials for that case. 
No additional jury instructions will be permitted unless specifically authorized by the judge at the PTC. 
Proposed jury instructions should be presented to the court with the final pretrial order. Objections to 
any instruction should be brought up at the PTC. All of the instructions will be settled at that time. 
(Normally the court finalizes the instructions before closing argument.) At the end of the trial, the court 
reads the instructions to the jury. You should have your own copy to review at the same time to ensure 
the instructions were read properly and to object if read improperly. Otherwise, you may lose the issue for 
appeal. The judge and the instructor each need a copy of the instructions at the time of the trial. 
11. Trial Binders 
One trial binder per team is due at the end of the trial and will be returned to you at the last class. The 
trial binders shall reflect and contain all items necessary for your trial, including your organization and 
preparation. 
118 National Institute for Trial Advocacy

## Page 85

KEMPER V. NITA CIN CUBS HOLDINGS, INC. 
12. Other Matters 
Any matters relating to the simulated nature of the trial or the trial materials should be raised at this 
point. If any counsel has a problem or foresees any difficulties relating to the simulated nature of the trial, 
it should be discussed at the PTC so that the trial runs smoothly and in a realistic fashion. 
Remember, this is your show. It is up to you to make sure that everyone is informed of everything that 
you feel they need to know. It is also up to you to make sure that counsel, the court, and the instructor 
have all necessary copies. Good luck, and have fun. 
National Institute for Trial Advocacy 119

## Page 86

KEMPER V. NITA On' CUBS HOLDINGS, INC. 
Appendix B 
STATE OF NITA 
COMPILED STATUTES 
(100 NCCS 5/1-1) 
Sec. 1-1. This Act may be cited as the Liquor Control Act of YR-78. 
(100 NCCS 5/1-2) 
Sec. 1-2. This Act shall be liberally construed, to the end that the health, safety, and welfare of the 
People of the State of Nita shall be protected and temperance in the consumption of alcoholic liquors 
shall be fostered and promoted by sound and careful control and regulation of the manufacture, sale, 
and distribution of alcoholic liquors. 
(100 NCCS 5/10) 
(a) Every person who is injured within this State, in person or property, by any intoxicated person 
has a right of action in his or her own name, severally or jointly, against any person, licensed under 
the laws of this State or of any other state to sell alcoholic liquor, who, by selling or giving alcoholic 
liquor, within or without the territorial limits of this State, causes the intoxication of such person. 
(b) Any person owning, renting, leasing, or permitting the occupation of any building or prem-
ises with knowledge that alcoholic liquors are to be sold therein, or who having leased the same for 
other purposes, shall knowingly permit therein the sale of any alcoholic liquors that have caused the 
intoxication of any person, shall be liable, severally or jointly, with the person selling or giving the 
liquors. However, if such building or premises belong to a minor or other person under guardianship, 
the guardian of such person shall be held liable instead of the ward. 
(c) Any person or organization owning, renting, leasing, or permitting the occupation of any 
building or premises with knowledge that alcoholic liquors are to be sold therein, and whose premises 
National Institute for Trial Advocacy 121

## Page 87

CASE FILE 
Final Jury Instructions 
The Court will now instruct you on the law governing this case. 
1. You must arrive at a verdict by unanimous vote, applying the law, as you are now instructed to the 
facts as you have observed and find them to be. 
2. The plaintiff, Jessica Kemper, has filed a complaint against the defendant, Nita City Cubs Holdings, 
Inc., for negligence and for violating the Nita Liquor Control Act of YR-78. The defendant denies 
both claims. 
3. The defendant, a corporation, can act only through its agents and/or employees, and the relevant 
employees are the ones who made the decisions or conducted the actions or omissions of which the 
plaintiff complains in this action. 
4. For the plaintiff to prevail, she must prove her claims by a preponderance of the evidence. 
Negligence—Essential Factual Elements 
1. In Count I, the plaintiff claims she was harmed by Nita City Cubs Holdings, Inc.'s negligence. To 
establish this claim, the plaintiff Kemper must prove all of the following: 
First, that Nita City Cubs was negligent in serving alcohol to patron Kolleng; 
Second, that Jessica Kemper was harmed; and 
Third, that Nita City Cubs negligence was a substantial factor in causing the plaintiff Kemper's 
harm—that is, but for the negligence the damage would not have occurred. 
Basic Standard of Care 
2. Negligence is the failure to use reasonable care to prevent harm to oneself or to others. A person can 
be negligent by acting or by failing to act. A person is negligent if he does something that a reasonably 
careful person would not do in the same situation or fails to do something that a reasonably careful 
person would do in the same situation. 
3. You must decide whether a reasonably careful person would have served or continue to serve Daniel 
Kolleng alcoholic beverages. 
4. Benjamin Stone was the agent of the defendant, Nita City Cubs Holdings, Inc., at and before the 
time of this incident. Therefore, any act or omission of the agent at that time was in law the act or 
omission of the defendant, Nita City Cubs Holdings, Inc. 
Nita Liquor Control Act of YR-78—Essential Factual Elements 
5. In Count II, the plaintiff claims she is entitled to recover damages from the defendant for a violation 
of the Nita Liquor Control Act of YR-78. Under the Act, Nita City Cubs Holdings, Inc., is deemed a 
mass distributor with over thirty employees. To establish this claim, the plaintiff Kemper must prove 
all of the following: 
First, that Nita City Cubs Holdings, Inc., its agents, or servants, sold or gave intoxicating liquor 
consumed by Daniel Kolleng; 
Second, that the liquor thus consumed caused or contributed to the intoxication of Daniel Kolleng; 
124 National Institute for Trial Advocacy

## Page 88

KEMPER V. NITA Cm' CUBS HOLDINGS, INC. 
Third, that Daniel Kolleng's intoxication at the time of the incident was at least one cause of the 
occurrence in question. 
Fourth, as a result of the occurrence, the plaintiff suffered injury; and 
Fifth, that Nita City Cubs Holdings, Inc., negligently failed to properly or adequately train, advise, 
or supervise the individuals selling intoxicating liquors on its premises. 
Basic Standard of Care 
6. Negligence is the failure to use reasonable care to prevent harm to oneself or to others. A person can 
be negligent by acting or by failing to act. A person is negligent if she does something that a reason-
ably careful person would not do in the same situation or fails to do something that a reasonably 
careful person would do in the same situation. 
7. You must decide how a reasonably careful person would have trained, advised, or supervised the 
individuals selling intoxicating liquors on its premises. 
8. Lara Kotkin and Diane Sandberg were both agents of the defendant, Nita City Cubs Holdings, Inc., 
at and before the time of this incident. Therefore, any act or omission of an agent, regarding duties 
of supervision and oversight of the defendant's liquor sale operations at that time, was in law the act 
or omission of the defendant Nita City Cubs Holdings, Inc. 
Damages 
[NB: If damages are to be determined in another proceeding read the following Instruction #9. Otherwise, 
continue with the below Compensatory Damage Instruction(s) #10-12]. 
9. You need not concern yourself with damages at this time. 
OR 
10. Damages—Compensatory Damages 
a. If you decide that Jessica Kemper has proved her claim against Nita City Cubs Holdings, 
Inc., you also must decide how much money will reasonably compensate Kemper for the 
harm. This compensation is called "damages." 
I. The amount of damages must include an award for each item of harm that was caused by the wrong-
ful conduct of Nita City Cubs Holdings, Inc., even if the particular harm could not have been 
anticipated. 
12. Jessica Kemper does not have to prove the exact amount of damages that will provide reasonable 
compensation for the harm. However, you must not speculate or guess in awarding damages. 
Concluding Instruction 
13. Ladies and gentleman of the jury, this is the conclusion of the instructions, and it is now time to retire 
to the jury room, where you will choose a foreperson and begin your deliberations. This is the verdict 
form. Upon making your decision, please fill out the form, sign it, date it, and then return with your 
verdict to the courtroom. 
National Institute for Trial Advocacy 125

## Page 89

U.S. DISTRICT COURT 
FOR THE STATE OF NITA 
Civil Division 
JESSICA KEMPER, 
Plaintiff, 
v. 
NITA CITY CUBS HOLDINGS, 
INC., 
Defendant. 
NITA: YR-1-CIV-10784 
VERDICT 
We, the jury, return the following verdict, and each of us concurs in the verdict: 
[Choose the appropriate verdict] 
We, the jury, unanimously find as follows in response to the questions submitted to us: 
Question 1 
Was the defendant Nita City Cubs Holdings, Inc., negligent in serving alcoholic beverages to 
Daniel Kolleng? 
YES NO 
Question 2 
Did the defendant, Nita City Cubs Holdings, Inc., violate the Nita Liquor Control Act of YR-78 by 
negligently training, advising, or supervising its employees? 
YES  NO 
Question 3 
What is the amount of the plaintiff's damages? 
Date Foreperson 
National Institute for Trial Advocacy 127
