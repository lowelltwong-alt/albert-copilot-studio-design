# Included case fixtures

Choose one folder for the first run. Each folder contains an original PDF, its paired OCR Markdown working copy, a source-boundary README and an exact Case Analyst start prompt.

| Folder | Use it for |
|---|---|
| `msimoto-fire/` | Msimoto Fire insurance mock-trial case |
| `kemper-city-cubs/` | Nita City Cubs baseball-bat injury case |
| `evans-professor/` | Evans v. Nita State University, involving adjunct Professor Jamie Winstone |

For every folder, the PDF is source authority. The OCR Markdown is searchable convenience text and may contain recognition or layout errors. Keep these files private and confirm redistribution rights before publication.
