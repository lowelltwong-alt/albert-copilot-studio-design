# Evans v. Nita State University case fixture

This folder is included so the first MVP pilot can start with a real, source-grounded test instead of an empty chat. It is the university cyberbullying case involving an adjunct professor.

## Files

- `EVANS-original.pdf` — original case-file PDF. Treat this as the source authority.
- `EVANS-ocr.md` — our existing OCR-derived Markdown snapshot. It is a working convenience copy, not source truth; preserve uncertainty and compare it to the PDF when the two differ.
- `CASE-START-PROMPT.md` — the exact first message to send after the Case Analyst agent is configured.

## Use and rights

This is a private test fixture for the recipient's licensed mock-trial work. Do not publish, commit to a public repository, or redistribute the PDF unless the recipient has the right to do so. The package contains no OCR engine; it only supplies the existing OCR snapshot so the prompt-only MVP can be exercised.

## Source boundary

The PDF is authoritative. The OCR Markdown may have recognition errors, missing layout, and imperfect exhibit boundaries. The Analyst must keep page anchors, semantic exhibit boundaries and conflicts visible, and must not turn an OCR guess into a fact. If the tenant cannot ingest the PDF, record that limitation in the source ledger and keep the PDF beside the run for human review.

## Integrity

- Original PDF SHA-256: `d5a7cd90c8cd238a70cdc823f59a7157cd49a936a80979d125f9906d8c0cf258`
- OCR Markdown SHA-256: `ac88d3e1750de465c40c85ac5241ab81c97afadf458e7b7aa7637561af6db85e`

