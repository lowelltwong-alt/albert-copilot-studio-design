# Evans V. Nita State University — full OCR text (test fixture)


## Page 2

EVAN S V.
NITA STATE UNIVERSITY
Second Edition
Elizabeth L. Lippy
Partner, Fairlie & Lippy, P.C.
Associate Director of Trial Advocacy
American University Washington College of Law
\` NITA NATIONAL INSTITUTE FOR TRIAL ADVOCACY '

## Page 3

© 2019 by the National Institute for Trial Advocacy
All rights reserved. No part of this work may be reproduced or transmitted in any form or by any means,
electronic or mechanical, including photocopying and recording, or by any information storage or retrieval
system without the prior written approval of the National Institute for Trial Advocacy unless such copying is
expressly permitted by federal copyright law.
Law students who purchase this NITA publication as part of their class materials and attendees of NITA-
sponsored CLE programs are granted a limited license to reproduce, enlarge, and electronically or physically
display, in their classrooms or other educational settings, any exhibits or text contained in the printed publi-
cation or online at the proprietary website. However, sharing one legally purchased copy o£ the publication
among several members o£ a class team is prohibited under this license. Each individual is required to pur-
chase his or her own copy of this publication. See 17 U.S.C. § 106.
Address inquiries to:
Reprint Permission
National Institute for Trial Advocacy
1685 38th Street, Suite 200
Boulder, CO 80301-2735
Phone: (800) 225-6482
Fax: (720) 890-7069
Email: permissions@nita.org
ISBN 978-1-60156-801-4
FBA. 1801
eISBN 978-1-60156-802-1
eFBA 1802
Printed in the United States of America
Wolters Kluwer
Official co-publisher of NITA.
WKLegaledu.com/NITA

## Page 4

ACKNOWLEDGMENTS
I would like to acknowledge the special contributions made by former students of the American
University Washington College of Law who helped research, draft, and edit this case file, particularly
Allyson Breech, Ryan Norman, Brittany Gail Thomas, Annie Berry, and Rebekah Mudri.
Together with the National Institute for Trial Advocacy (NITA), I wish to thank Facebook for its
permission to use likenesses of its website as part of these teaching materials.
I couldn't be doing what I do without the help and support of my law partner, Steven F. Fairlie,
who somehow lets me be in two places at once.
Last, but not least, my modern family and my true partner, my amazing husband. . . without
whom I could not accomplish half of my goals.
Liz Lippy
September 2019
National Institute for Trial Advocacy v

## Page 5

CONTENTS
CASE SUMMARY 1
SPECIAL INSTRUCTIONS FOR USE AS A FULL TRIAL 3
NOTICE  5
COMPLAINT 7
ANSWER 11
EXHIBITS  15
Exhibit 1—Selected Portions of Nita State University Student Handbook 17
Exhibit 2—October 28, YR-3, Memo to Dean Jeffries from Jamie Winstone 19
Exhibit 3—Nita State University Professor Evaluation Summary 21
Exhibit 4—Nita State University Academic Integrity Board Summons 23
Exhibit 5—Facebook Screenshots 25
Exhibit 6—Keg Stand Video 29
Exhibit 7—Emails between Dean Dylan Jeffries and Jamie Winstone 31
Exhibit 8—Text Messages between Riley Evans and Rob Thompson 33
Exhibit 9—Student Evaluations Screenshot on TeacherMeter 35
Exhibit 10—Anonymous Email to Dean Jeffries 37
DEPOSITIONS  39
Riley Evans 41
Jamie Winstone 53
Dylan Jeffries 61
Morgan Ritchfield  69
STATE OF NITA SCHOOL CYBERBULLYING PROTECTION ACT OF YR-6 7'7
JURY INSTRUCTIONS 79
VERDICT FORM 83
National Institute for Trial Advocacy vii

## Page 6

CASE SUMMARY
This is a civil action for negligence brought by the plaintiff Riley Evans against the defendant Nita
State University. Evans alleges that Nita State University, in violation of the Nita School Cyberbully-
ing Protection Act (CBPA) and university policy, failed to provide a safe learning environment and
did not prevent hostile cyberbullying that substantially interfered with Evans's education..
In Fall YR 3, Riley Evans was a student at Nita State University and was enrolled in a popular
course entitled Politics and Social Media, taught by Adjunct Professor Jamie Winstone. The course,
designed to teach students about the role of the Internet and social media in political campaigns,
involved students running simulated presidential campaigns using social websites such as Facebook.
Evans and one other student, Morgan Ritchfield, were selected by Winstone to be the presidential
candidates in the class. The remaining students were split into two groups and assigned to help run
the candidates' campaigns.
Morgan Ritchfield and students from the opposing campaign team began posting material about
Evans on a Facebook page entitled Politics and Social Media YR 3 Election, stating that Evans was
known to have cheated in an unrelated class, had made fun of a disabled student, and was seen
drinking underage at a campus fraternity party and included a video of the alleged incident. Evans
notified Winstone on two occasions about the nature of the posts on Facebook, but Winstone failed
to do anything about them. Winstone replied that the posts were nothing more than hard-nosed
campaigning and typical campaign mudslinging.
Following the Facebook posts, Evans was investigated by the Nita State University Academic In-
tegrity Board and received a summons to report to the board for a hearing on information involving
allegations of cheating and underage drinking. However, Evans withdrew from the university before
the hearing could take place.
The applicable law is contained in the statutes and proposed jury instructions set forth at the end
of this case file. All years in these materials are stated in the following form:
• YR-0 indicates the actual year in which the rase is being tried (i.e., the present year);
• YR-1 indicates the preceding year (please use the actual year);
• YR-2 indicates the next preceding year (please use the actual year); et cetera.
Electronic exhibits are available for download:
http://bit.ly/ 1 P20Jea
Password: Evans2
National Institute for Trial Advocacy 1

## Page 7

SPECIAL INSTRUCTIONS FOR USE AS A FULL TRIAL
When this case file is used for a full trial, the following witnesses may be called by the parties:
P1aintifh Riley Evans
Jamie Winstone
Defendant: Morgan Ritchfield
Dylan Jeffries
All witnesses are race- and gender-neutral and may be either male or female.
Limitation on Witnesses
Each party is limited to two witnesses. `
Required Stipulations
1. Federal Rules of Civil Procedure and Federal Rules of Evidence apply.
2. All witnesses called to testify who have identified the parties, other individuals, or tan-
gible evidence in depositions or prior testimony can and will, if asked, identify the same
at trial.
3. Each witness who gave a deposition agreed under oath at the outset of his or her testi-
mony to give a full and complete description of all material events that occurred and to
correct the transcript of such deposition or testimony for inaccuracies and completeness
before signing the transcript.
4. All depositions and transcripts of testimony were signed under oath.
5. The plaintiff and the defendant must call the two witnesses listed as that party's witnesses
on the witness list.
6. All exhibits in the file are authentic. In addition, each exhibit contained in the file is the
original of that document unless otherwise noted on the exhibit or as established by the
evidence.
7. This case comes to trial in YR-1.
8. The defendant attempted to file a cross-complaint against Adjunct Professor Jamie Win-
stone. However, the judge ruled that the immunity clause of the State of Nita School
Cyberbullying Protection Act of YR-6 protected Winstone from any such suit.
National institute for Trial Advocacy 3

## Page 8

CASE FILE
9. The defendant filed a cross-complaint against Morgan Ritchfield. A confidential settle-
ment occurred and may not be mentioned before the jury.
10. Exhibit 5 contains screenshots of the Facebook group entitled Politics and Social Media
YR-3 Election, and reflects all posts made in the group. Seventy-six people with Face-
book profiles became members of the group during the Fall YR-3 semester. The only
administrator of the group was the course instructor, Adjunct Professor Jamie Winstone.
The Facebook group page was capable of being downloaded and disseminated electroni-
cally.
11. The individual profile pages for Morganmaniac, Mritch4prez, EvansYR-3, Goldiephd,
Morgan Ritchfield, RitchfieldYR-3, Evanslvr, and Jamie Winstone are inaccessible.
12. Counsel for the plaintiff sent a request to defense counsel on November 4, YR-3, request-
ing that the Facebook page not be altered, destroyed, or modified in any way. Defense
complied with the request, and the Facebook page has not been altered from the date of
•the last posting, November 3, YR-3. Further, the Facebook page was no longer "live" on
the Internet as of November 4, YR-3.
13. An adjunct professor, adjunct faculty, and any deans at state-funded universities are con-
sidered agents of the state-funded university. See Machovina a Nita State University, 99
W.S.2d 1250 (Nita YR-4).
14. Exhibit 9 is a screenshot of student evaluations of Professor Jamie Winstone from the
website TeacherMeter in August YR-3.
15. This is a bifurcated trial. At this point in the trial, the jury is only deciding whether Nita
State University was negligent or whether Riley Evans assumed the risk.
4 National Institute for Trial Advocacy

## Page 9

BREECH & BREECH, PC
Attorney ID #24601
EBreech@bbpc.nita
1501 Tort State Road
Nita City, Nita 01234
ATTORNEY FOR PLAINTIFF
DISTRICT COURT OF THE STATE OF VITA
CIVIL DIVISION
RILEY EVANS
V.
NITA STATE UNIVERSITY
No. 123-YR-2
NOTICE
You have been sued in court. If you wish to defend against the claims set forth in the following
pages, you must take action within twenty days after this complaint and notice are served by
entering a written appearance personally, or by an attorney, to the claims set forth against you.
You are warned that if you fail to do so,
the case may proceed without you and a judgment may
be entered against you by the court, without further claims or relief requested by the plaintiff.
You may lose money, property, or other rights important to you.
National Institute for Trial Advocacy 5

## Page 10

BREECH & BREECH, PC
Attorney ID #24601
EBreech@bbpc.nita
1501 Tort State Road
Nita City, Nita 01234
ATTORNEY FOR PLAINTIFF
DISTRICT COURT OF THE STATE OF NITA
CIVIL DIVISION
RILEY EVANS
V.
NITA STATE UNIVERSITY
No. 123-YR-2
COMPLAINT
The plaintiff, by and through undersigned counsel, brings this action at law and respectfully
represents:
1. The plaintiff, Riley Evans, is an adult individual with a permanent address of 200 West
Oxfield Lane, Oaksville, Nita.
2. The defendant, Nita State University, is a quasi-municipal corporation created pursuant
to the law of the State of Nita and is controlled by state guidelines of Nita and as such is
governed by the Nita School Cyberbullying Protection Act (CBPA).
3. Venue and jurisdiction in this court are proper, as the plaintiff is a resident of Nita and all
facilities of Nita State University are located in this judicial district.
4. In or about August YR-4, the plaintiff enrolled as a student at Nita State University and
was so enrolled during the YR-3IYR-2 academic year.
5. In or about August YR-3, the plaintiff was a sophomore at Nita State University and
enrolled in a course entitled Politics and Social Media, which was offered at the school
for the two prior academic years and was taught by Adjunct Professor Jamie Winston
(hereinafter Professor Winstone).
National Institute for Trial Advocacy 7

## Page 11

CASE FILE
6. During the Fall YR-3 semester, the students in Politics and Social Media engaged in a
mock presidential election and campaign utilizing social media, which included Face-
book.
r,
7. As part of the aforementioned assignment, Professor Winston appointed two students
as the presidential candidates—specifically, the plaintiff and another sophomore student
named Morgan Ritchfield.
8. During the presidential election campaign process in Politics and Social Media, the
plaintiff became the subject of cyberbullying by students at Nita State University, includ-
ing, but not limited to, taunting, teasing, and bullying through the Internet (hereinafter
"cyberbullying") to such a degree that the plaintiff became anxious, upset, depressed,
and socially withdrawn, and the cyberbullying substantially interfered with the plaintiff's
educational experience.
COUNT I-NEGLIGENCE
9. The plaintiff hereby incorporates by reference the averments set forth in Paragraphs 1
through 8 as though fully set forth herein at length.
10. At all relevant times, the defendant owed a duty to provide a safe and appropriate envi-
ronment for the plaintiff to learn and benefit from the education provided by Nita State
University and to prevent a hostile environment that substantially interfered with the
plaintiff's educational performance, opportunities, or benefits, in accordance with the
Nita School Cyberbullying Protection Act, 18 N.C.L. § 3952(b) (CBPA).
11. The plaintiff had multiple meetings with Professor Winstone regarding the cyberbullying
and therefore the defendant was on notice that the plaintiff was a target of the ongoing
abuse.
12. Despite the plaintiff's regular and repeated requests for help, the defendant consistently
failed to prevent the ongoing abuse or to take any meaningful measures to prevent the
ongoing cyberbullying.
13. As a result of the defendant's utter failure to act in spite of notice, and as a result of the
ongoing cyberbullying, the plaintiff withdrew as a student at Nita State University on
November 3, YR-3.
14. As a direct and proximate cause of the actions and/or omissions of the defendant, the
plaintiff suffered, among other things, emotional distress.
15. The plaintiff is entitled to recover damages, which the plaintiff claims in excess of FIFTY
THOUSAND DOLLARS ($50,000.00) together with costs, interest, and attorney fees as
allowed by law.
a National Institute for Trial Advocacy

## Page 12

EVANS V. NITA STATE UNIVERSITY
WHEREFORE, the plaintiff respectfully requests judgment against Nita State University in an
amount yet to be determined, including reasonable attorney fees and costs.
Respectfully submitted,
BREECH & BREECH, PC
By:
E. Breech
Attorney for Plaintiff
VERIFICATION
I, Riley Evans, am the plaintiff in the within action and state that the facts set forth in the
foregoing complaint are true, correct, and accurate to the best of my information and belief.
I understand that false statements made herein are subject to penalty of law relating unsworn
falsifications to authorities.
Riley Evans
Plaintiff
January 10, YR-2
National Institute for Trial Advocacy 9

## Page 13

DEFENSE ATTORNEYS, LTD.
Attorney ID #66612
Jnucci@defenseattysltd.nita
4 Defense Road
Nita City, Nita 01233
ATTORNEY FOR DEFENDANT
DISTRICT COURT OF THE STATE OF NITA
CIVIL DIVISION
RILEY EVANS
V.
NITA STATE UNIVERSITY
No. 123-YR-2
ANSWER
The defendant, Nita State University, by and through undersigned counsel, hereby answers
the plaintiff's complaint and respectfully represents:
1. Admitted.
2. Admitted.
3. Admitted.
4. Admitted.
5. Admitted.
6. Admitted.
7. Denied. It is specifically denied that Professor Winstone appointed the plaintiff as the
presidential candidate. To the contrary, the plaintiff volunteered to become the presiden-
tial candidate and was only appointed to that position after the plaintiff volunteered.
8. Denied. It is specifically denied that the plaintiff became the subject of cyberbullying by
students at Nita State University; that the plaintiff became anxious, upset, depressed, and
socially withdrawn; and that the plaintiff's educational experience was substantially inter-
fered with due to the alleged cyberbullying. Strict proof is hereby demanded at time of trial.
National Institute for Trial Advocacy 11

## Page 14

CASE FILE
COUNT I-NEGLIGENCE
9. No answer required.
10. Denied as a conclusion of law. To the extent the allegations contained in Paragraph 10 are
not conclusions of law, they are specifically denied and strict proof is hereby demanded
at the time of trial.
11. Denied as a conclusion of law. To the extent the allegations contained in Paragraph 11 are
not conclusions of law, they are specifically denied and strict proof is hereby demanded
at the time of trial.
12. Denied as a conclusion of law. To the extent the allegations contained in Paragraph 12 are
not conclusions of law, they are specifically denied and strict proof is hereby demanded
at the time of trial.
13. Denied as a conclusion of law. To the extent the allegations contained in Paragraph 13 are
not conclusions of law, they are specifically denied and strict proof is hereby demanded
at the time of trial.
14. Denied as a conclusion of law. To the extent the allegations contained in Paragraph 14 are
not conclusions of law, they are specifically denied and strict proof is hereby demanded
at the time of trial.
15. Denied as a conclusion of law. To the extent the allegations contained in Paragraph 15 are
not conclusions of law, they are specifically denied and strict proof is hereby demanded
at the time of trial.
AFFIRMATIVE DEFENSES
16. The defendant hereby incorporates by reference the averments set forth in Paragraphs 1
through 15 as though fully set forth herein at length.
17. The plaintiff's claims are barred, in whole or in part, by the doctrine of assumption of
the risk:
18. To the extent that the plaintiff seeks to present claims under the State of Nita's anti-
cyberbullying legislation, those claims are barred as these statutes create no separate
cause of action.
19. The conduct described in the plaintiff's complaint does not rise to the level of cyberbul-
lying.
12 National Institute for Trial Advocacy

## Page 15

EVANS V. NITA STATE UNIVERSITY
WHEREFORE, the defendant, Nita State University, respectfully requests that this Honorable
Court find in its favor and against the plaintiff's complaint, together with costs and reasonable
attorney fees as allowed by law.
Respectfully submitted,
DEFENSE ATTORNEYS, LTD.
By:
J. Nucci
Attorney for Defendant
VERIFICATION
I, Dylan Jeffries, am the Dean of Academics for Nita State University, and as such am an agent
of the defendant capable of signing this verification. I hereby state that the facts set forth in the
foregoing answer are true, correct, and accurate to the best of my information and belief. I under-
stand that false statements made herein are subject to penalty of law relating unswom falsifica-
tions to authorities.
Dylan Jeffries
Agent of the Defendant
February 1, YR-2
National Institute for Trial Advocacy 13

## Page 16

EVANS V. N/TA STATE UNIVERSITY
Exhibit 1
Selected Portions of Nita State University
Student Handbook
Section 6640 — Cyberbullying
6640.1 The Nita State University Board strives to provide a safe, positive learning climate for
students in the schools. Therefore, it shall be the policy of the university to maintain an educational
environment in which cyberbullying in any form is not tolerated.
6640.1a All forms of cyberbullying by university students is hereby prohibited. Anyone who
engages in cyberbullying in violation of this policy shall be subject to appropriate discipline.
6640.1b Students who have been the victim of cyberbullying shall promptly report such inci-
dents to any staff member, university professor, or any other employee of the university.
6640. lc Complaints of cyberbullying shall be investigated promptly, and corrective action shall
be taken when a complaint is verified.
6640.1d The university shall annually inform students that cyberbullying of students will not
be tolerated.
6640.1e Each student shall be responsible for respecting the rights of his or her fellow students
and to ensure an atmosphere free of all forms of cyberbullying.
6640.2 "Cyberbullying" is the repeated use by one or more students of a verbal, written, or elec-
tronic expression, or any combination thereof, directed at the victim that creates a hostile environ-
ment for the victim or interferes with the victims rights at school.
6640.2a "Technology" includes, but is not limited to, telephones, computers, game consoles,
and personal electronic devices such as portable music players, computer tablets, cellular telephones,
and smartphones.
6640.2b "Electronic communications" include, but are not limited to, any written, oral, or vi-
sual imagery sent through technology included in (a) above. Examples of communications include
websites, electronic mail, instant messages, and postings to social media or shared media sites, either
within the school's domain or in the public domain through use of the school's equipment or under
the school's supervision.
6640.2c A "hostile environment" is a situation that is permeated with intimidation, ridicule, or
insult that is sufficiently severe or pervasive to substantially interfere with the victims educational
performance, opportunities, or benefits.
National Institute for Trial Advocacy 17

## Page 17

CASE FILE
6640.3 A violation of this policy shall subject the offending student to appropriate disciplinary
action, consistent with the student discipline code, which may include verbal or written reprimands,
suspension, expulsion, or notification to the appropriate authorities.
s'.
18 National Institute for Trial Advocacy

## Page 18

EVANS V. NITA STATE UNIVERSITY
Exhibit 2
October 28, YR-3, Memo to Dean Jeffries from Jamie Winston
TO: Dean Dylan Jeffries
FROM: Jamie Winston, Adjunct Professor
Department of Political Science
DATE: October 28, YR-3
SUBJECT: Student meeting
Dean Jeffries:
I met with Riley Evans; a student in my Politics and Social Media class yesterday. Evans
expressed concerns about the content of student comments on our Facebook page. As you
know,
my seminar involves a mock presidential election and part of that process is allowing students to
conduct a campaign using social media. As such, I created a Facebook page entitled Politics and
Social Media YR-3 Election, on which students can post comments and information about the
"candidates" for that semester's elections.
Evans was complaining about comments fellow students had posted regarding Evans's academic
and moral integrity. I review the postings on the bulletin board every day before class. Noth-
ing that was posted comes close to crossing the line, in my opinion. I did my best to encourage
Evans to stay with the class, explaining that the purpose of the class was to simulate real-world
scenarios. It is natural that some feelings might get hurt, but I believe it is necessary in order
to promote a dialogue and really get students to think about the impact words have on society,
especially in our instant-news world.
If you have any questions about this, let me know.
Jamie Winstone
National Institute for Trial Advocacy 19

## Page 19

EVANS V. NITA STATE UNIVERSITY
Exhibit 3
Nita State University Professor Evaluation Summary
Teaching the Minds of Tomorrow
Professor Evaluation Summary
This displays the average grade of student evaluations received for the professor and
class listed below. Evaluations are completed prior to the end of each semester by all
students in the class. Professors are rated on a scale of 1 to 5, with 1 being the lowest
("do not agree at all") and 5 being the highest ("agree completely").
Professor: JAMIE WINSTONE
Class: POLITICS AND SOCIAL MEDIA
Semester/Number of Evaluations FA YR-6
(10/12)
SP YR-5
(9/12)
FA YR-5
(7/12)
SP YR-4
(9/12)
FA YR-4
(8/12)
SP YR-3
(9/12)
Professor was enthusiastic and
knowledgeable
5.0 5.0 5.0 5.0 5.0 5.0
Professor managed class effectively 4.4 5.0 4.4 4.1 4.5 4.3
Professor responded to student
questions
4.2 3.0 3.2 1.9 2.3 1.9
Professor responded to student
concerns
2.3 1.7 3.2 2.8 2.7 2.5
Professor encouraged differing
opinions
4.8 5.0 4.0 3.6 3.5 3.0
Professor maintained respectful
learning environment
3.0 3.0 2.9 2.7 2.5 3.0
National Institute for Trial Advocacy 21

## Page 20

CASE FILE
Student Comments
• This class rocks! This class was so much fun and so relevant . . .
• The idea of this class is great, but Professor Winstone really let some students say whatever
they wanted to on the Facebook pages. Some of the comments are harsh!!!
• This class will definitely help prepare me for the real world. Social media is the way to go
nowadays for everything. If you can get into this class, you definitely should! But don't be
dumb and volunteer to be one of the presidential candidates. It can get a little vicious and
personal!
• So cool to be able to get more information about how social media can be utilized for pur-
poses of politics. Even Trump should've taken this class.
• I understand that we are all adults at this point, but Winstone never deals with any of the
drama that occurs during the election . . . that Facebook page is like a free-for-all.
22 National Institute for Trial Advocacy

## Page 21

EVANS V. NITA STATE UNIVERSITY
Exhibit 4
Nita State University Academic Integrity Board Summons
Teaching the Minds of Tomorrow
SUMMONS
Academic Integrity Board (Disciplinary Board)
Department
IN THE MATTER OF
Riley Evans
Respondent
Docket No.: YR-3-632
TO:
Riley Evans
200 W. Oxfield Lane
Oaksville, Nita 01242
YOU ARE COMMANDED TO:
x Appear and testify in the above-entitled matter at the place, date, and time indicated below
for:
Disciplinary Board Hearing as a result of allegations of cheating and underage drinking
during the YR-4/YR-3 academic year.
National Institute for Trial Advocacy 23

## Page 22

CASE FILE
And there to remain until discharged by the Academic Integrity Board by which you are sum-
moned to testify to the truth, to the best of your knowledge.
By order of said Disciplinary Board, this  1st  day of  November  ,  YR-3  , at Nita State
University.
Location to appear: Office of the Dean of Academics
Date and time to appear: November 16, YR-3, 9:00 a.m.
Signature of Officer Issuing Subpoena
24 National Institute for Trial Advocacy

## Page 23

EVANS V. NITA STATE UNIVERSITY
Exhibit 5
Facebook Screenshots
Search for people, places and things
Wall
Hidden Posts
Info
Friend Activity
Photos
EDIT
About
This Facebook Page is created for the
Politics and Social Media Course
taught.....
More
17
like this
3
tailing about this
Politics and Social Media YR-3 Election
Education Edit Info
Wall
Share: Status Photo Link
liked
Politics and Sodai Media.... Everyone (Most Recent)
Video Question
[Write something
Morganmaniac
SuceesnN!! Evans drops out of the eampaign...and schooi! Good riddance to the iying, cheating, racist
crybaby, See.,.sodal media does work in campaignsi!i
tike Comment Novemher3, yR-3 at 12:08pm
Mrttch4prez Yay! I heard Evans got a summons from the Diseiptnary guard and was too
chicken to face the fads so quoting school was easier. Leoerili
Like Novemher3,1R-3 at 12:10pm
[ Write a comment...
EvansYR-3
Who's the rat? Who sent these things to the Disdpteary Board? Speak now or forever hold your peace.
Like Comment November 1, YR-3 at 12.38pm
0
tloeganmaniac What are you wonted about, Evans? If none of this is true, then why do you
are? Crybaby.
Like November 2, P5-3 at 8:57am
Mritch4prez RMorganmaniac- I tutaily agreet Evans is a loser and a punk. Definitely not
capable of being president..eot even in a college dassil!
Like November 2,15-3 at 8:57am
EvansYR-3 Why are you guys so mean? This page is meant to help your candidate, not pot
me down! I ant beileve all of this.
Like November 2, YR-3 at 8:58am
tlorganmanlac Waaaaaaa waaaaaa
like November 2,YR-3 at8:58am
[write a comment...
National Institute for Trial Advocacy 25

## Page 24

CASE FILE
Goldlephd
, Hey. I am a law student at Nita State UMversry Cotege of Law (NCL)...Just wanted to share my two
;y cents. Evans paid me to unite freshman essays last year...I totally believe the cheating stones.
' y  Like Comment October21, YR-3 at 12:t4pm
EVansYR-3 Did you send thin to this asdplbary Board? How dare you!
Like November 1, YR-3 at 12:35pm
tin-tch4prez Goldie doesn't need to! Everyone (mows you'rea cheat and a Ilan
Like November 1, YR-3 at 12:40pm 0t.t
Write a comment.,.
EvansYR-3
Be sure to vote for the candidate who is down to earth, doesn't kiss up to professors, and gets things
done!!![
Like Comment Octaber24,YR-3at2:oipm
tiorganmantac You cant possibly think that describes you!! Get real. You're such a loony.
Like October 24, YR-3 at 2:01pm
fWrite a comment,.
Morgan RRchfieki
Like Comment October 24, YR-3 at 1:06pm
Morgan Rltohfleld Not off the presses!! Onto bad of Evans totally wasted at the Gamma
Tau Lambde party!! Non old Is Evans again? Oh Yeah...19! HAHAHAHAHA
Like October 24, YR-3 at 1:09pm
EvansYR-3 Morgan..dhafs a low blow! Where did you get this video? I can't beteve you
posted lids!
Like October 24, YR-3 at 1:10pm
EvansYR-3 You cant even prove that video Is of me. Nice try...yoo re such a sleezebdl,
Ritchheld. Why don't you go suck opts the pmfessors some more?
Like October 24, YR-S at 1:57pm
Write a comment..
26 National Institute for Trial Advocacy

## Page 25

EVANS V. NITA STATE UNIVERSITY
,g
t4r11ch4prez.
Duo hoof It Crybaby Riley ran to the professor. If you can't take the heat, Evans, drop out of the race!
Better yet drop out of school!
Like Comment October 13, YR-3 at 11:58am
EvansYR-3
Gmatjob, Ritchfleld...sending yourgoans oat to smear my name because you're too much of a coward to
contort we yourself. Yeah sight, you have integrity.,.
Like Comment October ll,YR-3 at 1:48pm
t4arganmaniac
lows flash.,.Evans definitely cheated last semester. Some grad student wrote Evans's freshman essays!
Don't vote for a candidate who cant even do their own woddf
Like Comment Octoherlo,YR-3at32:I8pm
l'litch4prez Yepl lives to the same political sdence class last spring..,Evans del copied off a
grits test In the final O when I asked about it, Evans said It was no big deal.
Like October 10, YR-3 at 12:23pm
i~ t4arganmaniac What a jerk! Totally bekve It though, after  heard Evans making fun of a kid
a 0 Ina wheelchair- told a totally radst & crude joke about him.
like October 10, YR-S at 12:27pm
RitctrlreldYR--3 Sex folks.,proof thatlm the candidate with integrity In this racetll
Like October 10, YR-3 at 12:38pm
Write a comment..
RitchfiehlYR-3
Remember balks - vote for the candidate with Integrity, not the eoe who only pretends to care.
Like Comment October 6, YR-3 at 11:42pm
hlorganmaniac Oan"t listen to Evans...a liar and a cheat!
like October 6, YR-3 at 12:04pm
Evanslvr You can't ray that wlout prooD Stop trying ta ke negative. Ritchfleld's campaign is a
joke.
li ke October 6, YR-3 at 12:otym
Write a comment...
lamle Winstone
What an exattng new year! I can'twa@ to see all of the great ways you utilize Pacebook for purposes of
! this eledionl
Like Comment October 6, YR-3 at 11:26pm
There are no more posts to show.
National Institute for Trial Advocacy 27

## Page 26

EVANS V. VITA STATE UNIVERSITY
Exhibit 6
Keg Stand Video
Exhibit ' iido
The digital file for this video and all other exhibits in this case file are available for download:
http://bit.ly/1 P20Jea
Password: Evans2
National Institute for Trial Advocacy 29

## Page 28

EVANS V. VITA STATE UNIVERSITY
Exhibit 7
Eniails between Dean Dylan Jeffries and Jamie Winstone
FROM: jwinstone@nsu.edu.nita
TO: djeffries@nsu.edu.nita
DATE: August 18, YR-3, 2:03 p.m.
SUBJECT: RE: Nita Cyberbullying Policy
Dean Jeffries:
I received your email about cyberbullying.
I look forward to another exciting semester!
Jamie Winstone
Adjunct Professor
Nita State University
FROM: djeffries@nsu.edu.nita
TO: fac/staff_listserve@nsu.edu.nita
DATE: August 15, YR-3, 9:34 a.m.
SUBJECT: Nita Cyberbullying Policy
Dear Faculty and Staff:
As you know, Nita State University takes cyberbullying very seriously. With this policy, we hope
to aid you in preventing and remedying any cyberbullying you become aware of in your
capacity as an employee at this university. The university's anti-cyberbullying policy is attached.
You MUST respond via email to me that you have reviewed this policy within SEVEN days of this
email.
Sincerely,
Dean Dylan Jeffries
Dean of Academics
Nita State University
National Institute for Trial Advocacy 31

## Page 29

CASE Fits
Cyber Bullying P+IIcy~docx 22K~
~r
32 National Institute for Trial Advocacy

## Page 30

EVANS V. VITA STATE UNIVERSITY
Exhibit 8
Text Messages between Riley Evans and Rob Thompson
••••• Verizon LTE 4:05 PM
Messages Rob
0 $ 11
Contact
Hey Rob. I know you're
Morgans campaign
manager. Can you take
that video off of
Facebook?
Who is this?
Riley Evans.
Hey. Look, if you didn't
want people to know
about it you shouldn't have
done it. Sorry.
r
Yeah,
Delivered
LI iMessage Send
National Institute for Trial Advocacy 33

## Page 31

EVANS V. N/TA STATE UNIVERSITY
Exhibit 9
Student Evaluations Screenshot on TeacherMeter
Home { About Revenge of the Teachers ! Shop },
Home.. United States • Rita.. Rita State University.. Jamie Winston
Jamie Winstone
School: Nita State University
Location: Nita City, Nita
Department Political Science
7.8
DATE CLASS Score
5/29/YR-4 P514 8/10
5/27/511-4 P5M 9/10
12/4/YR-5 P514 5110
12/31YR-5 P5M 9110
Rate this teacher
National Institute for Trial Advocacy
7.2 etattucoensly
Q.Search
Hi, Guestl lcreate account i login]
NOW ON DEMAND
LIARr LIAR, PANTS ON FIRE:
IMPEACHMENT TOOLS,
STRATEGIE S, AND TECHNIQUES
1'  studio7l
Staling hotl Great professor, but not going to tame down the class foryou. If you run for president,
beware!!
Its true, Profesar Winston wants you to get a real-world experlence with this class. The professor is
really interested in preparing you to run a participate in real-world politics.
Professor Winston didn't rein !ids in when they went too far on the webdte and doesn't respond to
student complaints.
BEST CLASS EVERlllU
Showing 1 to 4 of 4 ratings I1 page 1 of 1 *
35

## Page 33

EVANS V. NITA STATE UNIVERSITY
Exhibit 10
Anonymous Email to Dean Jeffries
From: anonymous@hawtmail.nita
To: djeffries@nsu.edu.nita
Subject: Anonymous tip
Date: October 31, YR-3, 2:10 p.m.
Dear Dean Jeffries:
Attached is a video I stumbled upon of NSU student Riley Evans drinking while underage at a
party. Additionally, I have attached a screenshot of a post on Professor Winstone's Politics and
Social Media Class Facebook page alleging that Evans is not the original author of the work
Evans submits for grades.
As a student who values the integrity of this university, I couldn't, in good conscience, allow
Evans's actions to go unpunished, which is why I am forwarding this to you anonymously.
Anon
mohilephd
Hey. I am a law student at Nita State University College of Law (NCL)...just wanted to share my two
cents. Evans paid me to write freshman envoys fast year...I totally believe the cheating stories.
~4,. Like Comment October31, YR-3 at 12:04pm
EvanoYR-3 Did you aendthrs to thin 1sd (nary Board?Haw dare yool
Like November 1, YR-3 at 12:35pm
A f•Iritch4prez Goldie doesn't need tat Everyone lmows you re a cheat and a Ilarl
like November 1, YR-3 at 12:40pm
Write a comment...
National Institute for Trial Advocacy 37

## Page 34

RILEY EVANS
DECEMBER 28, YR-2, 11:00 A.M.
1 Q: Please tell us your name and where you live.
2
3 A: My name is Riley Evans. I currently live with my parents at 200 West Oxfield Lane
4 in Oaksville, Nita, but during the school year, I live in the dorms at Nita Commu-
5 nity College.
6
7 Q: What year are you in the college?
8
9 A: I am only a sophomore.
10
11 Q: How old are you?
12
13 A: I'm twenty-one years old.
14
15 Q: How long have you attended Nita Community College?
16
17 A: I enrolled for Spring YR-2 after I withdrew from Nita State University, so only one
18 semester.
19
20 Q: When did you withdraw from Nita State University?
21
22 A: I withdrew on November 3, YR-3. Unfortunately, because it wasn't the end of the
23 fall semester, I didn't get any credits from that semester, so when I started at Nita
24 Community College, I only had a full year of college that counted toward my credits.
25
26 Q: What was your grade point average at Nita State University when you withdrew?
27
28 A: I am a really good student and had a 4.0 GPA. I'm very proud of that.
29
30 Q: What is your grade point average at the community college?
31
32 A: Grades haven't come out yet, but I'm hoping it'll be the same. A 4.0. I've never
33 gotten anything lower than an A in my entire life!
34
35 Q: What do you intend to major in and choose as a career?
36
37 A: I'm not a hundred percent sure yet what my career path is going to be, but I am
38 very interested in politics and may eventually become a lobbyist or even work on
39 the Hill in Washington, D.C. So, I'm leaning toward a political science major, but
40 don't have to decide until next semester.
National Institute for Trial Advocacy 41

## Page 35

CASE FILE
1 Q: Why did you withdraw from Nita State University?
2
3 A: It's a long story, but the main reason is because I was being bullied by other
4 students during a seminar I was enrolled in.
5
6 Q: What was the seminar?
7
8 A: It was called Politics and Social Media, taught by Adjunct Professor Jamie Winstone
9 in the Fall YR-3 semester. It was a three-credit class and met every Monday and
10 Wednesday from 10:00 to 11:50 a.m. I'm not much of an early riser, so the time
11 of the class was perfect.
12
13 Q: Why did you enroll in the class?
14
15 A: Well, like I said, I'm interested in potentially becoming involved in politics and
16 I heard it was a great class that looked at the use of social media in campaigns.
17
18 Q: What do you mean by social media?
19
20 A: You know. Twitter, Facebook, Instagram, Reddit, Linkedln, and all the other web-
21 sites out there that everyone is using nowadays. The class was supposed to help
22 get an insider's view of the importance of the internet and social media websites
23 in running a campaign.
24
25 Q: When was your first class?
26
27 A: August 23, YR-3. The first month or so of classes were really not a big deal. Just
28 a bunch of lecturing about how to use social media in campaigns. Professor
29 Winstone used those classes to help familiarize us with the uses of those websites
30 and discuss the philosophy of using the internet to further a campaign. It wasn't
31 until October that things got a little dicey.
32
33 Q: What do you mean by that?
34
35 A: After the first month, Professor Winstone broke our class into two sections. There
36 were only a total of twelve people in the class, so we were broken into two groups
37 of six students. One student from each group was chosen to run as president, and
38 the other students had to help build the campaign.
39
40 Q: Who were the. students that were chosen to run for president?
41
42 A: I was one of them, and Morgan Ritchfield was another. We didn't have much
43 say. Professor Winstone just assigned who the candidates would be. I did not
44 volunteer.
42 National Institute for Trial Advocacy

## Page 36

EVANS V. NITA STATE UNIVERSITY
1 Q: Who's Morgan Ritchfield?
2
3 A: I didn't really know Morgan too well, but I knew Morgan was also a sophomore at
4 the time.
5
6 O.: Explain the process of what was supposed to happen once the students were
7 assigned their roles.
8
9 A: The two groups were supposed to use Facebook to create an online campaign. The
10 professor created one main group page on Facebook entitled Politics and Social
11 Media YR-3 Election that was a closed group, meaning only Professor Winstone
12 could control who became members. We all had to request to join the group so
13 we could use it for our campaign. Winstone was the only administrator of the
14 group. I don't really think Winstone ever cared about who looked at the site or
15 who even posted on it. I didn't understand why Winstone even bothered making
16 it a closed group. We were only supposed to use Facebook and not the other so-
17 cial networking sites out there like Twitter, Instagram, Reddit, Linkedln, et cetera,
18 even though we learned about those sites.
19
20 Q: Was there an election that took place?
21
22 A: There was supposed to be, eventually. The last week of class, the class was
23 supposed to elect a president based on the campaign.
24
25 Q: I'm showing you what I've marked as Exhibit 5. Do you recognize this?
26
27 A: Yes, I do.
28
29 Q: What is it?
30
31 A: This is a screenshot of the Facebook group I just mentioned, where anyone could
32 join and post something about the campaign.
33
34 0: Is it a fair and accurate copy of the Facebook group as it appeared on November 3,
35 YR-3?
36
37 A: Yes, it is.
38
39 Q: Excuse my ignorance, but I'm not too familiar with Facebook. Can you please gen-
40 erally describe this group and how it works?
41
42 A: Wow. I thought everyone had a Facebook account nowadays. OK, so basically,
43 as you can see at the top of this page, it's called Politics and Social Media YR-3
44 Election. That's what Professor Winstone named the group for every semester.
National Institute for Trial Advocacy 43

## Page 37

CASE FILE
1 What you're looking at specifically is the "wall" page. The wall is where people
2 who are members of the group can write comments for other group members to
3 see. Once a comment is written on the wall, someone can then add a comment
4 or "react to" the comment. You can also tell when the posts were written because
5 there are dates after each post.
6
7 Q: Can you explain to me what the different posts are?
8
9 A: Sure. As you can see, there are different profile names that can post different
10 comments.
11
12 Q: Do you know who all the profile names are?
13
14 A: Not exactly. I know some of them.
15
16 Q: Which ones do you know?
17
18 A: RitchfieldYR-3 was Morgan Ritchfield. I was EvansYR-3. Professor Winstone told
19 Morgan and me that as the candidates running for president, we were to use our
20 last name and the year to create our profile name. Other than those two profile
21 names, I could only guess as to who the others were. But it doesn't take a genius
22 to figure out that names like "Morganmaniac" and "Mritch4prez" were people
23 associated with Ritchfield's campaign.
24
25 Q: How did this Facebook group affect you?
26
27 A: This group is what eventually forced me to quit Nita State University.
28
29 Q: Why do you say that?
30
31 A: The things that were being written about me were just devastating and untrue. It
32 made a mockery of me, and I just got so embarrassed I had to get out of there.
33
34 Q: Let's go through that. The first couple posts mention something about cheating in
35 a class. Did you cheat in a class?
36
37 A: No, that's ridiculous. I'm just a really good student, that's all. That's what made
38 me so mad, because it's not true. And it made me even angrier that the university
39 started an investigation into whether I was cheating.
40
41 Q: What investigation are you talking about?
42
43
44
44 National Institute for Trial Advocacy

## Page 38

EVANS V. NITA STATE UNIVERSITY
1 A: As a result of these stupid posts, I got a summons to appear before the Academic
2 Integrity Board to discuss my grades from the YR-4/YR-3 school year because they
3 supposedly had reason to believe that 1 may have cheated.
4
5 Q: We'll talk about that investigation more in a moment. For now, let's review some
6 of the posts on Facebook. On October 10, YR-3, Morganmaniac wrote something
7 about you making fun of a kid in a wheelchair and telling a racist and crude joke
8 about him. Do you know anything about that?
9
10 A: No, nothing. There is a kid in a wheelchair that was a freshman at Nita State
11 University, but I've never spoken to him or about him. I just thought he was kind
12 of awkward because he kept to himself and never went out. I would never tell a
13 racist joke. That's not my style.
14
15 Q: On October 24, YR-3, RitchfieldYR-3 posted a video claiming it was you. I've
16 marked it as Exhibit 6 and am playing it on the TV screen. Do you recognize this
17 video I've marked as Exhibit 6?
18
19 A: Yes, I do.
20
21 Q: What is it?
22
23 A: It's a video that Morgan Ritchfield posted on Facebook on October 24, YR-3. I saw
24 it on Facebook on October 24, YR-3, and as you can see from the Facebook page,
25 it was posted by the profile "Morgan Ritchfield."
26
27 Q: Is it a fair and accurate copy of the video posted by Ritchfield?
28
29 A: Yes, it is.
30
31 Q: Who's in the video?
32
33 A: That's me and some of my friends at a party at Gamma Tau Lambda. It wasn't a
34 big deal.
35
36 Q: How old were you then?
37
38 A: It was freshman year, so I was probably nineteen years old.
39
40 Q: What were you drinking?
41
42 A: I'm embarrassed to admit, I was drinking alcohol and doing a keg stand. I cer-
43 tainly don't make a habit of it, but come on. It's college. Doesn't everyone drink
44 every now and then in college? I feel like an idiot that someone videotaped it and
National Institute for Trial Advocacy 45

## Page 39

CASE FILE
1 posted it online, though. I never would've thought someone would be so mean to
2 do that. And somehow, the university found out about this. They were investigat-
3 ing my underage drinking, too.
4
5 Q: I'm showing you what I've marked as Exhibit 4. Do you recognize it?
6
7 A: Yes, I do. J
8
9 Q: What is it?
10
11 A: This is the summons I received from the Academic Integrity Board to appear on
12 November 16, YR-3, for a hearing regarding my grades and whether I was drinking
13 as a minor.
14
15 Q: Is it a fair and accurate copy of the summons you received?
16
.17 A: Yes, it is.
18
19 Q: What ever happened with the investigation?
20
21 A: Nothing. I withdrew before the investigation could proceed.
22
23 Q: If you had nothing to hide, why did you withdraw before going through with the
24 investigation?
25
26 A: I really didn't want to deal with it. I didn't feel like I should have to defend myself
27 against these bogus accusations.
28
29 Q: Do you know how the school found out about your underage drinking?
30.
31 A: I don't know of any source other than Facebook and this video.
32
33 Q: Do you know who Goldiephd is?
34
35 A: I assume Goldiephd is the graduate student at Nita State University College of Law
36 who helped me with some of my essays. Her name was Goldie, but I can't remem-
37 ber her last name. She never actually wrote my papers, so this post is a complete
38 lie, but she did help me. Goldie's post made me believe that students other than
39 those in the class were actually viewing the site. The class had gotten quite popu-
40 lar in the last three years, and it doesn't surprise me that someone outside of the
41 class would've viewed it.
42
43 Q: How do you know the class had gotten popular?
46 S National Institute for Trial Advocacy

## Page 40

EVANS V. NITA STATE UNIVERSITY
1 A: The evaluations from the previous classes were available for students
2 to view in order to make an informed decision about whether to take
3 the class.
4
5 Q: Where were the evaluations located?
6
7 A: You could access them in the library or online through the university website.
8
9 Q: How many years had this class been offered?
10
11 A: It was offered every semester from Fall YR-6 through Fall YR-3.
12
13 Q: Did you ever view the evaluations?
14
15 A: Yes, I did.
16
17 Q: When did you view them?
18
19 A: Before I enrolled in the class.
20
21 Q: How did you view them?
22
23 A: Online.
24
25 Q: I'm showing you what I've marked as Exhibit 3. Do you recognize this?
26
27 A: Yes, I do.
28
29 Q: What is it?
30
31 A: This is a summary of Professor Winstone's evaluations from Fall YR-6 through
32 Spring YR-3 that 1 saw prior to enrolling in that class.
33
34 Q: Is this a fair and accurate copy of the evaluation summary you saw?
35
36 A: Yes, it is.
37
38 Q: What does the top row of the chart show?
39
40 A: It says FA YR-6, SP YR-5, etcetera, which represents the semesters Fall YR-6, Spring
41 YR-5, et cetera. Then, underneath that is the number of students that completed
42 the evaluations. For example, in Fall YR-6, ten out of twelve students completed
43 the evaluations.
National Institute for Trial Advocacy 47

## Page 41

CASE FILE
1 Q: Besides the university evaluations, were you aware of any other professor evalu-
2 ations of Jamie Winstone before enrolling in Winstone's class?
3
4 A: Yes. I'm a little embarrassed to admit it, but I did go to a website that has profes-
5 sor evaluations on it. It's not exactly an official website, but I find that people are
6 more candid on the website than they tend to be in a university evaluation.
7
8 Q: What is the website called?
9
10 A: TeacherMeter.
11
12 Q: I'm showing you a document that has been marked as Exhibit 9 for identification
13 purposes. Do you recognize it?
14
15 A: Yes, I sure do.
16
17 Q: What is it?
18
19 A: It is a screenshot of the evaluations for Professor Winstone on the website
20 TeacherMeter.
21
22 Q: Does Exhibit 9 fairly and accurately show what you saw on the website prior to
23 enrolling in Professor Winstone's class?
24
25 A: Yes, it does.
26
27 Q: Just out of curiosity, what is the thermometer next to Professor Winstone's name?
28
29 A: This is part of why the website is a bit embarrassing. When you go onto this
30 website, you evaluate certain things like overall quality, helpfulness, clarity, easi-
31 ness, and then there's the final category of hotness. It's no secret that Professor
32 Winstone is really good looking.
33
34 Q: Did you ever talk to anyone about your feelings about the Facebook posts?
35
36 A: Well, I spoke to a few people. I sent a text message to Ritchfield's campaign man-
37 ager Rob, and I spoke with Professor Winstone.
38
39 Q: Let's discuss first your text messages with Rob. Who is Rob?
40
41 A; Rob Thompson. He was Ritchfield's campaign manager. Rob was "Morganmaniac"
42 on the Facebook page.
43
44 Q: How did you text message Rob?
48 National Institute for Trial Advocacy

## Page 42

EVANS V. NITA STATE UNIVERSITY
1 A: I had his cell phone number that someone gave me.
2
3 Q: What was his phone number?
4
5 A: (555) 321-4890.
6
7 Q: I'm showing you what has been marked as Exhibit 8 for identification. Do you rec-
8 ognize it?
9
10 A: Yes, I do. It's a screenshot from my cell phone showing the text messages be-
11 tween me and Rob Thompson.
12
13 Q: Is Exhibit 8 a fair and accurate copy of the screenshot of your phone?
14
15 A: Yes, it is. I know that because I'm the one that took the screenshot. When I met
16 with my lawyer, she asked whether I talked to anyone about the video that was
117 on Facebook. When I told her that I sent text messages back and forth with Rob
18 Thompson, she asked me to take a screenshot of the messages. So, I did, and then
19 I emailed it to myself and to my lawyer.
20
21 Q: When did you take this screenshot?
22
23 A: I can't remember the exact day, but it was probably early January YR-2.
24
25 Q: When did you send these text messages between you and Rob Thompson?
26
27 A: Again, I don't know the exact time of day, but I sent them almost immediately
28 after Morgan Ritchfield posted the video of me doing the keg stand. That was on
29 October 24, YR-3.
30
31 Q: How did you take the screenshot of the messages? I mean, how can we know that
32 these weren't altered or edited in any way?
33
34 A: Are you questioning my integrity? Of course I didn't alter or edit them. Don't
35 you know how to take a screenshot using an iPhone? Everyone knows how to do
36 that. You just press the home and sleep buttons at the same time, and it takes a
37 screenshot.
38
39 Q: Did you report the Facebook posts to anyone at the university?
40
41 A: I was so frustrated and embarrassed about it that I felt as though I was constantly
42 being ridiculed and insulted, so I went to talk to Professor Winstone.
43
44 Q: Do you know whether the university has a policy against bullying?
National Institute for Trial Advocacy 49

## Page 43

CASE FILE
1 A: Yes, there is one.
2
3 Q: How do you know that?
4
5 A: It's in the university handbook that we all get at the beginning of the year.
6
7 Q: I'm showing you a copy of a page from the university handbook marked as Exhibit
8 1. Do you recognize it?
9
10 A: Yes, that's the portion that discusses cyberbullying and bullying in the university. I got
11 a copy of this particular version the first day of class on August 23, YR-3, via email.
12
13 Q: When did you talk to Professor Winstone about the Facebook posts?
14
15 A: I talked to Professor Winstone on two different occasions. The first time was after
16 class on October 11, and the second time was after class on October 26.
17
18 Q: Let's talk about that first time. What did you tell your professor?
19
20 A: I showed Professor Winstone the Facebook group page and pointed out all of the
21 posts about me cheating in class. I explained how that really offended me, and
22 Professor Winstone just kind of shrugged and said something like the posts were
23 nothing more than hard-nosed campaigning and told me not to be so sensitive.
24 When Winstone didn't do anything, I thought I could just take the matter into my
25 own hands, and I posted on the site calling Ritchfield a coward.
26
27 Q: What happened the second time you met with Professor Winstone?
28
29 A: Again, nothing really happened. I showed Professor Winstone the website again
30 and expressed my anger and embarrassment about the keg stand video. I asked
31 Winstone to take it down since Winstone was the only administrator of the site,
32 but Winstone refused. I also told Professor Winstone how I couldn't concen-
33 trate in class, that I had dropped out of student government because I was so
34 embarrassed, and that I was considering leaving the university altogether.
35 Professor Winstone just told me, "Welcome to real life," and that I should con-
36 Sider myself lucky for getting this experience in the safety of university instead of
37 being exposed to it in professional life. Then, the post from Gold iephd just put me
38 over the edge. I was so fed up and embarrassed that I decided to leave Nita State.
39
40 Q: Did anyone mention these posts to you in person?
41
42 A: Yes, it was terrible. I had-  several professors mention them to me and question me
43 about them, not to mention some of the students who ridiculed me on campus
44 saying things like "cheater" and "boozer." It was totally embarrassing.
50 National Institute for Trial Advocacy

## Page 44

EVANS V. NITA STATE UNIVERSITY
1 Q: Why aren't you suing Morgan Ritchfield for any of the comments Ritchfield made
2 on the website?
3
4 A: I don't know. I guess because Morgan's just a student and doesn't have any money.
5 Besides, my lawyer told me to go after the school.
6
7 Q: Is there anything else you would like to add?
8
9 A: No, that's all.
I have reviewed this deposition and certify it is an accurate reflection of my statements.
Signed:
Witnessed:
Riley Evans Date:  December 28, YR-2
Steven F. Fairlie Date:  December 28, YR-2
National institute for Trial Advocacy 51

## Page 45

JAMIE WINSTONE
DECEMBER 29, YR-2, 1O:OO A.M.
1 Q: Please tell us your name and where you live.
2
3 A: My name is Jamie Winstone. I currently reside at 72 West Dupont Circle in Nita City.
4
5 Q: How old are you?
6
7 A: I'm fifty-two years old.
8
9 Q: Are you married?
10
11 A: You betcha. I've been married for the past twenty years. We have two great kids,
12 an eighteen-year-old son and a sixteen-year-old daughter. My oldest is off to
13 college next year to study physics. I couldn't be more proud of them.
14
15 Q: Are you employed?
16
17 A: Yes, I am. I own my own lobbying firm. I also used to work as an adjunct professor
18 at Nita State University, but the university didn't renew my contract for the Spring
19 YR-2 semester, so I'm no longer working as an adjunct professor.
20
21 Q: When were you teaching there?
22 -
23 A: I had a four-year contract with Nita State from Fall YR-6 through Spring YR-2.
24
25 Q: What were you teaching?
26
27 A: I taught some introductory civics classes and a really interesting and relevant
28 course called Politics in Social Media. As a lobbyist, I am all too familiar with
29 how social media is impacting the political scene and how campaigns are using
30 social media with more frequency to relay their messages and garner votes.
31 So, I came up with an idea of holding a small seminar where the students run
32 a simulated election and integrate the use of social media. The first month of
33 the class, I taught the class how to use some of the websites like Twitter, Face-
34 book, Reddit, Linkedln, Instagram, etcetera, and showed examples of their use
35 in prior elections and campaigns, like in the Obama—McCain election and the
36 Trump—Clinton election. We've all seen how Trump loves to use Twitter, not
37 to mention all of the hoopla around Mueller's special investigation and report
• 38 and how easily Russia could meddle with an election through the use of social
39 media.
National institute for Trial Advocacy 53

## Page 46

CASE FILE
1 0: How many students were in your classes?
2
3 A: I wanted to keep it small, so I limited my enrollment to twelve students per
4 semester. What we did each semester was hold a mock presidential campaign. So,
5 I would assign two students the role of running for president, and the other ten
6 students were split into the two campaign teams. They had to make use of Face-
7 book to run their campaign. Ideally, I would've loved to use Twitter, Instagram,
8 Linkedln, and other major social networking sites, but I figured that it would be
9 best to contain the election process solely to one website so I could provide bet-
10 ter oversight. Facebook had the easiest platform on which to create and manage
11 private groups, so I just created a Facebook group each semester. That particular
12 semester, it was entitled Politics and Social Media YR-3 Election.
13
14 0: Who had access to the Facebook group?
15
16 A: Only people who I approved to join the group.
17
18 0: What do you mean by that?
19
20 A: There are a couple different privacy options on Facebook. I created a closed group
21 so that I, as the administrator of the group, would have to approve you to become
22 a member. Once you were approved as a member, you could access the Facebook
23 group, post in it, and see who the other members were.
24
25 0: How did you decide who could join the Facebook group?
26
27 A: What do you mean? If someone asked to join, I'd say yes.
28
29 0: Were any students or individuals that were not enrolled in your course approved
30 by you to become members of the site?
31
32 A: Of course. There were seventy-some-odd people that were members of the
33 group. Obviously, that includes people who were not students in the class.
34
35 0: What was your experience with this exercise during other semesters?
36
37 A: From my experience, the students in class really get into it and take the whole
38 thing seriously. So, in the past semesters, there was some typical political mud-
39 slinging going back and forth.
40
41 0: What do you do when you see what you call "typical political mudslinging"?
42
43 A: There's nothing for me to do. It's a campaign election. Of course, there are going
44 to be some feelings hurt.
54 National Institute for Trial Advocacy

## Page 47

EVANS V. NITA STATE UNIVERSITY
1 Q: What type of boundaries did you provide that your students must follow during
2 the campaign?
3
4 A: I didn't. The way I saw it, these students were all over eighteen years old. If they
5 can't figure out appropriate boundaries, then they needed to learn a lesson.
6 Besides, in the real political world, there aren't many boundaries. It definitely
7 takes thick skin to play in the political arena.
8
9 Q: Have you ever seen your student evaluations?
10
11 A: Yes, of course. It was important to me what my students thought of me. Fortu-
12 nately, most of the evaluations were stellar. Seemed to me like I was connecting
13 with my students really well.
14
15 Q: I'm showing you what I've marked as Exhibit 3. Do you recognize this?
16
17 A: Yes, I do. It's the student evaluation summary form from Fall YR-6 through
18 Summer YR-3.
19
20 Q: Did you read these evaluations completely?
21
22 A: Yes, I read every word.
23
24 Q: Did you change any of your class assignments or how the class was run based on
25 any of these evaluations?
26
27 A: Nope. I didn't change a thing.
28
29 Q: Are you aware of any other student evaluations?
30
31 A: I don't know what you mean or what you are talking about. .
32
33 Q: I'm showing you a document marked Exhibit 9 for identification. Do you recognize
34 it?
35
36 A: Not at all. I've never seen this before. What is it?
37
38 Q: It's a screenshot from a website called TeacherMeter. It is your evaluations by
39 various students. Were you aware that this website existed and that students
40 were making comments about you on this website?
41
42 A: Obviously I wasn't aware. I've never seen this document before. But I'm flattered
43 that I've received a thermometer for hotness. You have to love the minds of our
44 future.
National Institute for Trial Advocacy 55

## Page 48

CASE FILE
1 Q: When was the Politics in Social Media class in the Fall YR-3?
2
3 A: It met on Mondays and Wednesdays from 10:00 to 11:50 a.m. It was a three-
4 credit class.
5
6 Q: Who was assigned to be the presidential candidates?
7
8 A: Two sophomores, Riley Evans and Morgan Ritchfield. They both seemed to express
9 interest in potentially going into the political arena, and they both volunteered for
10 the position.
11
1.2 Q: Did you assign the students their profile names for Facebook?
13
14 A: Not all of them. I made sure the two presidential candidates used their last name
15 plus the school year, for example, RitchfieldYR-3, butfor the other students, I just
16 left it up to them. I figured it was part of their creativity for purposes of campaign-
17 ing and didn't want to stifle any good ideas.
18
19 Q: I'm showing you a copy of Exhibit 5. Is this a printout of the Facebook group from
20 the Fall YR-3 class?
21
22 A: Yes, it is.
23
24 Q: Did you look at this group throughout the semester?
25
26 A: Yes, I typically looked at the group thirty minutes before every class so I could be
27 up to date about what was going on.
28
29 Q: Are you aware of a cyberbullying policy at the university?
30
31 A: Yes. Every year, we got some silly handbook that contained a section about
32 bullying.
33
34 Q: I'm showing you Exhibit 1. Do you recognize this?
35
36 A: Yes, I do. That's the cyberbullying policy of Nita State University that was sent to
37 me via email in the beginning of the semester in August YR-3. We would receive a
38 copy of the policy every academic year. But when I first started, I had to undergo
39 an hour of training on the policy during new hire orientation.
40
41 Q: I'm now showing you Exhibit 7. Do you recognize Exhibit 7?
42
43 A: I do. That is the email that Dean Jeffries sent out at the beginning of the school
44 year, YR-3.
56 National Institute for Trial Advocacy

## Page 49

EVANS V. NITA STATE UNIVERSITY
I. 3
1 Q: Is it a fair and accurate copy of the email?
2
3 A: Yes, it is. It is from Dean Jeffries's email address, which is djeffries@nsu.edu.nita, and
4 sent to the faculty listsery email address, which is fac/staff_listserv@nsu.edu.nita.
5
6 Q: Did you read the email?
7
8 A: It's the same policy as always, so I probably didn't bother. But I did respond to the
9 email, as I was required to do. That's what the top part of Exhibit 7 is, my response
10 that I received it.
11
12 Q: The first page of Exhibit 7, which is the email from Dean Jeffries, indicates that
13 there is an attachment. Did you ever open the attachment, and do you know what
14 the attachment was?
15
16 A: Like I said, I honestly cannot say for sure whether I opened it. I had received the
17 same email every year, so I just assumed that it was the same and didn't bother
18 reading it. But I assume that it was an attachment of the school's policy, which you
19 just showed me marked as Exhibit 1.
20
21 Q: Did any students complain to you about the Facebook group during the Fall YR-3
22 semester?
23
24 A: Yes. Riley Evans came to me twice. First, Riley met with me after class on October
25 11, YR-3, and our second meeting took place after class on October 26, YR-3. At
26 both meetings, Riley showed me the Facebook group as if I hadn't been paying
27 attention to it. Riley was complaining that the posts were too harsh and untrue or
28 something like that. I basically told Riley to get thicker skin. I mean, Riley wanted
29 to eventually get into politics, and how is that possible if you're going to get this
30 upset over a class project?
31
32 Q: Did Riley explain to you plans to drop out of school and had already dropped out
33 of extracurricular activities?
34
35 A: Nope. Not at all. Riley just kept complaining that the other students were being
36 so mean and unfair. Again, I explained that it's better to learn these lessons in the
37 shelter of a university atmosphere as opposed to the real world.
38
39 Q: Did you ever ask the other students to stop posting mean comments?
40
41 A: No. It's a free world, and the last thing I want to do is decrease the effectiveness
42 of this exercise by trying to control what people post.
43
44 Q: Did you ever do anything as a result of the meetings with Riley Evans?
National Institute for Trial Advocacy 57

## Page 50

CASE FILE
1 A: I wrote an interoffice memo to Dylan Jeffries after my second meeting with Riley,
2 but I didn't do anything after the first meeting.
3
4 Q: Who's Dylan Jeffries?
5
6 A: Dylan Jeffries is the Dean of Academics for Nita State University. I was supposed
7 to let Dean Jeffries know of any situations that arose in classes that related to
8 cyberbullying claims, so I was!following what I was supposed to be doing.
9
10 Q: I'm showing you Exhibit 2. Do you recognize it?
11
12 A: Yes, I do.
13
14 Q: What is it?
15
16 A: This is the memo I hand-delivered to Dean Jeffries on October 28, YR-3.
17
18 Q: Is it a fair and accurate copy of the memo you wrote to Dean Jeffries?
19
20 A: Yes, it is.
21
22 Q: Why did you think what Riley Evans told you "wasn't a big deal" and "didn't need
23 to be addressed"?
24
25 A: Like I already told you, I didn't think that any of the comments or posts on Face-
26 book were that big of a deal.
27
28 Q: To the best of your knowledge, did Nita State University do any investigation into
29 the matter?
30
31 A: I have no idea. But I do know that it did not renew my teaching contract.
32
33 Q: Did you ever follow up with the Dean to see whether the university took any
34 action?
35
36 A: No. Why would I?
37
38 Q: When did your teaching contract expire?
39
40 A: At the end of the Spring YR-2 semester. I was under the impression that I would be
41 teaching the same class in the spring, as it was on the university course roster and
42 being advertised on its academic courses website, but I had a meeting with Dean
43 Jeffries before the end of the fall semester and was told that I would no longer
44 be teaching. Apparently, from what Dean Jeffries told me, the school wasn't too
58 National Institute for Trial Advocacy

## Page 51

EVANS V. NITA STATE UNIVERSITY
1 happy with how I handled the Riley Evans situation. Jeffries told me directly that
2 I was being let go because the school had been sued and that I should've been
3 editing and censoring the students more to avoid this type of situation. The
4 university was sued sometime in December. It's not my fault.
5
6 Q: How much were you being paid to teach?
7
8 A: I got $3,000 a credit. With my eighteen-year-old son going to college next year, it
9 sure would've been nice to have that extra money, but things happen.
10
11 Q: Are you here today out of your own accord?
12
13 A: I'd really rather not be involved at all. I got a subpoena from the plaintiff's attor-
14 ney. I honestly think Riley Evans is just an example of how young students nowa-
15 days have a sense of entitlement and need to grow up and get tough. I mean,
16 that's what college is about, right? Preparing students for the real world.
17
18 Q: Would you like to say anything else?
19
20 A: No.
I have reviewed this deposition and certify it is an accurate reflection of my statements.
Signed:
Witnessed:
Jamie Winstone
Steven F. Fairlie
Date:  December 29, YR-3
Date: December 29, YR-3
National Institute for Trial Advocacy 59

## Page 52

DYLAN JEFFRIES
JANUARY 4, YR-i, 3:45 P.M.
1 Q: Please tell us your name and where you live.
2
3 A: My name is Dylan Jeffries. I live at 52993 Breeze Point Road in Rightsville, Nita.
4
5 Q: What is your educational and employment background?
6
7 A: I received a BA in education in YR-34 from Westmont University. I started
8 working as a high school English teacher in Middlebury, Nita, right after
9 I graduated. I earned my MA in higher education in YR-29 and moved on to
10 teaching English at Nita Community College. In YR-25, I became a full-time
11 professor of English, specializing in American dialects, at Nita State University.
12 I became tenured in YR-21, which is pretty quick for a professor. However,
13 I was routinely evaluated by students as the best professor on campus,
14 I received three teaching awards in four years, and I had published six articles
15 and one New York Times bestseller novel. I earned my doctorate in education
16 in YR-15.
17
18 Q: What do you currently do for a living?
19
20 A: I am the Dean of Academics for Nita State University. I was promoted to this posi-
21 Lion in YR-14.
22
23' Q: What are your duties as the Dean of Academics?
24
25 A: I oversee all the curriculum and professors at the school. It's a pretty big uni-
26 versity, with about 35,000 students. There are hundreds of classes offered each
27 semester. My goal is to ensure all the courses being taught meet the rigorous
28 academic standards for which this university is known. I interview, hire, evaluate,
29 and mentor the professors. I am also the head of the Academic Integrity Board,
30 which investigates and disciplines students for violations of the academic honor
31 code, such as cheating. A subsidiary of that board is the Disciplinary Board, which
32 looks into allegations that students violated any other school policy. I'm also the
33 head of that board.
34
35 Q: To your knowledge, does the university have any policies on bullying?
36
37 A: Yes, the school has an anti-bullying policy, as well as one against cyberbullying.
38 I helped develop it after the state legislature passed the School Cyberbullying
39 Protection Act of YR-6.
National Institute for Trial Advocacy 61

## Page 53

CASE FILE
1 Q: Please describe the cyberbullying policy.
2
3 A: The policy prohibits students from using any sort of school technology to harass
4 or intimidate anyone connected with the university. It includes using school corn-
5 puters to post to outside websites and using outside computers to post to school
6 websites.
7
8 Q: Why was this policy developed?
9
10 A: The policy was developed to comply with the state anti-cyberbullying statute.
11
12 Q: You are being shown a document that is labeled Exhibit 1. Do you recognize this?
13
14 A: Yes, it is a copy of the university's cyberbullying policy.
15
16 Q: Is it a fair and accurate copy of the policy?
17
18 A: Yes.
19
20 Q: Do you have any involvement with the university's anti-bullying policies?
21
22 A: Yes.
23
24 Q: Please describe your involvement.
25
26 A: I am responsible for ensuring every professor and student completes the manda-
27 tory annual training on the cyberbullying policy. I also respond to any complaints
28 or concerns professors bring to me in accordance with the policy.
29
30 Q: How is training for the faculty conducted?
31
32 A: When the policy was implemented, we held several training sessions to ensure all
33 existing faculty and staff were trained on the policy in person. Each new faculty
34 member receives an hour of training on the policy during their new hire orienta-
35 tion. After that, they are emailed a copy of the policy at the start of each academic
36 year. They are required to reply by email certifying that they have reviewed the
37 policy within one week of receiving the reminder.
38
39 Q: Why do you not conduct a live annual training on this policy?
40
41 A: We tried the first year, but it just wasn't feasible to have a time that fit the sched-
42 ules of all the professors and staff Including the part-time, full-time, and adjunct
43 professors, we have over 200 professors. The professors are especially hard to
44 schedule because they travel during semester breaks or are on sabbatical. The
62 National Institute for Trial Advocacy

## Page 54

EVANS V. NITA STATE UNIVERSITY
1 administration decided that all our employees are professionals and could be
2 trusted to complete the training on their own after the initial live session. We
3 have not had any problems with this method.
4
5 Q: That seems like a lot of oversight for you to have to be responsible for. Does any-
6 one else help you with this?
7
8 A: I have an assistant who helps oversee some of the faculty members, too.
9
10 Q: Just one?
11
12 A: Just one. We haven't really had an issue like this until now.
13
14 Q: How are students trained on the cyberbullying policy?
15
16 A: Like the faculty and staff, each student receives training on the policy when they
17 enter the university. Each student receives an email at the beginning of each fall
18 semester reminding them of the policy.
19
20 Q: I'm showing you what has been marked as Exhibit 7 for identification. Do you rec-
21 ognize it?.
22
23 A: Yes, I do. This is the email that I sent to the faculty and staff listsery on August 15,
24 YR-3.
25
26 Q: It indicates there is an attachment to the email. What is the attachment?
27
28 A: That is a copy of the YR-3 Cyberbullying Policy, which you just showed me as Ex-
29 hibit 1.
30
31 Q: Whose email is djeffries@nsu.edu.nita?
32
33 A: That's my email address. ,
34
35 Q: Who did this email go out to?
36
37 A: I have an email listsery that includes all faculty and staff members. They all
38 received a copy of this through the email address fac/staff_listserv@nsu.edu.nita.
39
40- Q: Did you ever receive a response from Jamie Winstone indicating that Winstone
41 received the email?
42
43 A: Yes, I did receive a response from Professor Winstone three days-later on August
44 18. That's the top portion of Exhibit 7.
National Institute for Trial Advocacy 63

## Page 55

CASE FILE
1 Q: What is the process for evaluating a complaint of cyberbullying?
2
3 A: First, the professor has to become aware of the situation, either through a
4 student report or by personal observation. Once that happens, the professor
5 must inform us of the situation, including the students involved and the circum-
6 stances surrounding the alleged bullying. After we receive the professor's report,
7 the disciplinary board, decides on a case-by-case basis how to handle the issue.
8 Some cases we can dismiss right away. Others require more investigation. The
9 reporting professor plays a key role in the investigation because he or she has the
10 first-hand knowledge of what happened.
11
12 Q: Do you know a person named Jamie Winstone?
13
14 A: Yes, Jamie Winstone used to be a professor at this university and taught a so-
15 cial media class in the political science department, as well as introductory civics
16 classes.
17
18 Q: What do you mean by "used to be a professor"?
19
20 A: Winstone was an adjunct professor who taught on a four-year contract with the
21 school. Jamie was hired in August YR-6, and the contract was terminated after the
22 Fall YR-3 semester.
23
24 Q: Why was Winstone's contract terminated early?
25
26 A: Well, Winstone was a very well-liked professor whose classes always filled up.
27 The annual evaluations were satisfactory. I never told Winstone the reason for
28 being fired was because we were sued by Evans. I would never say such a thing,
29 but that is why the school asked me not to renew his contract. The one big nega-
30 five against Winstone, though, was the rise in complaints on the students' class
31 evaluations.
32
33 Q: What sort of complaints did students make?
34
35 A: They were mostly along the lines of the professor not controlling the class discus-
36 Sion and atmosphere. We strive to make this school a positive learning environ-
37 ment, so complaints of this type are taken very seriously.
38
39 Q: When did you first start receiving these complaints?
40
41 A: Fall YR-4.
42
43 Q: I'm showing you Exhibit 3. Do you recognize that?
64 National Institute for Trial Advocacy

## Page 56

EVANS V. NITA STATE UNIVERSITY
1 A: Yes, I do.
2
3 Q: What is it?
4
5 A: This is the Professor Evaluation Summary for Jamie Winstone for the Politics and
6 Social Media class.
7
8 Q: Is it the regular practice of the university to make this type of document?
9
10 A: Yes, it is.
11
12 Q: Is Exhibit 3 kept in the regular course of a regularly conducted activity at the
13 university?
14
15 A: Yes, it is.
16
17 Q: How is the exhibit created?
18
19 A: My office collects the evaluations of professors and adjunct professors each
20 semester. We compile all the information for the same professor and create this
21 document so it's easier for students to look at a professor's evaluations for all of
22 his or her semesters.
23
24 Q: Did you ever discuss the evaluations with Professor Winstone?
25
26 A: Each professor is given the results of the student evaluations, so l am sure Profes-
27 sor Winstone was aware that it was an issue, but I never had a direct conversation
28 with Winstone about it.
29
30 Q: How are professors evaluated?
31
32 A: Each professor has a set of goals for the academic year, such as course enrollment,
33 participation in meetings and boards within the school, and other professional
34 metrics. Additionally, students complete a standard evaluation of the professors
35 at the end of each semester. These student evaluations are compiled and made
36 available on the university website. We examine them for trends in how students
37 perceive the professors. We want to ensure students are getting a good education
38 from quality professors, so a downward trend in an area is reason for concern.
39
40 Q: Besides the university evaluations, are you aware of any other evaluations of Pro-
41 fessor Winstone?
42
43 A; I don't know what you are talking about.
National Institute for Trial Advocacy 65

## Page 57

CASE FILE
1 Q: I'm showing you what I've marked as Exhibit 9 for identification. Do you recognize
2 this?
3
4 A: No, I don't. I've never seen this before.
5
6 Q: You are being shown a document marked as Exhibit 2. Do you recognize this?
7
8 A: Yes, it is a memo Professor Winstone sent to my office in October YR-3. It
9 describes a meeting with one of the students in the Politics and Social Media
10 seminar taught by Professor Winstone each semester. It was a very popular class.
11 Apparently, a student, Riley Evans, who brought this lawsuit against the univer-
12 sity, was complaining about the behavior of another student in the class.
13
14 Q: What action did you take as a result of this memo?
15
16 A: None.
17
18 Q: Why not?
19
20 A: Well, as you can see in the memo, there doesn't appear to be much more than
21 hurt feelings. We rely on professors as the frontline investigators when it comes
22 to complaints like this. Since Professor Winstone did not think it was serious, we
23 followed that recommendation.
24
25 Q: The memo clearly references the Facebook group. Why didn't you ask to see the
26 group content so you could make your own determination?
27
28 A: Look, Jamie Winstone was an employee and was previously trained about our
29 cyberbullying polices. I relied on Winstone's determination that the comments
30 and posts that were put on that page were not a big deal.
31
32 Q: Do you know Riley Evans?
33
34 A: You mean besides from this lawsuit claiming cyberbullying?
35
36 Q: Yes, did you know Riley Evans before this lawsuit?
37
38 A: Yes. Unfortunately, Evans's name came up before the academic integrity and the
39 disciplinary boards shortly before Winstone sent me this memo.
40
41 Q: Why were the boards investigating Riley Evans?
42
43 A: The disciplinary board was investigating.a report of underage drinking and a report
44 that Riley Evans paid a graduate student to write essays for Evans's freshman year.
66 National Institute for Trial Advocacy

## Page 58

EVANS V. NITA STATE UNIVERSITY
1 Q: How were these reports made?
2
3 A: We have a way of emailing the disciplinary board anonymously on our website.
4 We find that fosters students to make reports. If they have to identify themselves
5 when making the reports, then oftentimes they will not do so out of fear that the
6 reported student will find out. The disciplinary board received a video via email
7 from an anonymous student that showed Evans drinking at an underage party.
8 We also received an anonymous email regarding Evans's cheating. Someone sent
9 a copy of a Facebook post from "Goldiephd."
10
11 Q: I'm showing you a copy of what I've marked as Exhibit 10. Do you recognize it?
12
13 A: Yes, I do. This is a fair and accurate copy of the email that I received anonymously
14 on October 31, YR-3, at 2:10 p.m. It has attached to it the video of:Evans doing a
15 keg stand and the screenshot of a post by Goldiephd on Facebook.
16
17 Q: What did you do as a result of receiving this email?
18
19 A: Normally, the board invites the student to speak with us about the allegations of
20 underage drinking and cheating, so we sent a summons requiring Evans to show
21 up for a hearing where we would discuss the allegations.
22
23 Q: Do you recognize this document, which is marked as Exhibit 4?
24
25 A: Yes, it is the summons the disciplinary board sent to Evans regarding the hearing
26 we required Evans to attend.
27
28 Q: Is it a fair and accurate copy of that summons?
29
30 A: Yes.
31
32 Q: What was the result of the investigation into Riley Evans's grades?
33
34 A: The board never completed its investigation because Evans withdrew from the
35 university shortly after Professor Winstone sent my office that memo.
36
37 Q: Did you or anyone else from the disciplinary or academic integrity boards view
38 the entire Facebook page from Professor Winstone's class?
39
40 A: No, I didn't see how that was necessary.
41
42 Q: Is there anything else you'd like to add?
43
44 A: No, there isn't.
National Institute for Trial Advocacy 67

## Page 59

CASE FILE
I have reviewed this deposition and certify it is an accurate reflection of my statements.
Signed:
Witnessed:
Dylan Jeffries
Steven F. Fairlie
Date:  January 4, YR-1
Date:  January 4, YR-1
68 National Institute for Trial Advocacy

## Page 60

MORGAN RITCHFIELD
JANUARY 5, YR-1, 11:00 A.M.
1 Q: Please tell us your name and where you live.
2
3 A: My name is Morgan Ritchfield. I live in Room 5B, Naylor Hall, on the campus of
4 Nita State University in Nita City, Nita.
5
6 Q: How old are you?
7
8 A: I'm twenty-one years old.
9
10 Q. Where are you from?
11
12 A: I was born and raised right here in Nita City.
13
14 Q: What do you do for a living?
15
16 A: I am currently a senior at Nita State University. I'm majoring in economics. I started
17 out in philosophy, but my parents convinced me to get a degree that I can use as
18 soon as I graduate. It's been a dream of mine since I was a kid tb go to school here.
19 This has been the best experience of my life.
20
21 Q: How long have you been enrolled at the university?
22 _
23 A: Since Fall YR-4. I've been here for my entire school career.
24
25 Q; How are your grades?
26
27 A: Well, I started out pretty rough because I was partying too much, but I've man-
28 aged to bring them up to a 2.97 GPA. Hopefully, I can get above a 3.0 by the time
29 I graduate.
30
31 Q: What do you plan to do when you graduate?
32
33 A: I want to work for an economics think tank in D.C., someplace I can apply eco-
34 nomic theory to politics. I haven't really been interested in politics, but some of
35 the classes I've taken here at NSU have really piqued my interest.
36
37 Q; Do you remember what classes you took in the Fall YR-3?
38
39 A: Of course. I took Macroeconomics, Introductory German, Calculus, Modern
40 American Poetry, and Politics and Social Media.
National Institute for Trial Advocacy 69

## Page 61

CASE FILE
1 Q: What was the Politics and Social Media class?
2
3 A: It was a three-credit class that met on Monday and Wednesday mornings from
4 10:00 to 11:50. That was the main class that got me interested in politics. It
5 explored how modern politics are influenced by all forms of social media—blogs,
6 social networks like Facebook and Twitter, webpages, et cetera. It was really
7 awesome.
8
9 Q: Who taught the course?
10
11 A: Professor Jamie Winstone, who is amazing. Professor Winstone really gave us an
12 in-depth, hands-on experience of how campaigns really work and how social me-
13 dia has transformed the campaign landscape.
14
15 Q: Why did you decide to take the class?
16
17 A: I wanted to take a political science course, and this one had great reviews. I looked
18 at the student evaluations and Professor Winstone was rated very highly on how
19 interesting the class was, how much experience the professor had, and for having
20 a relaxed atmosphere in class. It sounded like the perfect interesting, laid-back
21 class to balance out my other classes.
22
23 Q: You are being shown a document marked Exhibit 3. Do you recognize it?
24
25 A: Yes, it's the summary of student evaluations for Professor Winstone that I looked
26 at when I was deciding whether to take the Politics and Social Media class. All the
27 students can access it on the school's website.
28
29 Q: Is it a fair and accurate copy of the evaluations you examined?
30
31 A: Yes.
32
33 Q: I'm now showing you Exhibit 9. Do you recognize it?
34'
35 A: Yes, I do. It looks to be a screenshot of Professor Winstone's evaluation on a web-
36 site called TeacherMeter.
37
38 Q: Did you look at this website before enrolling in
the class?
39
40 A: Yes, I did. Most students nowadays go to this website to get the real inside scoop
41 on a professor. Exhibit 9 is a fair and accurate copy of how the website looked as
42 of August YR-3.
70 National Institute for Trial Advocacy

## Page 62

EVANS V. NITA STATE UNIVERSITY
1 Q: Is this a fair and accurate copy of how the website looked as of August YR-3?
2
3 A: Yes, it is.
4
5 Q: What type of work did you do in the class?
6
7 A: There were a lot of little side assignments, but the major project was a semes-
8 ter-long "presidential election" campaign. The class was divided in half, with
9 Professor Winstone picking a student to be the candidate, and the rest of the
10 students were campaign staff.
11
12 Q: How many students were in the class?
13
14 A: Twelve, although one dropped out halfway through the semester.
15
16 Q: Who were the presidential candidates in your class?
17
18 A: I was one, and Riley Evans was my opponent.
19
20 Q: Who won the election?
21
22 A: I did, by default, since Evans dropped out of school during that semester.
23
24 Q: What type of social media was involved in the campaign?
25
26 A: Mostly Facebook. Although we learned about the use of other social media tools,
27 Professor Winstone only let us post on Facebook. Winstone created a Facebook
28 group called Politics and Social Media YR-3 Election. We used it to introduce the
29 candidates and their platforms, plus publish news or updates. Anyone could post
30 comments about the candidates, the campaign, et cetera.
31
32 Q: When you say "anyone" could post comments, what do you mean by that?
33
34 A: Anyone that was a member of the group could post comments.
35
36 Q: How did someone become a member of the Facebook group?
37
38 A: That's easy. As long as you had a Facebook profile page, you could ask to join
39 the group. Professor Winstone was the administrator, so Winstone determined
40 whether you could become a member or not.
41
42 Q: You are being shown a document labeled Exhibit 5. Do you recognize this?
National Institute for Trial Advocacy 71

## Page 63

CASE FILE
1 A: Yes.
2
3 Q: What is it?
4
5 A: It's a printout of the Facebook group page that was used in the class, for the
6 campaign. This printout shows the Facebook group page as of November 3, YR-3.
7
8 Q: Is it a fair and accurate copy of the Facebook group page?
9
10 A: Yes, as far as I can tell. It looks like all the posts that I remember.
11
12 Q: Do you recognize any of the screen names on this printout?
13
14 A: Yes, I recognize most of them. "RitchfieldYR-3" is me. "Morganmaniac" was my cam-
15 paign manager, Rob Thompson. "Mritch4prez" was Misty Wellman, my spokeswoman.
16 "EvansYR-3" was Riley Evans. I think "evanslvr" was someone on Evans's campaign
17 staff. I don't know who "Goldiephd" was, but anyone could post on the site, like I said.
18
19 Q: How do you know who had these screen names?
20
21 A: Both candidates were required to use our last names and the year as our screen
22 names, that way everyone would know it was us who was posting the messages.
23 I know Rob and Misty's screen names because we chose them at our first cam-
24 paign meeting. I assume Evans did the same thing for the staff on that campaign.
25
26 Q: Why did you make the first comment about integrity?
27
28 A: I kind of took a page from the other campaigns I've watched over the last year, for
29 state or federal offices. One big part of getting people to vote for you is showing
30 that you have integrity and the other guy doesn't. I wanted to be first out of the
31 box to use that tactic and stake the claim on that concept.
32
33 Q: Did you know anything specific about Riley Evans that made you believe Evans did
34 not have integrity?
35
36 A: Not me, personally, but some stuff came up during our campaign meetings. Other
37 people knew Evans from previous classes. I told them they could post anything
38 they wanted, so long as they had proof to back it up.
39
40 Q: Let's discuss the post by the profile name Morgan Ritchfield that has a video
41 attached to it. What is the content of that post?
42
43 A: I uploaded a link to a video I had of Evans getting drunk and doing a keg stand at a
44 fraternity party during freshman year. I think it was February or March YR-4. I had to
72 National Institute for Trial Advocacy

## Page 64

EVANS V. NITA STATE UNIVERSITY
1 use my own personal Facebook profile name, Morgan Ritchfield, because for some
2 reason Facebook wouldn't let me upload the video by using my RitchfieldYR-3 page.
3
4 Q: Where did you get the video?
5
6 A: I took it myself with my iPhone. I was at the party and saw Evans chugging beer,
7 doing shots, and generally acting like an idiot. l didn't know who Evans was then,
8 but I thought it was funny and started recording it on my phone. I forgot about it
9 until I was going through my phone during class one day in Fall YR-3 and recog-
10 nized Evans as the person in the video.
11
12 Q: Why did you upload the video?
13
14 A: Evans was going on and on in class about being an upstanding citizen who always
15 follows the rules. This was direct proof against that, so I figured it had to be
16 posted. The people have a right to know when candidates are lying to them. Plus,
17 outside of class, I totally heard Evans brag about being able to do the longest keg
18 stand ever. What a joke. That's more like the shortest keg stand ever.
19
20 Q: You are watching a video that is labeled Exhibit 6. Do you recognize this?
21
22 A: Yes, that's the video I made of Evans at the party and posted to Facebook.
23
24 Q: Is this a fair and accurate copy of that video?
25
26 A: Yes, that's the whole video I shot.
27
28 Q: Did Riley Evans ever speak to you about the things that were posted on the Face-
29 book group?
30
31 A: No, Evans never came to me, but I do know that Evans sent text messages to my
32 campaign manager, Rob Thompson.
33
34 Q: I'm showing you Exhibit 8. Are these the text messages to which you just referred?
35
36 A: Yes, I believe they are.
37
38 Q: How did you know that Evans sent text messages to Rob Thompson?
39
40 A: Because Thompson forwarded them to me, and we talked about them.
41
42 Q: I'm confused. What exactly does Exhibit 8 show?
43
44 A: That's a screenshot of the text messages between Riley Evans and Rob Thompson.
National Institute for Trial Advocacy 73

## Page 65

CASE FILE
1 Q: OK, but you said that Rob forwarded them to you. So, this is a screenshot from
2 your phone? Or from Rob's phone?
3
4 A: Oh, I understand your confusion. It's actually a screenshot from Riley Evans's
5 phone. Rob had also taken a screenshot from his phone and sent it to me,,so
6 I saw the conversation previously, but from Rob's perspective. Exhibit 8 is the
7 same conversation that Rob showed me.
8
9 Q: So, who wrote which color?
10
11 A: Obviously, the blue bubbles are Riley Evans and the light gray bubbles are Rob
12 Thompson.
13
14 Q: How can you be so sure?
15
16 A: Because the person sending the message is the one with the blue bubbles, and
17 the recipient's name is at the top of the screen. Plus, the blue bubble says "Riley
18 Evans."
19
20 Q: When did Rob discuss this conversation with you?
21
22 A: October 31.
23
24 Q: Do you know when Rob received the messages?
25
26 A: No.
27
28 Q: Do you know Evans's phone number or Rob's phone number?
29
30 A: Not off the top of my head, no.
31
32 Q: Were you aware that these statements were upsetting Evans?
33
34 A: No, not at all. I don't see why they were upsetting either. I mean, even the text
35 message Evans sent to Rob Thompson didn't actually say that Evans was upset.
36 It's not like any of the statements on Facebook were lies. If Evans didn't want
37 people to know about that stuff, Evans shouldn't have done those things in
38 public.
39
40 Q: Did you write, or encourage anyone to write, statements with the intention to
41 bully Riley Evans?
42
43 A: No, not at all. I have nothing against Evans at all. We barely know each other. This
44 was only part of the class. We were role-playing.
74 National Institute for Trial Advocacy

## Page 66

EVANS V. NITA STATE UNIVERSITY
1 Q: Are you aware that Riley Evans dropped out of school?
2
3 A: Yeah, I heard something about that. I figured it was because of the academic
4 integrity investigation that started after everyone found out about Evans's cheating
5 and underage drinking.
6
7 Q: Are you aware of the school's policy on cyberbullying?
8
9 A: Yes, I remember reading about the policy in the university handbook I was given
10 during freshmen orientation. We all had to sign a paper acknowledging we read
11 and understood the policy. The university also sends out a copy by email in August
12 of each school year. We have to reply that we received it.
13
14 Q: You are being shown what is marked as Exhibit 1. Do you recognize this?
15
16 A: Yes, it's a copy of the cyberbullying policy from the university handbook.
17
18 Q: Is this a fair and accurate copy of the policy?
19
20 A: Yes.
21
22 Q: Did you ever consider that the comments on the campaign bulletin board were
23 cyberbullying?
24
25 A: No, not at all. Everything that was on that board was true. And it's not like we
26 posted it on the front page of the school newspaper.
27
28 Q: Did Professor Winstone ever speak with you about the Facebook posts or corn-
29 ments made during the campaign?
30
31 A: No, never. In fact, I got an A in that course, which really helped bring my GPA up.
32
33 Q: Did anyone from the school administration ever speak to you about the Facebook
34 posts?
35
36 A: No.
37
38 Q: Were you disciplined for the Facebook posts?
39
40 A: No, I've never been in trouble at school.
41
42 Q: Well, that's not exactly true, is it?
43
44 A: What are you talking about?
National Institute for Trial Advocacy 75

## Page 67

CASE FILE
1 Q: Didn't you lie on a college application to University of Transylvania about your
2 high school GPA and then get caught by the University of Transylvania?
3
4 A: Well, yeah, but that's a different school. I meant I've never been in trouble at this
5 school. At Nita State University.
6
7 Q: Whatever happened with the issue at the University of Transylvania?
8
9 A: Nothing, really. I got a phone call from the admissions department basically tell-
10 ing me that they got my transcript from high school and. the GPAs did not match
11 up. They strongly suggested that I withdraw my application so as to avoid any fur-
12 ther issues or penalties, and I did. I put the wrong GPA on my application because
13 I really wanted to go to that school, and I figured they would never find out.
14
15 Q: Is there anything else you would like to say?
16
17 A: No.
I have reviewed this deposition and certify it is an accurate reflection of my statements.
Signed:
Witnessed:
Morgan Ritchfield
Steven F. Fairlie
Date:  January 5, YR-1
Date:  January 5, YR-1
76 National Institute for Trial Advocacy

## Page 68

STATE OF NITA SCHOOL
CYBERBULLYING PROTECTION ACT OF YR-6
(a) Each school within the Nita state school system, including primary, secondary, collegiate, and
charter schools, shall develop a policy to prohibit and punish cyberbullying to foster the learning
environment required of a state-funded school system.
(1) "Cyberbullying" is the repeated use by one or more students of a verbal, written, or elec-
tronic expression, or any combination thereof, directed at the victim that creates a hostile environ-
ment for the victim or interferes with the victims rights at school.
(A) "Technology" includes, but is not limited to, telephones, computers, game consoles,
and personal electronic devices such as MP3 music players, computer tablets, and smartphones.
(B) "Electronic communications" include, but are not limited to, any written, oral, or
visual imagery sent through technology included in (A) above. Examples of communications include
websites, electronic mail, instant messages, and postings to social media or shared media sites, either
within the school's domain or in the public domain through use of the school's equipment.
(C) A "hostile environment" is a situation that is permeated with intimidation, ridicule,
or insult that is sufficiently severe or pervasive to substantially interfere with the victims educational
performance, opportunities, or benefits.
(b) Each policy shall be distributed at least annually to all students, faculty members, and
employees of the school system. Distribution may be in printed or
electronic form. -
(c) School employees, faculty, or students who comply in good faith with the procedures set
forth in this act are immune from causes of action arising from incidents prohibited under this act.
(d) The First Amendment right to free speech is not a defense to any claim brought pursuant to
the Cyberbullying Protection Act of YR 6.
National Institute for Trial Advocacy 77

## Page 69

JURY INSTRUCTIONS
PRELIMINARY JURY INSTRUCTIONS
You have now been sworn as the jury to try this case. This is a civil case involving disputed claims
between the parties. Those claims and other matters will be explained to you later. By your verdict,
you will decide the disputed issues of fact. I will decide the questions of law that arise during the
trial, and before you retire to deliberate at the close of the trial, Twill instruct you on the law that you
are to follow and apply in reaching your verdict. It is your responsibility to determine the facts and
to apply the law to those facts. Thus, the function of the jury and the function of the judge are well
defined, and they do not overlap. This is one of the fundamental principles of our system of justice.
Before proceeding further, it will be helpful for you to understand how a trial is conducted. In
a few moments, the attorneys for the parties will have an opportunity to make opening statements,
in which they may explain to you the issues in the case and summarize the facts that they expect the
evidence will show. Following the opening statements, witnesses will be called to testify under oath.
They will be examined and cross-examined by the attorneys. Documents and other exhibits also may
be received as evidence.
After all the evidence has been received, the attorneys will again have the opportunity to address you
and to make their final arguments. The statements that the attorneys now make and the arguments that
they later make are not to be considered by you either as evidence in the case or as your instruction on
the law. Nevertheless, these statements and arguments are intended to help you properly understand the
issues, the evidence, and the applicable law, so you should give them your close attention. Following the
final arguments by the attorneys, I will instruct you on the law.
You should give careful attention to the testimony and other evidence as it is received and pre-
sented for your consideration, but you should not form or express any opinion about the case until
you have received all the evidence, the arguments of the attorneys, and the instructions on the law
from me. In other words, you should not form or
express any opinion about the case until you retire
to the jury room to consider your verdict.
The attorneys are trained in the rules of evidence and trial procedure, and it is their duty to make
all objections they feel are proper. When a lawyer makes an objection, I will either overrule or sus-
tain the objection. If I overrule an objection to a question, the witness will answer the question. If
I sustain an objection, the witness will not answer, but you must not speculate on what might have
happened or what the witness might have said had I. permitted the witness to answer the question.
You should not draw any inference from the question itself.
During the trial, it may be necessary for me to confer with the attorneys out of your hearing,
talking about matters of law and other matters that require consideration by me alone. It is impos-
sible for me to predict when such a conference may be required or how long it will last. When such
conferences occur, they will be conducted so as to consume as little of your time as necessary for a
fair and orderly trial of the case.
National Institute for Trial Advocacy 79

## Page 70

CASE FILE
At this time, the attorneys for the parties will have an opportunity to make their opening
statements.
FINAL JURY INSTRUCTIONS
Members of the jury, I shall now instruct you on the law that you must follow in reaching your ver-
dict. It is your duty as jurors to decide the issues, and only those issues, that I submit for determina-
tion by your verdict. In reaching your verdict, you should consider and weigh the evidence, decide
the disputed issues of fact, and apply the law on which I shall instruct you to the facts as you find
them, from the evidence.
The evidence in this case consists of the sworn testimony of the witnesses, all exhibits received into
evidence, and all facts that may be admitted or agreed to by the parties. In determining the facts, you
may draw reasonable inferences from the evidence. You may make deductions and reach conclusions
that reason and common sense lead you to draw from the facts shown by the evidence in this case, but
you should not speculate on any matters outside the evidence.
In determining the believability of any witness and the weight to be given the testimony of any
witness, you may properly consider the demeanor of the witness while testifying; the frankness or lack
of frankness of the witness; the intelligence of the witness; any interest the witness may have in the
outcome of the case; the means and opportunity the witness had to know the facts about which the
witness testified; the ability of the witness to remember the matters about which the witness testified;
and the reasonableness of the testimony of the witness, considered in light of the all the evidence in the
case and in light of your own experience and common sense.
When I say that a party has the burden of proof on any issue, or use the expression "if you find,"
"if you decide," or "by a preponderance of the evidence," I mean that you must be persuaded from a
consideration of all the evidence in the case that the issue in question is more probably true than not.
Any findings of fact you make must be based on probabilities, not possibilities. They may not be
based on surmise, speculation, or conjecture.
The issue for your determination on the claim of Riley Evans is whether Nita State University
was negligent in failing to take meaningful measures to prevent the ongoing cyberbullying against
Riley Evans, and, if so, whether such negligence was the proximate cause of any damages to Evans.
The terms "negligent" or "negligence" as used in these instructions mean the failure to use that
degree of care that an ordinarily careful and prudent person would use under the same or similar
circumstances.
Proximate cause is an act or failure to act which in the natural, continuous sequence was a sub-
stantial factor in producing the injury, and without which it would not have occurred. Proximate
cause occurs when the injury is the natural and foreseeable result of the act or failure to act.
80 National Institute for Trial Advocacy

## Page 71

EVANS V. VITA STATE UNIVERSITY
In order to establish negligence on the part of Nita State University, Riley Evans had to prove
that:
• Nita State University had a duty to Riley Evans to provide a safe school environment;
• Riley Evans was, in fact, bullied or harassed by one or more students at Nita State University;
• Nita State University knew of bullying or harassment by one or more students towards Riley
Evans;
• After learning of the bullying or harassment, it was foreseeable that the bullying or harass-
ment would continue;
• Such harassment or bullying did continue; and
• Nita State University did not take reasonable steps to prevent the injury or damage caused
by the bullying student or students to Riley Evans.
Nita State University is a quasi-municipal corporation. Under the law of this jurisdiction, em-
ployees such as adjunct faculty members, faculty members, and deans of the university are agents
of Nita State University. The university is liable if its agents act negligently as it relates to the role of
their employment.
Whether Riley Evans was, in fact, bullied or harassed is to be determined using a reasonable per-
son, or objective standard. That is, the question for your determination is not whether Riley Evans
subjectively believed he [or she] was being bullied and/or harassed, but what a reasonable person
would believe.
Nita State University has asserted what is called an affirmative defense of assumption of the risk.
In order to establish that Riley Evans assumed the risk, Nita State University had to establish that
Riley Evans had knowledge of a risk or danger, appreciated such risk or danger, and yet voluntarily
placed himself [or herself] in the environment. The knowledge required is actual knowledge. The
standard to be applied is a subjective one, of what Riley Evans saw, knew, understood, and appre-
ciated. It is not actual knowledge where it merely appears that Riley Evans should or could have
discovered the danger. An individual assumes all the ordinary risks of his or her voluntary acts or
the environment in which he or she voluntarily places himself or herself. An individual does not,
however, assume obscure and unknown risks, which are not naturally incident to such acts or envi-
ronment and which, in the existing conditions, would not be reasonably observed and appreciated.
However, if fully informed, Riley Evans may be deemed to assume the risk even though the danger-
ous condition was caused by the negligence of Nita State University. Should you find Nita State
University proved Riley Evans assumed the risk by a preponderance of the evidence, then you must
find in favor of Nita State University.
Nita State University claims that Riley Evans's harm resulted, in whole or in part, from
Riley Evans's own negligence. The terms "contributorily negligent" or "contributory negligence" mean
National'lnstitute for Trial Advocacy 81

## Page 72

CASE FILE
negligence on the part of Riley Evans. In order for Nita State University to avoid liability under this
theory, Nita State University must prove it is more likely true than not true that:
a) The plaintiff was negligent; and
b) The plaintiffs negligence was a proximate cause of the plaintiff's harm.
Shortly, you will retire to the jury room and be given a verdict form to fill out. Answer yes or no
to all questions unless otherwise instructed. A yes answer must be based on a preponderance of the
evidence unless you are otherwise instructed. If you do not find that a preponderance of the evidence
supports a yes answer, then answer no. The term "preponderance of the evidence" means the greater
weight and degree of credible evidence admitted in this case. Whenever a question requires an answer
other than yes or no, your answer must be based on a preponderance of the evidence unless you are
otherwise instructed.
At this point in the trial, you, as jurors, are deciding only if Nita State University was negligent
or whether Riley Evans assumed the risk. You will first return a verdict on that issue. If you find that
Nita State University was negligent, you will hear additional argument from the attorneys and you
will hear additional witnesses testify concerning damages.
Your verdict must be based on the evidence that has been received and the law on which I have
instructed you. In reaching your verdict, you are not to be swayed from the performance of your duty
by prejudice, sympathy, or any other sentiment for or against, any party.
When you retire to the jury room, you should select one of your members to act as foreperson
to preside over your deliberations and sign your verdict. Your verdict must be unanimous—that is,
your verdict must be agreed to by each of you. You will be given a verdict form, which I shall now
read and explain to you.
[read verdict form]
When you have agreed on your verdict, the foreperson, acting for the jury, should date and sign
the verdict form and return it to the courtroom. You may now retire to consider your verdict.
82 National Institute for Trial Advocacy

## Page 73

DISTRICT COURT OF THE STATE OF NITA
CIVIL DIVISION
RILEY EVANS
V.
NITA STATE UNIVERSITY
No. 123-YR-1
VERDICT FORM
We, the jury, return the following verdict:
1. Was there negligence on the part of Nita State University in failing to take measures to
prevent cyberbullying against Riley Evans, which was a legal cause of damage to Riley
Evans?
YES NO
If your answer to question 1 is NO, you should not proceed further except to date and sign
this verdict form and return it to the courtroom.
If your answer to question 1 is YES, please answer question 2.
2. Did Riley Evans assume the risk of injury he [or she] sustained?
YES  NO
If your answer to question 2 is YES, you should not proceed further except to date and
sign this verdict form and return it to the courtroom.
SO SAY WE ALL this day of , YR-1.
Foreperson
National Institute for Trial Advocacy 83
