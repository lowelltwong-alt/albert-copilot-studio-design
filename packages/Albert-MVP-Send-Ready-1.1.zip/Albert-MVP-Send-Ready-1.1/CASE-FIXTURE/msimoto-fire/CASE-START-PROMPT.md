# Case Analyst — first run with the included Msimoto Fire fixture

Use the two attached files as a paired source set:

1. `MSIMOTO-original.pdf` is the authority. Use it to resolve page layout, images, exhibits and any OCR ambiguity.
2. `MSIMOTO-ocr.md` is generated working text. Use it for searchable text, but do not promote an OCR guess to a fact.

Run the MVP source intake and produce the normal RUN-01 handoff. Preserve page anchors and semantic exhibit boundaries even where the document does not label an item "Exhibit." For every material statement, record source file, page or section anchor, speaker or document attribution, certainty, and whether the witness would know it. List OCR uncertainty and every PDF/OCR discrepancy for later review. Do not summarize beyond the supplied files, add outside facts, invent a speaker, or state that an image proves more than the source shows.

End with the complete Markdown packet required by RUN-01 and a short `INPUT-LIMITATIONS` section stating whether the PDF was directly readable in this tenant and which pages or exhibits need human visual review.
