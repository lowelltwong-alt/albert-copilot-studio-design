# Msimoto Fire case fixture

This folder is included so the first MVP pilot can start with a real, source-grounded test instead of an empty chat. It is the fire-insurance mock-trial case.

## Files

- `MSIMOTO-original.pdf` — original case-file PDF. Treat this as the source authority.
- `MSIMOTO-ocr.md` — our existing OCR-derived Markdown snapshot. It is a working convenience copy, not source truth; preserve uncertainty and compare it to the PDF when the two differ.
- `CASE-START-PROMPT.md` — the exact first message to send after the Case Analyst agent is configured.

## Use and rights

This is a private test fixture for the recipient's licensed mock-trial work. Do not publish, commit to a public repository, or redistribute the PDF unless the recipient has the right to do so. The package contains no OCR engine; it only supplies the existing OCR snapshot so the prompt-only MVP can be exercised.

## Source boundary

The PDF is authoritative. The OCR Markdown may have recognition errors, missing layout, and imperfect exhibit boundaries. The Analyst must keep page anchors, semantic exhibit boundaries and conflicts visible, and must not turn an OCR guess into a fact. If the tenant cannot ingest the PDF, record that limitation in the source ledger and keep the PDF beside the run for human review.

## Integrity

- Original PDF SHA-256: `2eb938ef405bfbacb0fe8f1f7b25cecf7c9280c1d36b650184de21e551a0440d`
- OCR Markdown SHA-256: `87493a974329acfb0f9092ac4d83208f9c9e00cb9b41bfdd1cba8a1b83bd06d8`

