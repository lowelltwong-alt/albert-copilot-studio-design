# What the other packages are for

The MVP is the only package needed for the first Copilot Studio pilot. Keep the other packages separate until the MVP's source, evidence and conversation checks are useful.

## No MCP or API

`Albert-No-MCP-or-API-1.0.zip` expands the same source-grounded idea into a longer manual workflow. It gives one all-in-one prompt, explicit case/exhibit ledgers, storage templates, acceptance checklists and detailed diagrams. It still relies on human packet handoffs and does not need a server.

## MCP and API

`Albert-MCP-and-API-1.0.zip` describes the connected architecture, service contracts, API/MCP connector shapes and durable storage boundaries. It is an implementation design, not a completed full Albert case-processing backend. Do not present it as deployed until the backend, authentication, tenant and regression tests exist.

## Digital Assets with MCP

`Albert-Digital-Assets-1.0.zip` is an independent, reusable digital-assets service. It catalogs agents, workflows, skills, prompts and harnesses; exposes typed graph search and lifecycle checks; and accepts explicit privacy-safe lesson candidates. It does not observe another AI automatically, does not promote lessons, and is not required by the prompt-only MVP. Open its `AI_FRONT_DOOR.md` before connecting it.

