# Email to send with the MVP

**Subject:** Albert MVP — prompt-only Copilot Studio pilot

Hello,

I’m sending the first Albert package as a prompt-only Copilot Studio pilot. It is intentionally self-contained: no MCP server, API, SharePoint connection or database is required. The purpose of this first run is to see whether the source-grounded workflow produces a useful podcast transcript and witness-preparation work product before connecting the later versions.

Please extract the pack and open `MVP/START-HERE.md`. The short setup is:

1. Create four unpublished agents in standard Copilot Studio.
2. Paste each exact ROLE file into the agent’s **Overview → Instructions** field.
3. Select the proposed model if it is available, and record the actual model if your picker uses a different label.
4. Open `MVP/WORKFLOWS/README.md` and follow `MVP/PROMPTS/00-PLACEMENT.md`.
5. Run the numbered prompts in the Test agent chat, saving and reopening each complete Markdown packet before copying it to the next role.
6. Choose a folder under `CASE-FIXTURE/`, add its original PDF and paired OCR Markdown as the case inputs, and send that folder's exact `CASE-START-PROMPT.md` text to the Case Analyst. If file upload is unavailable, use the OCR Markdown as text input while retaining the PDF for source review.
7. Run `RUN-01` through `RUN-11` in order, saving each complete Markdown handoff. `MVP/More/02-RUN-GUIDE.md` explains what to paste, what to save and which reviewer must be independent.
8. Review the source, evidence, conversation quality, timing and witness-preparation outputs together. The synthetic case in `MVP/More/02-RUN-GUIDE.md` remains available as a smaller workflow check.

The expected work product is a source graph and ledger, witness profile and packet, evidence and conflict review, a two-host conversational script, a podcast-quality review, timing/export instructions and a witness-preparation card. It creates no audio. It should not be treated as approved legal advice, a gold-standard producer or a tenant-validated deployment until the team reviews the outputs.

The two future packages are included only as orientation in `FUTURE-PACKAGES.md`. **No MCP or API** is the expanded manual workflow after this pilot. **MCP and API** is the connected design, which still needs its full case-processing backend and tenant acceptance. **Digital Assets with MCP** is a separate optional DAD-style catalog and learning service; it is not required for this MVP.

The included case files are private test materials. Keep each PDF under the recipient's existing license and do not publish or redistribute it. Each PDF is source authority; its paired OCR Markdown is a generated convenience copy and must be checked against the PDF where the text, layout or exhibit boundary is uncertain.

Please record the actual model labels, run date, source packet, output files, held conflicts and any proposed repairs. Keep the original PDF private and use the OCR Markdown only as a convenience copy. The standalone MVP ZIP SHA-256 is `6102713cfd9495911dced23c43933c93a62bda02c1b86dc62d6949a8e992e97e` for version checking; the case fixture hashes are in `HANDOFF-RECEIPT.json`.

Best,

