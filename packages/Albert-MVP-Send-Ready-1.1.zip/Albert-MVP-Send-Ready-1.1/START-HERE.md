# Albert MVP — send-ready quick start

This pack contains the prompt-only MVP. Start with the extracted `MVP/START-HERE.md`. The MVP is independent of MCP, API, SharePoint, the Digital Assets package and the two future upgrade packages.

## First run

1. In standard Copilot Studio, create four unpublished agents.
2. In each agent's **Overview → Instructions**, paste the exact ROLE file listed below. Select the proposed model only if it is available in your tenant; record the actual model if the label differs.
3. Open `MVP/WORKFLOWS/README.md` and `MVP/PROMPTS/00-PLACEMENT.md`.
4. Run the numbered RUN prompts in the Test agent chat. The operator saves, reopens and copies the complete Markdown packet between roles.
5. Choose one of the three included case fixtures in `CASE-FIXTURE/`: Msimoto Fire, the City Cubs baseball-bat case, or Evans v. Nita State University (the professor case). Keep the selected PDF as source authority and its paired OCR Markdown as a convenience working copy.

## First case-file run after setup

1. Open the selected fixture's `README.md` and confirm the rights and source-authority note.
2. Add both files from that fixture folder to the case input. If the tenant supports file upload, attach its original PDF and paired OCR Markdown. If it supports only one file, use the PDF first and paste or upload the OCR Markdown in a second source step.
3. Send the exact text in that fixture's `CASE-START-PROMPT.md` to the Case Analyst Test agent. It tells the Analyst to compare the two representations, preserve page/exhibit boundaries and hold OCR uncertainty instead of silently repairing it.
4. Run `RUN-01` through `RUN-11` in the order in `MVP/More/02-RUN-GUIDE.md`, saving the complete Markdown packet after each handoff. The first run is a pilot exercise; review its source, conflict, podcast and witness-preparation outputs before using a live case.
5. If the agent cannot ingest the PDF, keep it beside the run as the visual authority and use that fixture's OCR Markdown as the text input. Record that limitation in the source ledger and do not call the result gold-standard.

| Agent | Exact Instructions file | Proposed pilot model | Test-chat prompts |
|---|---|---|---|
| Case Analyst | `MVP/PROMPTS/ROLE-ANALYST.md` | GPT-5.5 | RUN-01 |
| Writer | `MVP/PROMPTS/ROLE-WRITER.md` | Claude Sonnet 4.6 | RUN-02, RUN-04, RUN-08, RUN-10 |
| Evidence Reviewer | `MVP/PROMPTS/ROLE-EVIDENCE.md` | GPT-5.5 | RUN-03, RUN-05, RUN-07, RUN-09 |
| Conversation Reviewer | `MVP/PROMPTS/ROLE-CONVERSATION.md` | GPT-5.5 | RUN-06 |

Run RUN-11 only as a separate non-author audit. Do not let a reviewer audit its own work.

## What to save

Keep the complete graph/view, source ledger, witness packet, plan, evidence review, conversation review, final two-host script, timing sheet and witness preparation card. Preserve the input and output Markdown exactly at each handoff. The MVP has no automatic file storage; the operator is the state manager.

## Acceptance check

Before treating a run as useful, verify that claims are source-linked or held, conflicts remain visible, unproved identity/details are not invented, both speakers contribute naturally, examination lessons are taught, and the independent reviewer can explain every repair. The bundled synthetic example is a held development candidate, not a gold-standard or tenant-acceptance result.

The included case files are a private test fixture. Do not publish the PDF or redistribute it outside the rights held by the recipient. The PDF is authoritative; the OCR Markdown is generated working text and may contain recognition errors.

## Package identity

Standalone MVP ZIP SHA-256: `6102713cfd9495911dced23c43933c93a62bda02c1b86dc62d6949a8e992e97e`

