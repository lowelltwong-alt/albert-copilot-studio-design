# DAD-derived material — restrictive boundary

DAD-derived adaptations in this package are controlled internal adaptation material pending the owner's final license decision. The donor contains no completed permissive grant. Do not redistribute, sublicense, sell or offer these adaptations as an external service without separate written permission. Preserve provenance and notices. See the separately supplied `LICENSE-DAD-DERIVED.md` in Digital Assets with MCP for the full draft terms.
