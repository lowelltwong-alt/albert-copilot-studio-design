# Licensing and attribution

This package is a mixed-rights distribution. Material authored for the Albert implementation package is offered under **Creative Commons Attribution 4.0 International (CC BY 4.0)** where the owner has the right to grant that license. Attribution should name the project, preserve this notice and link to https://creativecommons.org/licenses/by/4.0/.

The CC BY grant does not cover DAD-derived material, third-party dependencies, Microsoft documentation, or any source whose own terms differ. Those components retain their separate terms. CC licenses are not a substitute for a software license for code; the runtime's code and dependencies must be reviewed under their applicable notices.

The DAD donor checkout reviewed for this package contains `LICENSE_DECISION_REQUIRED.md` and no completed permissive license grant. DAD-derived adaptations are therefore separated by provenance and remain under the restrictive recipient terms in `LICENSE-DAD-DERIVED.md` pending the owner's final selection. Do not redistribute them under CC BY by assumption. Public release also requires a rights review of every copied or adapted file and dependency.

