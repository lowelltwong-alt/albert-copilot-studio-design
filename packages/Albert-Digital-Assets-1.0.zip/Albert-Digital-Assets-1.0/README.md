# Digital Assets with MCP

Start with [AI_FRONT_DOOR.md](AI_FRONT_DOOR.md). This package is a lightweight, independent DAD-style library for discovering and reviewing reusable agents, workflows, skills, prompts and harnesses.

It includes a typed metadata graph, verified content retrieval, lifecycle expiry checks, a local stdio MCP server, a loopback Streamable HTTP adapter, and an API-key guarded Azure adapter. Its cross-instance learning path is opt-in and candidate-only: another AI must explicitly report a privacy-safe observation. The service never watches an AI, promotes a lesson, or changes instructions automatically.

Run the local suite:

```powershell
python -B tests/test_runtime.py
```

The HTTP suite requires the task-local MCP/ASGI dependencies and Windows dependency paths described in `RUNTIME-CONTRACT.md`; it was run during development with the pinned task-local dependency set. Azure, Copilot Studio, Foundry and Entra/OAuth acceptance remain deployment work.

The catalog currently contains seed protocols plus searchable reference cards for the high-value Team Toolkit roles and workflows. They are candidate metadata, not permission to execute or adopt them. See `PROVENANCE.md`, `LICENSE.md` and `LICENSE-DAD-DERIVED.md` before copying or publishing.
