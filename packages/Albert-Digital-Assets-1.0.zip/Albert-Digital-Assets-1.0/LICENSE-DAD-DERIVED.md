# DAD-derived material — restrictive recipient terms (draft)

Status: **owner decision required before external or public distribution**. This draft is included to make the boundary visible; it is not a substitute for a signed license decision.

The identified DAD-derived adaptations may be used, copied and modified by the directly receiving organization for its internal activities, including internal Azure hosting. Staff and contractors may use them solely on that organization's behalf under the same restrictions. They may not be sold, publicly redistributed, transferred to another organization, offered as an external hosted service, or sublicensed without the owner's separate written permission. Preserve attribution, provenance and this notice. Third-party components retain their own licenses. No ownership transfer or endorsement is granted; the material is provided as-is to the extent permitted by law.

The owner has not yet selected between this internal-use-and-modification scope and the narrower evaluation-only scope. Until that decision is recorded, treat DAD-derived material as controlled internal adaptation only. This restriction does not alter rights in independently authored Albert material offered under CC BY 4.0 or rights already granted by another licensor.

